<?php

if (isset($_REQUEST['name'],$_REQUEST['email'])) {
      
    $name = $_REQUEST['name'];
    $email = $_REQUEST['email'];
    $message = $_REQUEST['message'];
	
	$frompage = $_REQUEST['frompage'];
	
//	$str = "<p>this -&gt; &quot;</p>\n";

//$str1 = htmlspecialchars_decode($message);

// note that here the quotes aren't converted
//$str2 = htmlspecialchars_decode($message, ENT_NOQUOTES);
							 
							 
							 

	
	$from1 = "VOG Website Form";
	
	$date = date("Y-m-d H:i:s");
      
    // Set your email address where you want to receive emails. 
    $to = 'guy@voiceoverguy.co.uk';
	//$to = 'info@ld360.co.uk';
	
	///movie@voiceoverguy.co.uk
      
  //  $subject = 'Custom Script from $email ';
	$subject = "Website enquiry from ".$email."\r\n";
      
    $headers = "From: ".$name." <".$email."> \r\n";
	
	$headers .= "MIME-Version: 1.0\r\n";
//Set the content-type to html
//	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
$headers .= "Content-Type: text/html; charset=utf-8";
	
	
//accept-charset="utf-8
	
$message2 = '<html><body>';
$message2 .= '<h2>Voiceover Guy Blog Post Enquiry</h2>';
$message2 .= '<h2>'.$frompage.'</h2>';
$message2 .= '<p><b>Name: </b>'.$name.'<br>';
$message2 .= '<b>Email: </b>'.$email.'<br>';

	
	//str_replace('<br />', "\n", $textarea);
	
	//$message2 .= '<h2>'.nl2br($message).'</h2>';
//$message2 .= '<h2>'.($str1).''.($str2).'</h2>';
	
	$message2 .= '<h2>'.($message).'</h2>';
	

$message2 .= '</body></html>';
	
	
	 // $message2 = "From :$name \n<b>Email</b>: $email \n Script:\n$message \r\n";
      
    $send_email = mail($to,$subject,$message2,$headers);
      
	 
	 
	
  // header( 'Location: http://movietrailervoice.co.uk/script1.php?=sent' ) ;

 
   
    echo ($send_email) ? 'success' : 'error';
	
	
	
	
	
}
	
	
	

	
	
	
      


?>