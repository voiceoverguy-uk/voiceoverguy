<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo5.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo5.s2'); ?>">
    <meta name="keywords" content="Apple voice style, minimalist voiceover, British voiceover, Male Voiceover, Apple ad style, casual narration, clean voiceover, Guy Harris voiceover">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seo5.s2'); ?>">

<meta name="Robots" content="index, follow">


<meta property="og:title" content="<?php echo Config::get('seo5.s2'); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="https://www.voiceoverguy.co.uk/apple-voice-style">
<meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/apple-voice-style-og.jpg">

<meta property="fb:app_id" content="128367003916318">




<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/apple-voice-style" /> 
<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	
	
		<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "Apple Voice Style | Guy Harris – British Voiceover Artist",
  "url": "https://www.voiceoverguy.co.uk/apple-voice-style",
  "description": "Guy Harris delivers premium Apple-style voiceovers – sleek, minimal, and trusted by the world’s top brands.",
  "mainEntity": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk/",
    "image": "https://www.voiceoverguy.co.uk/assets/images/guy-harris-voiceover.png",
    "jobTitle": "British Male Voiceover Artist",
    "sameAs": [
      "https://www.linkedin.com/in/voiceoverguy/",
      "https://www.voiceoverguy.co.uk/",
      "https://www.youtube.com/c/voiceoverguy"
    ]
  }
}
</script>

  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "CreativeWork",
    "name": "Apple Voice Style",
    "description": "Looking for that clean, minimalist Apple commercial narration style? Guy Harris delivers just that – a trusted British voiceover artist who’s worked with Apple and many more.",
    "url": "https://www.voiceoverguy.co.uk/apple-voice-style",
    "image": "https://www.voiceoverguy.co.uk/assets/images/apple-voice-style-og.jpg",
    "author": {
      "@type": "Person",
      "name": "Guy Harris"
    }
  }
  </script>
	
	
	</head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo html_entity_decode(Config::get('seo5.s3')); ?>



</div>
</div>
</div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">
<iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/26491585&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true" height="315" width="100%" frameborder="no" scrolling="no"></iframe>
</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">
<div class="row">

<div class="col-md-6" >

<?php echo html_entity_decode(Config::get('seo5.s4')); ?>
</div>

<div class="col-md-6" >
<br>

<?php
$string2 = Config::get('seo5.s20');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo5.s7'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo5.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>



</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>

<?php
$string2 = Config::get('seo5.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo5.s8'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo5.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>


</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo5.s5')); ?>
</div>


</div>

<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo5.s6')); ?>
</div>

<div class="col-md-6" >
<br>
<a href="voiceover-cartoons" title="Apple Voice Style - Guy Harris" ><img alt="Apple Voice Style - Guy Harris" title="Apple Voice Style - Guy Harris" class="img-responsive"   src="assets/images/cartoons/Voiceover-Cartoon-TheAgency.jpg" /></a>

</div>


</div>





<?php include("assets/inc/applinks.php"); ?>



</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>


<?php include("assets/inc/footer.php"); ?>

 
    
</body>
</html>