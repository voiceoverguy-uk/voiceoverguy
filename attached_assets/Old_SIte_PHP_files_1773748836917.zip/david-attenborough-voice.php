<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo18.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo18.s2'); ?>">
    
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seo18.s2'); ?>">

<meta name="Robots" content="index, follow">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">


<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/david-attenborough-voice" />
<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	
	
	
	<script type="application/ld+json">
{

  "@context": "https://schema.org",

  "@type": "ProfilePage",

  "mainEntity": {

    "@type": "Person",

    "name": "Guy Harris",

    "alternateName": "VoiceoverGuy",

    "jobTitle": "British Male Voiceover Artist",

    "description": "Guy Harris is an award-winning British male voiceover artist, known for his David Attenborough impression voiceovers used in TV, games, social campaigns and promos.",

    "url": "https://www.voiceoverguy.co.uk/david-attenborough-voice",

    "image": "https://www.voiceoverguy.co.uk/images/guy-harris-profile.jpg",

    "sameAs": [

      "https://www.linkedin.com/in/voiceoverguy/",

      "https://www.youtube.com/user/voiceoverguyharris"

    ],

    "worksFor": {

      "@type": "Organization",

      "name": "VoiceoverGuy"

    }

  }

}
<\/script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "mainEntity": {
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Who is the most famous wildlife narrator?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Sir David Attenborough is widely regarded as the most famous wildlife narrator, with a career spanning decades of natural history documentaries."
        }
      },
      {
        "@type": "Question",
        "name": "Is David Attenborough’s voice AI?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "While AI voice generators exist, Guy Harris provides a natural David Attenborough impression voiceover, delivering nuance and storytelling that AI cannot replicate."
        }
      },
      {
  "@type": "Question",
  "name": "Is this Attenborough voice generated by AI?",
  "acceptedAnswer": {
    "@type": "Answer",
    "text": "No. This is a real voiceover performed by award-winning British voice artist Guy Harris, using his own voice to create a natural, respectful Attenborough-style narration."
  }
},
      {
        "@type": "Question",
        "name": "Who has 32 honorary degrees?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Sir David Attenborough has been awarded 32 honorary degrees from universities worldwide, recognising his influence on broadcasting and education."
        }
      }
    ]
  }
}
</script>

	<meta property="og:title" content="David Attenborough Voice Impression - Guy Harris" />
<meta property="og:description" content="A highly realistic David Attenborough voiceover impression by award-winning voice artist Guy Harris. Used in TV, games, and viral campaigns." />
<meta property="og:image" content="https://www.voiceoverguy.co.uk/images/attenborough-voice-og.jpg" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta property="og:url" content="https://www.voiceoverguy.co.uk/david-attenborough-voice" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="VoiceoverGuy" />
<meta property="og:image:alt" content="David Attenborough Voice Impression by Guy Harris" />

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "AudioObject",
  "@id": "https://www.voiceoverguy.co.uk/david-attenborough-voice#audio",
  "name": "David Attenborough Voiceover Demo – Guy Harris",
  "description": "A natural David Attenborough-style narration performed by British male voiceover artist Guy Harris.",
  "url": "https://www.voiceoverguy.co.uk/assets/audio/david-attenborough-demo-25-guy-harris.mp3",
  "contentUrl": "https://www.voiceoverguy.co.uk/assets/audio/david-attenborough-demo-25-guy-harris.mp3",
  "encodingFormat": "audio/mpeg",
  "inLanguage": "en-GB",
  "duration": "PT1M26S",
  "thumbnailUrl": "https://www.voiceoverguy.co.uk/images/attenborough-voice-og.jpg",
  "uploadDate": "2025-01-15T12:00:00+00:00",
  "publisher": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "David Attenborough Voice Demo – Main Video",
  "description": "Cracking Ice – A nature‑style narration over skaters enjoying King Winter’s reign in the Netherlands, voiced in a David Attenborough impression by Guy Harris.",
  "thumbnailUrl": "https://i.ytimg.com/vi/t0DqlSVh6hc/maxresdefault.jpg",
  "uploadDate": "2021-02-14T12:00:00+00:00",
  "contentUrl": "https://www.youtube.com/watch?v=t0DqlSVh6hc",
  "embedUrl": "https://www.youtube.com/embed/t0DqlSVh6hc",
  "inLanguage": "en-GB"
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "David Attenborough Voice Demo – Big Blue Planet",
  "description": "A spoof Attenborough-style narration following boys on Missionary Ridge preparing for their great migration into the wild. Voiced by British voiceover artist Guy Harris.",
  "thumbnailUrl": "https://i.ytimg.com/vi/diSuM7OMyGg/maxresdefault.jpg",
  "uploadDate": "2022-05-16T12:00:00+00:00",
  "contentUrl": "https://www.youtube.com/watch?v=diSuM7OMyGg",
  "embedUrl": "https://www.youtube.com/embed/diSuM7OMyGg",
  "inLanguage": "en-GB"
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "How fast can you record my Attenborough-style script?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Most Attenborough-style scripts are recorded the same day, often within a few hours depending on schedule and direction needs."
      }
    },
    {
      "@type": "Question",
      "name": "Do I need permission to use an Attenborough impression?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "No. An Attenborough-style voiceover is a transformative performance. Guy Harris delivers an original interpretation without imitating likeness or identity."
      }
    },
    {
      "@type": "Question",
      "name": "Can you match David Attenborough’s tone and pacing?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Guy Harris is known for his authentic pacing, warmth and storytelling delivery that captures the essence of Attenborough-style narration."
      }
    }
  ]
}
</script>
	
	
	</head>
	
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://www.voiceoverguy.co.uk/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "David Attenborough Voice",
      "item": "https://www.voiceoverguy.co.uk/david-attenborough-voice"
    }
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": "https://www.voiceoverguy.co.uk/#business",
  "name": "Guy Harris – VoiceoverGuy",
  "image": "https://www.voiceoverguy.co.uk/images/guy-harris-profile.jpg",
  "url": "https://www.voiceoverguy.co.uk",
  "telephone": "",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Wakefield",
    "addressRegion": "West Yorkshire",
    "addressCountry": "UK"
  },
  "priceRange": "££",
  "sameAs": [
    "https://www.linkedin.com/in/voiceoverguy/",
    "https://www.youtube.com/user/voiceoverguyharris"
  ]
}
</script>

	<style>
	
	#price1 {display: none;}
	#price2 {display: none;}
	#price3 {display: none;}
	#price4 {display: none;}
	#price5 {display: none;}
	
	
	input[type=text], input[type=email], textarea {
    border:1px solid #ccc;
    padding:8px;
    margin:2px 0;
    font-size:13px;
    font-family:Arial, Helvetica, sans-serif;
    color:#8f8f8f;
    width:250px;
    border-radius:5px;
    box-shadow:inset 0 0 8px #e5e8e7;
}
input[type=submit] {
    border:none;
    padding:8px 25px;
    margin:2px 0;
    font-family:Arial, Helvetica, sans-serif;
    color:#fff;
    background:#0d7963;
    border-radius:5px;
    cursor:pointer;
}
input[type=submit]:hover {
    opacity:0.9;
}

	</style>
	
	
	  
<script type="text/javascript">
$(function() {

$(".submit").click(function() {


	
	//var res = str.replace("Microsoft", "W3Schools");
	
	var myStr = $("#message").val();
    var newStr = myStr.replace(/&/g, "and");
	
    var message = newStr;
	
	
	var name = $("#name").val();
	var email = $("#email").val();
	
	     
	
    var dataString = 'message='+ message + '&name=' + name + '&email=' + email;
	
	
	
	if(message=='' || name=='' || email=='')
	{
	$('.success').fadeOut(200).hide();

    $('.error').fadeOut(200).show();
		
   
	}
	
	
	else
	{
	$.ajax({
	type: "POST",
    url: "process-form-david.php",
    data: dataString,
    success: function(){
	$('.success').fadeIn(200).show();
    $('.error').fadeOut(200).hide();
	$('.submit').fadeOut(200).hide();
	
		
   }
});




	}
		

    return false;
	});



});
</script>
	
	
	
	
	
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo html_entity_decode(Config::get('seo18.s3')); ?>



</div>
</div>
</div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">

<iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/24260716&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true" width="100%" height="150" frameborder="no" scrolling="no"></iframe>

</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">
<div class="row">

<div class="col-md-6" >

<?php echo html_entity_decode(Config::get('seo18.s4')); ?>
</div>

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo18.s20');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo18.s7'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo18.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>

</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo18.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo18.s8'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo18.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>


</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo18.s5')); ?>
</div>


</div>

<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo18.s6')); ?>
	
	<br>
	<p>
	If you are ready to book <a href="/contact-guy">please get in touch.</a>
		</p>
	
<!-- 	
	 <form id="form1" accept-charset="ISO-8859-1">



  <textarea style="width:100%; max-width:500px;  height: 140px; font-size:19px "  id="message" name="message"  placeholder="Please type your enquiry here" ></textarea>
<input style="width:100%; max-width:500px;" type="text" name="name" id="name" placeholder="Your Name" required><br>
<input style="width:100%; max-width:500px; " type="email" name="email" id="email" placeholder="Your Email" required><br>
<span class="error" style="display:none"> Please enter valid email address</span>
<br>
   
		
<input  type="submit" value="Send message" style="background:#B42C2D; color:#; font-size:14px; border:1px solid #B42C2D;  margin-left: auto;
    margin-right: auto; display:block" class="submit"/>
		 
		  <div  class="success" style="display:none">
 <h2 style="margin-top: -20px;">Message sent successfully</h2>
	</div>
 

  <input type="submit" name="send" value="Send" onClick="post();"> <span class="output_message"></span>
   
  
</form>
 -->
</div>

<div class="col-md-6" >
<br>
<a href="voiceover-cartoons"  title="David Attenborough Voice Impression" ><img alt="David Attenborough Voice Impression" title="David Attenborough Voice Impression" class="img-responsive"   src="assets/images/david-attenborough-voice.jpg" /></a>
	
	
	
	

</div>


</div>







<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

 <?php include("assets/inc/footer.php"); ?>
</body>
</html>