<?php require_once 'guyadmin/app/init.php';?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo.s7'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo.s8'); ?>">
    
<meta name="msvalidate.01" content="781CD99316BFBC157AA14BFEE683B5E7" />

<meta name="twitter:card" content="summary" />
<meta name="twitter:site" content="@voiceoverman" />
<meta name="twitter:title" content="<?php echo Config::get('seo.s7'); ?>" />
<meta name="twitter:description" content="<?php echo Config::get('seo.s8'); ?>" />
<meta name="twitter:url" content="https://www.voiceoverguy.co.uk" />
<meta name="twitter:image" content="https://pbs.twimg.com/profile_images/770927533437120512/twHj7UTs_400x400.jpg" />






<meta name="Robots" content="index, follow">

<meta name="apple-itunes-app" content="app-id=526007008, affiliate-data=myAffiliateData, app-argument=myURL">

<meta name="twitter:description" content="<?php echo Config::get('seo.s8'); ?>">
<link href="https://plus.google.com/+GuyHarrisVoiceoverGuy" rel="publisher" />

<meta property="og:title" content="<?php echo Config::get('seo.s7'); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="https://www.voiceoverguy.co.uk">
<meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/guy-harris-voiceover.png">
<meta property="og:description" content="<?php echo Config::get('seo.s8'); ?>">

<meta property="fb:app_id" content="128367003916318">
<meta name="p:domain_verify" content="010f4220855ec1039122693b4aef8bc1"/>

<link rel='stylesheet' id='options_typography_Ubuntu-400-css'  href='assets/css/fonts.css' type='text/css' media='all' />

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">


<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />

<link rel="canonical" href="https://www.voiceoverguy.co.uk/privacypolicy" />


     <link href="assets/css/bootstrap.min.css" rel="stylesheet">
     <link href="assets/css/custom.css" rel="stylesheet">
     <link rel="stylesheet" href="assets/css/font-awesome.min.css">
     
	<link rel="stylesheet" type="text/css" href="assets/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
	<link rel="stylesheet" type="text/css" href="assets/fancybox/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
    
	<script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
   
   
    <link rel="stylesheet" type="text/css" href="assets/slick/slick.css">

    
    <link rel="stylesheet" type="text/css" href="assets/nav/assets/css/MegaNavbar.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/nav/assets/css/skins/navbar-inverse.css" title="inverse">
    <link rel="stylesheet" type="text/css" href="assets/nav/assets/css/animation/animation.css" title="inverse">
    
       
  <script type="text/javascript">
function toggleDiv(divId) {
	
	
      $("#"+divId).slideToggle();
   
	
	
  
}
</script>

<script type="text/javascript">
$(function(){
$(".search").keyup(function() 
{ 
var searchid = $(this).val();
var dataString = 'search='+ searchid;
if(searchid!='')
{
    $.ajax({
    type: "POST",
    url: "search/search.php",
    data: dataString,
    cache: false,
    success: function(html)
    {
    $("#result").html(html).show();
    }
    });
}return false;    
});


$(document).mouseup(function (e)
{
	
	  jQuery("#result").fadeOut(); 
});



});
</script>
   <style type="text/css">
   
   
    .content{
        width:450px;
        margin:0 auto;
    }
    #searchid
    {
        width:450px;
        border:solid 1px #999;
        padding:2px;
        font-size:14px;
		margin-bottom:21px;
		
    }
    #result
    {
        position:absolute;
        width:450px;
        padding:10px;
        display:none;
        margin-top:-1px;
        border-top:0px;
        overflow:hidden;
        border:1px #999 solid;
        background-color: white;
		max-height:420px;
		overflow:scroll;
    }
    .show
    {
        padding:3px; 
        
        font-size:10px; 
      
    }
    .show:hover
    {
	
        background:#4c66a4;
        color:#FFF;
        cursor:pointer;
    }
</style>



 
</head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    

<!-- Start Container -->
<div class="container"  >
<!-- Start First Row -->
<div class="row">

<!-- Start Logo-->
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>

    <div class="container">
    
    <?php include("assets/inc/menu.php"); ?>
    
    	
    </div>
    

</div>
<!-- END Logo-->
</div>
<!-- Start Container -->
</div>
<?php
$input = array(Config::get('searchops.s1'), Config::get('searchops.s2'), Config::get('searchops.s3'), Config::get('searchops.s4'), Config::get('searchops.s5'));
$rand_keys = array_rand($input, 2);

?>

<div class="content" >
<input type="text" class="search" id="searchid" placeholder="<?php echo $input[$rand_keys[0]] ?>" autocomplete="off" /><br>
<div id="result" style="z-index:2"></div>
</div>


<div id="parallax">

<div class="container">
<div class="row">
<!-- Start First Text-->
<div class="col-md-12" >
<h1 class="text-center">Privicy Policy</h1>
<p class="text-center">



  <h2>What is this Privacy Policy for?</h2>
        <p>This privacy policy is for this website www.voiceoverguy.co.uk and served by VoiceoverGuy and governs the privacy of its users who choose to use it. </p>
        <p>The policy sets out the different areas where user privacy is concerned and outlines the obligations &amp; requirements of the users, the website and website owners. Furthermore the way this website processes, stores and protects user data and information will also be detailed within this policy.</p>
        <h2>The Website</h2>
        <p>This website and its owners take a proactive approach to user privacy and ensure the necessary steps are taken to protect the privacy of its users  throughout their visiting experience. This website complies to all UK national laws and requirements for user privacy.</p>
        <h4>Use of Cookies</h4>
        <p>This website uses cookies to better the users experience while visiting the website. Where applicable this website uses a cookie control system allowing the user on their first visit to the website to allow or disallow the use of cookies on their computer / device. This complies with recent legislation requirements for websites to obtain explicit consent from users before leaving behind or reading files such as cookies on a user's computer / device.</p>
        <p>Cookies are small files saved to the user's computers hard drive that track, save and store information about the user's interactions and usage of  the website. This allows the website, through its server to provide the users with a tailored experience within this website.<br />
        Users are advised that if they wish to deny the use and saving of cookies from this website on to their computers hard drive they should take necessary steps within their web browsers security settings to block all cookies from this website and its external serving vendors.</p>
        <p>This website uses tracking software to monitor its visitors to better understand how they use it. This software is provided by Google Analytics which uses cookies to track visitor usage. The software will save a cookie to your computers hard drive in order to track and monitor your engagement and usage of the website, but will not store, save or collect personal information. You can read Google's privacy policy here for further information <a href="http://www.google.com/privacy.html" target="_blank">http://www.google.com/privacy.html </a>.<br />
        </p>
        <p>Other cookies may be stored to your computers hard drive by external vendors when this website uses referral programs, sponsored links or adverts. Such cookies are used for conversion and referral tracking and typically expire after 30 days, though some may take longer. No personal information is stored, saved or collected.</p>
        <h2>Contact &amp; Communication</h2>
        <p>Users contacting this website and/or its owners do so at their own discretion and provide any such personal details requested at their own risk. Your personal information is kept private and stored securely until a time it is no longer required or has no use, as detailed in the Data Protection Act 1998. Every effort has been made to ensure a safe and secure form to email submission process but advise users using such form to email processes that they do so at their own risk.<br />
        </p>
        <p>This website and its owners use any information submitted to provide you with further information about the products / services they offer or to assist you in answering any questions or queries you may have submitted. This includes using your details to subscribe you to any email newsletter program the website operates but only if this was made clear to you and your express permission was granted when submitting any form to email process. Or whereby you the consumer have previously purchased from or enquired about purchasing from the company a product or service that the email newsletter relates to. This is by no means an entire list of your user rights in regard to receiving email marketing material. 
        Your details are not passed on to any third parties. </p>
        <h2>Email Newsletter</h2>
        <p>This website operates an email newsletter program, used to inform subscribers about products and services supplied by this website. Users can subscribe through an online automated process should they wish to do so but do so at their own discretion. Some subscriptions may be manually processed through prior written agreement with the user. </p>
        <p>Subscriptions are taken in compliance with UK Spam Laws detailed in the Privacy and Electronic Communications Regulations 2003. All personal details relating to subscriptions are held securely and in accordance with the Data Protection Act 1998. No personal details are passed on to third parties nor shared with companies / people outside of the company that operates this website. Under the Data Protection Act 1998 you may request a copy of personal information held about you by this website's email newsletter program. A small fee will be payable. If you would like a copy of the information held on you please write to the business address at the bottom of this policy.</p>
        <p>Email marketing campaigns published by this website or its owners may contain tracking facilities within the actual email. Subscriber activity is tracked and stored in a database for future analysis and evaluation. Such tracked activity may include; the opening of emails, forwarding of emails, the clicking of links within the email content, times, dates and frequency of activity.<br />
        This information is used to refine future email campaigns and supply the user with more relevant content based around their activity.</p>
        <p>In compliance with UK Spam Laws and the Privacy and Electronic Communications Regulations 2003 subscribers are given the opportunity to un-subscribe at any time through an automated system. This process is detailed at the footer of each email campaign. If an automated un-subscription system is unavailable clear instructions on how to un-subscribe will by detailed instead.</p>
        <h2>External Links</h2>
        <p>Although this website only looks to include quality, safe and relevant external links, users are advised adopt a policy of caution before clicking any external web links mentioned throughout this website. (External links are clickable text  / banner / image links to other websites, similar to; <a href="http://www.craftykingsboutique.co.uk" title="Folded Book Art" target="_blank">Folded Book Art</a> or <a href="http://www.newportholidaycottages.co.uk" title="Cottages in Pembrokeshire" target="_blank">Cottages in Pembrokeshire</a>.)</p>
        <p>The owners of this website cannot guarantee or verify the contents of any externally linked website despite their best efforts. Users should therefore note they click on external links at their own risk and this website and its owners cannot be held liable for any damages or implications caused by visiting any external links mentioned.</p>
        <h2>Adverts and Sponsored Links</h2>
        <p>This website may contain sponsored links and adverts. These will typically be served through our advertising partners, to whom may have detailed privacy policies relating directly to the adverts they serve. </p>
        <p>Clicking on any such adverts will send you to the advertisers website through a referral program which may use cookies and will track the number of referrals sent from this website. This may include the use of cookies which may in turn be saved on your computers hard drive. Users should therefore note they click on sponsored external links at their own risk and this website and its owners cannot be held liable for any damages or implications caused by visiting any external links mentioned.</p>
        <h2>Social Media Platforms</h2>
        <p>Communication, engagement and actions taken through external social media platforms that this website and its owners participate on are custom to the terms and conditions as well as the privacy policies held with each social media platform respectively. </p>
        <p>Users are advised to use social media platforms wisely and communicate / engage upon them with due care and caution in regard to their own privacy and personal details. This website nor its owners will ever ask for personal or sensitive information through social media platforms and encourage users wishing to discuss sensitive details to contact them through primary communication channels such as by telephone or email.</p>
        <p>This website may use social sharing buttons which help share web content directly from web pages to the social media platform in question. Users are advised before using such social sharing buttons that they do so at their own discretion and note that the social media platform may track and save your request to share a web page respectively through your social media platform account.</p>
        <h2>Shortened Links in Social Media</h2>
        <p>This website and its owners through their social media platform accounts may share web links to relevant web pages. By default some social media platforms shorten lengthy urls https://www.voiceoverguy.co.uk (this is an example: http://bit.ly/zyVUBo). <br />
        </p>
        <p>Users are advised to take caution and good judgement before clicking any shortened urls published on social media platforms by this website and its owners. Despite the best efforts to ensure only genuine urls are published many social media platforms are prone to spam and hacking and therefore this website and its owners cannot be held liable for any damages or implications caused by visiting any shortened links.</p>
        <h2>Resources &amp; Further Information</h2>
        <ul>
			<li><a href="http://www.legislation.gov.uk/ukpga/1998/29/contents" target="_blank">Data Protection Act 1998</a></li>
			<li><a href="http://www.legislation.gov.uk/uksi/2003/2426/contents/made" target="_blank">Privacy and Electronic Communications Regulations 2003</a></li>
			<li><a href="http://www.ico.gov.uk/for_organisations/privacy_and_electronic_communications/the_guide.aspx" target="_blank">Privacy and Electronic Communications Regulations 2003 - The Guide</a></li>
			
        </ul>
        <p>1st Feb 2017 Edited &amp; customised by: Guy Harris - VoiceoverGuy</p>





</p>

</div>
<!-- END First Row -->
</div>





</div>

<?php include("assets/inc/applinks.php"); ?>



<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>

 


   
<?php include("assets/inc/socials.php"); ?>
<br> </div>

</div></div></div>
<!-- End Footer-->


<?php include("assets/inc/footerhome.php"); ?>

   
</body>
</html>