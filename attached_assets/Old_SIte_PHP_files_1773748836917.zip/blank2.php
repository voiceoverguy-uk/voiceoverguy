<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

      <title><?php echo Config::get('seo13.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo13.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="<?php echo Config::get('seo13.s3'); ?>" />

<meta name="twitter:description" content="<?php echo Config::get('seo13.s2'); ?>" />

<meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/football-commentator-voice-og.jpg" />

<meta name="Robots" content="index, follow">

 




<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />



<link rel="canonical" href="https://www.voiceoverguy.co.uk/football-commentator-voice" /> 

<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	
	
	<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Guy Harris - Football Commentator Voice",
  "image": "https://www.voiceoverguy.co.uk/assets/images/football-commentator-voice-og.jpg",
  "description": "Guy Harris is a British voiceover artist known for his football commentator-style voice, used by BBC, Netflix, and major sports brands.",
  "url": "https://www.voiceoverguy.co.uk/football-commentator-voice",
  "telephone": "+44 113 123 4567",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Wakefield",
    "addressRegion": "West Yorkshire",
    "postalCode": "WF1",
    "addressCountry": "GB"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "53.6829",
    "longitude": "-1.4964"
  },
  "priceRange": "£100 - £5000",
  "openingHours": "Mo-Sa 07:00-21:00",
  "sameAs": [
    "https://www.linkedin.com/in/voiceoverguy/",
    "https://www.youtube.com/user/voiceoverguyharris"
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can I hire Guy Harris for a football commentator-style voiceover?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, Guy Harris is available to voice football-style commentaries for TV, radio, promos, and comedy spots. His voice is trusted by major broadcasters and sports clubs."
      }
    },
    {
      "@type": "Question",
      "name": "Is the voiceover studio located in Wakefield, West Yorkshire?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, Guy’s voiceover studio is based in Wakefield, West Yorkshire and offers remote and in-person directed sessions."
      }
    },
    {
      "@type": "Question",
      "name": "What’s included in a football commentator voiceover session?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Voiceover sessions include a live directed call, multiple takes, and delivery in your preferred format. Fast turnaround and professional audio are guaranteed."
      }
    }
  ]
}
</script>
	

	   <style>
  

    #copyBtn {
      position: absolute;
      bottom: -27px;
      right: 40px;
      font-size: 1.8rem;
      background-color: transparent;
      border: none;
      color: #999999;
      box-shadow: none;
    }
    #copyBtn:hover {
      color: #ffffff;
    }

    /* Padding and margin overrides for info-box and demo-wrapper */
    .info-box {
      padding-top: 15px;
      padding-bottom: 20px;
    }

    .info-box h3 {
      margin-top: 0;
      margin-bottom: 10px;
    }

    .info-box ul {
      margin-top: 10px;
      margin-bottom: 10px;
    }

    .demo-wrapper {
      margin-top: 10px;
    }
  </style>
	  <link rel="stylesheet" href="/attenborough-voice/style-3.css">
	</head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" style="text-align: center" >


<!--
TEXT HERE
-->

    <h1>David Attenborough Script Generator</h1>
    <h2 style="margin-top: 10px;">A Fun, Free Attenborough-Style Script Generator by UK Voiceover Artist Guy Harris</h2>
    <p class="subtitle">Type a short scenario. Watch it transform into an Attenborough-style script.<br><a href="/david-attenborough-voice" title="David Attenborough Voiceover">get the real VoiceoverGuy</a> to voice it and make it sound awesome.</p>

    <div class="textarea-wrapper">
      <textarea id="userInput" placeholder="Describe a natural moment or quirky wildlife scene..." style="height: 60px;"></textarea>
		<br>
      <span id="wordCount" class="word-count-bottom">0/25 words</span>
      <div id="popup" class="popup">25 words max! 🛑</div>
    </div>

    <button id="generateBtn">🎙️ Generate</button>

    <div id="output" style=" position: relative;
  width: 100%;
  max-width: 800px;" > 
      <div id="outputContent"><span class="text-muted">Your story will appear here...</span></div>
      <button id="copyBtn" class="hidden" style="display: none !important;" title="Copy Script">📋</button>
    </div>

    <button id="newScenarioBtn" class="hidden">🔄 New Scenario</button>

    <div class="info-box">
    <p>🎬 The UK's Leading David Attenborough Voiceover Artist</p>
    <p>Guy Harris - Renowned for his distinctive narration style as <strong> Attenborough </strong></p>
    <ul>
      <li><span class="star">⭐</span> Direct the session and get your script read right 1st time!</li>
      <li><span class="star">⭐</span> Receive a broadcast quality Wav file polished and ready to work with!</li>
      <li><span class="star">⭐</span> Listen to Guy’s David Attenborough demo:</li>
    </ul>
    <div class="demo-wrapper">
      <div id="demoPlayerWrapper">
        <audio id="realGuyDemo" controls>
          <source src="/attenborough-voice/assets/audio/david-attenborough-demo-25-guy-harris.mp3" type="audio/mpeg">
          Your browser does not support the audio element.
        </audio>
<br><a href="https://www.voiceoverguy.co.uk/contact-guy" target="_blank" rel="noopener noreferrer" style="color: #fff; text-decoration: underline;">
  Book <span style="color:#d42027;">Guy</span> Now!
</a>
      </div>
    </div>
  </div>
  

  <script src="/attenborough-voice/script-2.js"></script>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "AudioObject",
    "name": "David Attenborough Demo – Guy Harris",
    "description": "A short David Attenborough-style demo voiced by Guy Harris.",
    "author": {
      "@type": "Person",
      "name": "Guy Harris",
      "url": "https://www.voiceoverguy.co.uk"
    },
    "thumbnailUrl": "https://www.voiceoverguy.co.uk/assets/images/attenborough-voice-og.jpg",
    "contentUrl": "https://www.voiceoverguy.co.uk/attenborough-voice/assets/audio/david-attenborough-demo-25-guy-harris.mp3",
    "encodingFormat": "audio/mpeg",
    "duration": "PT1M26S",
    "uploadDate": "2025-10-04",
    "inLanguage": "en-GB",
    "isAccessibleForFree": true,
    "keywords": "Attenborough, voiceover, demo, Guy Harris",
    "publisher": {
      "@type": "Organization",
      "name": "VoiceoverGuy",
      "url": "https://www.voiceoverguy.co.uk"
    }
  }
  </script>
</body>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "What is the David Attenborough Script Generator?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "It's a fun tool that turns your scene into a nature-style voiceover script using AI. You can then get professional voice actor Guy Harris to voice it like Attenborough."
        }
      },
      {
        "@type": "Question",
        "name": "Can I get the script voiced by a real person?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Yes! Once your script is generated, you can book Guy Harris – the UK's leading Attenborough-style voiceover artist – to narrate it for you."
        }
      },
      {
        "@type": "Question",
        "name": "Is this just for fun or for commercial use?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "The generator is free to play with, but you can commission a polished, studio-quality recording for professional projects."
        }
      }
    ]
  }
  </script>
	
	
</div>
</div>
</div>
</div>








<div id="parallax">
<div class="container">





<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

<?php include("assets/inc/footer.php"); ?>
    
</body>
</html>