<?php
    $rssfeed = '<?xml version="1.0" encoding="UTF-8"?>';
    $rssfeed .= '<rss version="2.0">';
    $rssfeed .= '<channel>';


$objConnect = mysql_connect("localhost","cl10-vox","earwax69") or die(mysql_error());
$objDB = mysql_select_db("cl10-vox");

$order_by = "ORDER BY id DESC"; // Default order

$strSQL = "SELECT * FROM messages2 ORDER BY theorder ASC";
$objQuery = mysql_query($strSQL) or die ("Error Query [".$strSQL."]");


while($objResult = mysql_fetch_array($objQuery))
{
        $rssfeed .= '<item>';
        $rssfeed .= '<title>'.$objResult["title"].'</title>';
        $rssfeed .= '<description>'.$objResult["info"].'</description>';
        $rssfeed .= '<link>'.$objResult["audio"].'</link>';
        $rssfeed .= '<pubDate></pubDate>';
        $rssfeed .= '</item>';

}
    $rssfeed .= '</channel>';
    $rssfeed .= '</rss>';
    echo $rssfeed;




?>


    