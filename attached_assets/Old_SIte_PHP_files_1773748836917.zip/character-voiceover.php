<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo11.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo11.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seo11.s2'); ?>">

<meta property="og:title" content="Character Voiceover Artist | Guy Harris">
<meta property="og:description" content="From Boom Beach to Minecraft, Guy Harris is the voice of over 100 characters including Disney, Alton Towers & Thomas the Tank Engine. Hear the Big Six & more.">
<meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/character-voiceover-og.jpg">
<meta property="og:url" content="https://www.voiceoverguy.co.uk/character-voiceover">
<meta property="og:type" content="profile">

<meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/character-voiceover-og.jpg">

<meta name="Robots" content="index, follow">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

  
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/character-voiceover" /> 
<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	
		  	<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#webpage",
  "url": "https://www.voiceoverguy.co.uk/character-voiceover",
  "name": "Character Voiceover – Voice Creation by Guy Harris",
  "description": "Character voiceovers by Guy Harris. From gaming villains to cartoon heroes, discover unique voices for apps, games, animation and comedy. Listen to the showreels."
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#breadcrumb",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "item": {
        "@id": "https://www.voiceoverguy.co.uk/",
        "name": "Home"
      }
    },
    {
      "@type": "ListItem",
      "position": 2,
      "item": {
        "@id": "https://www.voiceoverguy.co.uk/character-voiceover",
        "name": "Character Voiceover"
      }
    }
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Person",
  "@id": "https://www.voiceoverguy.co.uk/#guyharris",
  "name": "Guy Harris",
  "url": "https://www.voiceoverguy.co.uk",
  "image": "https://www.voiceoverguy.co.uk/images/guy-harris-profile.jpg",
  "jobTitle": "British Male Voiceover Artist",
  "sameAs": [
    "https://www.voiceoverguy.co.uk",
    "https://www.voiceoverguy.co.uk/voiceover-cartoons"
  ],
  "description": "Guy Harris is a versatile British male voiceover artist voicing over 100 characters for games, apps, animation and global media."
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Service",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#service",
  "serviceType": "Character Voiceover",
  "provider": {
    "@id": "https://www.voiceoverguy.co.uk/#guyharris"
  },
  "url": "https://www.voiceoverguy.co.uk/character-voiceover",
  "description": "Professional character voiceover for games, apps, animation, comedy, commercials and digital media by UK voice artist Guy Harris."
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "AudioObject",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#audio",
  "name": "Character Voiceover Showreel – Guy Harris",
  "description": "A 1 minute 44 second character voice compilation featuring gaming voices, cartoon styles and comedic characters.",
  "url": "https://www.voiceoverguy.co.uk/assets/audio/guy-harris-voiceoverguy-character-showreel.mp3",
  "contentUrl": "https://www.voiceoverguy.co.uk/assets/audio/guy-harris-voiceoverguy-character-showreel.mp3",
  "encodingFormat": "audio/mpeg",
  "uploadDate": "2025-03-20T10:00:00+00:00",
  "duration": "PT1M44S"
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#video1",
  "name": "Character Voiceover Showreel 2025 | Guy Harris – Games, Cartoons & Crazy Characters",
  "description": "A fast-paced compilation of gaming voices, cartoon characters, villains, heroes, accents and comedy vocals by Guy Harris.",
  "thumbnailUrl": "https://i.ytimg.com/vi/Ad85PPvSfbc/maxresdefault.jpg",
  "uploadDate": "2025-03-20T10:00:00+00:00",
  "url": "https://www.youtube.com/watch?v=Ad85PPvSfbc",
  "embedUrl": "https://www.youtube.com/embed/Ad85PPvSfbc"
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#video2",
  "name": "Guy Harris Character Singing – Wonderful World (Multiple Voices | HD)",
  "description": "Guy Harris sings 'Wonderful World' using multiple character voices with visual pop-up characters.",
  "thumbnailUrl": "https://i.ytimg.com/vi/k7DZFWnOcvo/maxresdefault.jpg",
  "uploadDate": "2025-03-20T10:00:00+00:00",
  "url": "https://www.youtube.com/watch?v=k7DZFWnOcvo",
  "embedUrl": "https://www.youtube.com/embed/k7DZFWnOcvo"
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#faq",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What character voices has Guy Harris performed?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy Harris has voiced over 100 characters for games, apps, animation, radio and online media including Boom Beach, Minecraft, Clash of Clans, Thomas & Friends, Joker-style voices and more."
      }
    },
    {
      "@type": "Question",
      "name": "Can I book Guy Harris for a character voiceover?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Guy Harris is available for bespoke character voiceovers via Zoom, Cleanfeed or Teams, and can work with reference clips or custom direction."
      }
    },
    {
      "@type": "Question",
      "name": "Where can I find a character voiceover?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy Harris is one of the UK's most in-demand character voiceover artists. With over 25 years' experience in radio, TV, films and social media content, his voice has been heard in more places than you can imagine."
      }
    },
    {
      "@type": "Question",
      "name": "Who is the voice of the trains in Thomas the Tank Engine?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy Harris is the voice of Winston, Salty and Troublesome Tanker 2 in Thomas & Friends: All Engines Go, and also voices other characters such as Mr Messy and Mr Funny in the Mr Men series."
      }
    },
    {
      "@type": "Question",
      "name": "Who is a great voice for Santa or Father Christmas?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy Harris is widely considered the Voice of Santa thanks to his work for BBC Radio 1, BBC Radio 2, the Heart Network, Asda, Tesco, ITV, Butlins, Capital Radio and more, delivering a traditional, jovial British Father Christmas performance."
      }
    }
  ]
}
</script>
  
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": "https://www.voiceoverguy.co.uk/#website",
  "url": "https://www.voiceoverguy.co.uk/",
  "name": "VoiceoverGuy",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://www.voiceoverguy.co.uk/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>
	<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Service",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#rating",
  "serviceType": "Character Voiceover",
  "provider": {
    "@id": "https://www.voiceoverguy.co.uk/#guyharris"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "5.0",
    "ratingCount": "117",
    "bestRating": "5",
    "worstRating": "1"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "SpeakableSpecification",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#speakable",
  "cssSelector": [
    "h1",
    "h2"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "OfferCatalog",
  "@id": "https://www.voiceoverguy.co.uk/character-voiceover/#offercatalog",
  "name": "Character Voiceover Services",
  "itemListElement": [
    {
      "@type": "Offer",
      "itemOffered": {
        "@type": "Service",
        "name": "Gaming Character Voice",
        "provider": { "@id": "https://www.voiceoverguy.co.uk/#guyharris" }
      }
    },
    {
      "@type": "Offer",
      "itemOffered": {
        "@type": "Service",
        "name": "Cartoon / Animation Character Voice",
        "provider": { "@id": "https://www.voiceoverguy.co.uk/#guyharris" }
      }
    },
    {
      "@type": "Offer",
      "itemOffered": {
        "@type": "Service",
        "name": "Comedy & Exaggerated Voices",
        "provider": { "@id": "https://www.voiceoverguy.co.uk/#guyharris" }
      }
    }
  ]
}
</script>
	</head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >

<?php echo html_entity_decode(Config::get('seo11.s3')); ?>

</div>
</div>
</div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12" style="background-color:#9E0100; padding-top:20px; padding-bottom:20px;">
      <div class="container">

        <div id="dynamic-review-block" style="background:#fff3f3;border:3px solid #cc0000;padding:25px;margin-bottom:25px;border-radius:10px;text-align:center;box-shadow:0 0 12px rgba(200,0,0,0.25);">
          <h2 id="review-title" style="margin-top:0;font-size:30px;color:#b30000;font-weight:800;">
            🎤 Rated 5.0 <span style="color:#f5c518;">★★★★★</span> by <span id="review-count">117</span> Happy Clients
          </h2>
          <p style="font-size:18px;color:#333;margin-bottom:18px;">
            Trusted by global brands around the world daily.
          </p>
          <a href="https://www.google.com/search?q=Guy+Harris+Voiceover+Reviews"
             target="_blank"
             rel="noopener"
             style="display:inline-block;background:#cc0000;color:white;padding:12px 28px;border-radius:6px;font-weight:700;font-size:17px;text-decoration:none;">
             ★ Read Google Reviews
          </a>
        </div>

        <script>
          fetch('/api/get-reviews.php')
            .then(r => r.json())
            .then(data => {
              if (data.count) {
                document.getElementById('review-count').textContent = data.count;
              }
            })
            .catch(err => console.error('Review API error:', err));
        </script>

      </div>
    </div>
  </div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">

<iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/1219509&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true" width="100%" height="415" frameborder="no" scrolling="no"></iframe>
</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">
<div class="row">

<div class="col-md-6" >

<?php echo html_entity_decode(Config::get('seo11.s4')); ?>
<h2>Voicing Characters for Games, Animation & Comedy</h2>
</div>

<div class="col-md-6" >
<br>

<?php
$string2 = Config::get('seo11.s20');
if ( $string2 == "1" ){
?>

<iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo11.s7'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo11.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo11.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo11.s8'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo11.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>

<div class="col-md-6" >
<h2>Clients from Boom Beach to Disney</h2>
<?php echo html_entity_decode(Config::get('seo11.s5')); ?>
</div>


</div>

<div class="row">

<div class="col-md-6" >
<h2>Big Six Signature Voices – And Custom Creations</h2>
<?php echo html_entity_decode(Config::get('seo11.s6')); ?>
</div>

<div class="col-md-6" >
<br>
<a href="voiceover-cartoons" title="Guy Harris - Character Voiceover" ><img alt="Guy Harris - Character Voiceover" title="Guy Harris - Character Voiceover" class="img-responsive"   src="assets/images/cartoons/Voiceover-Cartoon-Darth-Vader.jpg" /></a>

</div>


</div>







<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Container-->
<div class="container" style="margin-top:40px; margin-bottom:40px;">
  <div style="background:#fff3f3;border:3px solid #cc0000;padding:25px;border-radius:10px;box-shadow:0 0 12px rgba(200,0,0,0.25);">
    <h2 style="margin-top:0;font-size:26px;color:#b30000;font-weight:800;">
      Explore More Character Work
    </h2>
    <p style="font-size:17px;line-height:1.55em;">
      Dive deeper into Guy’s most popular character performances across TV, games and animation:
    </p>
    <ul style="font-size:17px;line-height:1.6em;">
      <li><a href="https://www.voiceoverguy.co.uk/thomas-the-tank-engine-voice-of-salty">Salty – Thomas & Friends</a></li>
      <li><a href="https://www.voiceoverguy.co.uk/thomas-the-tank-engine-voice-of-winston">Winston – Thomas & Friends</a></li>
      <li><a href="https://www.voiceoverguy.co.uk/star-wars-character-voices">Star Wars Character Voices</a></li>
      <li><a href="https://www.voiceoverguy.co.uk/clash-of-clans-goblins-voiceover">Goblin Voice – Clash of Clans</a></li>
      <li><a href="https://www.voiceoverguy.co.uk/playmobil-pirate-voice">Pirate Voice</a></li>
      <li><a href="https://www.voiceoverguy.co.uk/joker-voice">Joker Voice</a></li>
      <li><a href="https://www.voiceoverguy.co.uk/pathe-news-jack-fm">Pathé News Voice</a></li>
    </ul>
  </div>
</div>

<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

  <?php include("assets/inc/footer.php"); ?>
</body>
</html>