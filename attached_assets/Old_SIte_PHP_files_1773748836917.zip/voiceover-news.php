<?php require_once 'guyadmin/app/init.php';?>



<?php
error_reporting(0); // Turn off all error reporting
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
 

    <title><?php echo Config::get('seoBlogHome.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seoBlogHome.s2'); ?>">

    <meta name="keywords" content="Voiceover news, Guy Harris blog, UK voiceover blog, British voice actor updates, voiceover campaigns, character voices, voice acting tips">

    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="Voiceover News & Blog – Guy Harris" />
    <meta property="og:description" content="<?php echo Config::get('seoBlogHome.s2'); ?>" />
    <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/og-image.jpg" />
    <meta property="og:url" content="https://www.voiceoverguy.co.uk/voiceover-news" />
    <meta property="og:type" content="website" />

    <!-- Twitter Card Update -->
    <meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/og-image.jpg" />
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seoBlogHome.s2'); ?>">

<meta name="Robots" content="index, follow">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

 
<link rel="preload" as="image" href="https://www.voiceoverguy.co.uk/assets/images/og-image.jpg" />
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/voiceover-news" /> 
<link href="assets/css/all.css" rel="stylesheet">
<script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>

<!--
<script type="text/javascript" src="https://www.voiceoverguy.co.uk/searchjquery-1.8.0.min.js"></script>
-->

<script type="text/javascript">
$(function(){
$(".search").keyup(function() 
{ 
var searchid = $(this).val();
var dataString = 'search='+ searchid;
if(searchid!='')
{
    $.ajax({
    type: "POST",
    url: "search/search.php",
    data: dataString,
    cache: false,
    success: function(html)
    {
    $("#result").html(html).show();
	
	
	
    }
    });
}return false;    
});


$(document).mouseup(function (e)
{
	
	  jQuery("#result").fadeOut(); 
});




});
</script>
    <style type="text/css">
   
   
    .content{
		
        width:100%;
		max-width:650px;
        margin:0 auto;
    }
    #searchid
    {
		
        width:100%;
		height:50px;
        border:solid 1px #999;
        padding:20px;
        font-size:14px;
		margin-bottom:21px;
		
    }
    #result
    {
        position:absolute;
		max-width: 620px;
      
      
 
        margin: 0 auto;
        left: 0;
        right: 0;
		
         padding-top:10px;
        padding-left:10px;
        display:none;
     
        border-top:0px;
        overflow:hidden;
        border:1px #999 solid;
        background-color: white;
		max-height:460px;
		overflow:scroll;
	
	
       
    }
    .show
    {
		
		
	
     
      
    }
	
    }
    .show:hover
    {
	
        background:#4c66a4;
        color:#FFF;
        cursor:pointer;
    }
</style>
	  
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Blog",
      "name": "Voiceover News & Blog",
      "url": "https://www.voiceoverguy.co.uk/voiceover-news",
      "description": "The latest news and blog updates from British male voiceover Guy Harris, including character projects and seasonal campaigns."
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      "name": "Voiceover News & Blog – Guy Harris",
      "description": "Explore voiceover news and blog posts from British voiceover artist Guy Harris. Discover seasonal campaigns, client work, and voice acting insights.",
      "url": "https://www.voiceoverguy.co.uk/voiceover-news",
      "image": "https://www.voiceoverguy.co.uk/assets/images/og-image.jpg"
    }
    </script>

    </head>

<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>
</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">
<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
</div></div></div>

<?php
	//
//$input = array(Config::get('searchops.s1'), Config::get('searchops.s2'), Config::get('searchops.s3'), Config::get('searchops.s4'), Config::get('searchops.s5'));
//$rand_keys = array_rand($input, 2);

?>




   














<div id="parallax">
<div class="container">



<div class="row">
	<h1 style="text-align: center; font-weight: bold">Voiceover News & Blog – Guy Harris | British Voiceover Artist</h1>
<br>
	
	<div style="text-align:center; ">
		
		<!--
<input  type="text" class="search" id="searchid" style="width:50%; height:47px;border-style: solid;
   
     border-width: 1px;
    border-color: black; padding-left:10px " placeholder="So... what are you looking for?" autocomplete="off" />
    
-->

<div id="result" style="z-index:2"></div>

	</div>
	

	
	<?php
  
  $servername = "localhost";
  $username = "cl10-nreblog";
  $password = "earwax69";
  $databasename = "cl10-nreblog";
  $conn = new mysqli($servername,
    $username, $password, $databasename);
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $query = "SELECT * FROM messages2 WHERE rating = '5' ORDER BY rand()";
	
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        while($row = $result->fetch_assoc())
        {
			?>
		
<div class="col-md-4" style=" min-height:350px" >


<p style="font-size:18px"><strong><?php echo $row['page_title']; ?></strong></p><?php if (Auth::userCan('list_users')): ?>
<a href="https://www.voiceoverguy.co.uk/guyadmin/admin.php?page=options-blog-edit&theid=<?php echo $row['id']; ?>" target="_blank"> Edit this Blog</a>

<?php endif ?>

<a href="<?php echo $row['url']; ?>" title="<?php echo $row['page_title']; ?>">
<div class="effect1">
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['page_title']; ?>" class="img-responsive imageborder"   src="assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</a>



<p><?php echo $row['hometext']; ?></p>




      </div>
	
	<?

			
		}
    } 
    else {
        echo "0 results";
    }
  
   $conn->close();
  
?>
	
	
	
	
	




	
	
	
	
	
	
	
	
	
	
	


	
	
	
		
	<?php
  
  $servername = "localhost";
  $username = "cl10-nreblog";
  $password = "earwax69";
  $databasename = "cl10-nreblog";
  $conn = new mysqli($servername,
    $username, $password, $databasename);
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $query = "SELECT * FROM messages2 WHERE rating = '3' ORDER BY rand()";
	
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        while($row = $result->fetch_assoc())
        {
			?>
		
<div class="col-md-4" style=" min-height:350px" >


<p style="font-size:18px"><strong><?php echo $row['page_title']; ?></strong></p><?php if (Auth::userCan('list_users')): ?>
<a href="https://www.voiceoverguy.co.uk/guyadmin/admin.php?page=options-blog-edit&theid=<?php echo $row['id']; ?>" target="_blank"> Edit this Blog</a>

<?php endif ?>

<a href="<?php echo $row['url']; ?>" title="<?php echo $row['page_title']; ?>">
<div class="effect1">
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['page_title']; ?>" class="img-responsive imageborder"   src="assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</a>



<p><?php echo $row['hometext']; ?></p>




      </div>
	
	<?

			
		}
    } 
    else {
        echo "0 results";
    }
  
   $conn->close();
  
?>
	





	
	<?php
  
  $servername = "localhost";
  $username = "cl10-nreblog";
  $password = "earwax69";
  $databasename = "cl10-nreblog";
  $conn = new mysqli($servername,
    $username, $password, $databasename);
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $query = "SELECT * FROM messages2 WHERE rating = '0' ORDER BY rand()";
	
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        while($row = $result->fetch_assoc())
        {
			?>
		
<div class="col-md-4" style=" min-height:350px" >


<p style="font-size:18px"><strong><?php echo $row['page_title']; ?></strong></p><?php if (Auth::userCan('list_users')): ?>
<a href="https://www.voiceoverguy.co.uk/guyadmin/admin.php?page=options-blog-edit&theid=<?php echo $row['id']; ?>" target="_blank"> Edit this Blog</a>

<?php endif ?>

<a href="<?php echo $row['url']; ?>" title="<?php echo $row['page_title']; ?>">
<div class="effect1">
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['page_title']; ?>" class="img-responsive imageborder"   src="assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</a>



<p><?php echo $row['hometext']; ?></p>




      </div>
	
	<?

			
		}
    } 
    else {
        echo "0 results";
    }
  
   $conn->close();
  
?>
	
	

	
	

</div>
<div style="text-align:center">




</div>

	

<?php include("assets/inc/applinks.php"); ?>   

</div>


<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>

</div><?php include("assets/inc/footer.php"); ?>
    
</body>
</html>

