<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo23.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo23.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seo23.s2'); ?>">


<meta name="Robots" content="index, follow">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

 
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />



<link rel="canonical" href="https://www.voiceoverguy.co.uk/appletv" /> 
<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script></head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" style="text-align:center" >






<img alt="App Development" title="App Development" class="img-responsive"   src="assets/images/apple-tv-development.png" />

<?php echo html_entity_decode(Config::get('seo23.s3')); ?>


 <section id="pricePlans">
		<ul  id="plans">
			<li style=" list-style-type: none;" class="plan">
				<ul  class="planContainer">
					<li class="title"><h2>tvOS App</h2></li>
					<li class="price"><p>£399</p></li>
					<li>
						<ul class="options">
							<li>tvOS <span>App</span></li>
							<li>&nbsp;</li>
                            <li>&nbsp;</li>
                            <li>&nbsp;</li>
                            <li>&nbsp;</li>
                            <li>&nbsp;</li>
						</ul>
					</li>
					<li class="button"><a href="mailto:appletv@voiceoverguy.co.uk">Purchase</a></li>
				</ul>
			</li>
            
            <li style=" list-style-type: none;" class="plan">
				<ul  class="planContainer">
					<li class="title"><h2>iOS & tvOS</h2></li>
					<li class="price"><p>£499</p></li>
					<li>
						<ul class="options">
                        	
							<li>iPhone <span>App</span></li>
							<li>iPad <span>App</span></li>
                           
                             <li>tvOS <span>App</span></li>
                                 <li> &nbsp;</li>
							
                            <li>&nbsp;</li>
                            <li>&nbsp;</li>
						</ul>
					</li>
					<li class="button"><a href="mailto:appletv@voiceoverguy.co.uk">Purchase</a></li>
				</ul>
			</li>

			<li style=" list-style-type: none;" class="plan">
				<ul class="planContainer">
					<li class="title"><h2 class="bestPlanTitle">All Apple</h2></li>
					<li class="price"><p class="bestPlanPrice">£699<span style="font-style:italic">/Best seller</span></p></li>
					<li>
						<ul class="options">
							<li>tvOS <span>App</span></li>
							<li>iPhone <span>App</span></li>
							<li>iPad <span>App</span></li>
                            <li>Mac <span>App</span></li>
                             <li>&nbsp;</li>
                            <li>&nbsp;</li>
                            
                         
						</ul>
					</li>
					<li class="button"><a class="bestPlanButton" href="mailto:appletv@voiceoverguy.co.uk">Purchase</a></li>
				</ul>
			</li>

			<li style=" list-style-type: none;" class="plan">
				<ul class="planContainer">
					<li class="title"><h2>Full Monty</h2></li>
					<li class="price"><p>£749</p></li>
					<li>
						<ul class="options">
							<li>tvOS <span>App</span></li>
							<li>iPhone <span>App</span></li>
							<li>iPad <span>App</span></li>
                            <li>Mac <span>App</span></li>
                                <li>Android <span>App</span></li>
                                    <li>Amazon <span>App</span></li>
						</ul>
					</li>
					<li class="button"><a href="mailto:appletv@voiceoverguy.co.uk">Purchase</a></li>
				</ul>
			</li>

			
		</ul> <!-- End ul#plans -->


	</section>

</div>
</div>
</div>
</div>









<div id="parallax">
<div class="container">



<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo23.s4')); ?>


</div>

<div class="col-md-6" >
<br>
<img alt="Guy Harris - App Development" title="Guy Harris - App Development" class="img-responsive"   src="assets/images/santa-radio2.jpg" />
</div>


</div>

<div class="row">

<div class="col-md-6" >
<br>
<img alt="Guy Harris - App Development" title="Guy Harris - App Development" class="img-responsive"   src="assets/images/santa-radio1.jpg" />
</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo23.s5')); ?>


</div>


</div>







<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

 <?php include("assets/inc/footer.php"); ?>
 
</body>
</html>