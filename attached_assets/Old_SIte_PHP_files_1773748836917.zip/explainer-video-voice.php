<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo html_entity_decode(Config::get('seo19.s1', 'Explainer Video Voiceover | Guy Harris – Trusted British Voice Artist')); ?></title>

    <meta name="description" content="<?php echo Config::get('seo19.s2', 'Trusted British explainer voiceover artist. Used by Microsoft, Renault, NHS, DPD, Vodafone & more. Warm, clear, friendly delivery perfect for web, social & business explainers.'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Explainer Video Voiceover | Guy Harris – Trusted British Voice Artist">
<meta name="twitter:description" content="Trusted British explainer voiceover artist. Used by Microsoft, Renault, NHS, DPD, Vodafone & more. Warm, clear, friendly delivery perfect for web, social & business explainers.">
<meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/explainer-video-voice-og.jpg">
<meta name="Robots" content="index, follow">

<meta property="og:title" content="Explainer Video Voiceover | Guy Harris – Trusted British Voice Artist" />
<meta property="og:description" content="Trusted British explainer voiceover artist. Used by Microsoft, Renault, NHS, DPD, Vodafone & more. Warm, clear, friendly delivery perfect for web, social & business explainers." />
<meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/explainer-video-voice-og.jpg" />
<meta property="og:url" content="https://www.voiceoverguy.co.uk/explainer-video-voice" />
<meta property="og:type" content="profile" />

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">


<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/explainer-video-voice" /> 

<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	
	
		<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Guy Harris Voiceover Studio",
  "image": "https://www.voiceoverguy.co.uk/assets/images/guy-harris-voiceover.png",
  "url": "https://www.voiceoverguy.co.uk/explainer-video-voice",
  "telephone": "+44-7973-420177",
  "priceRange": "£100 - £5000",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Wakefield",
    "addressRegion": "West Yorkshire",
    "addressCountry": "GB"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "53.683",
    "longitude": "-1.505"
  },
  "openingHours": [
    "Mo-Sa 07:00-21:00"
  ],
  "sameAs": [
    "https://www.voiceoverguy.co.uk",
    "https://www.linkedin.com/in/voiceoverguy/"
  ],
  "description": "Guy Harris is a trusted British voiceover artist providing explainer video voiceovers for brands like Microsoft, Renault, NHS and DPD. Studio based in Wakefield, West Yorkshire."
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Where is your voiceover studio based?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The studio is based in Wakefield, West Yorkshire, with excellent transport links to Leeds, Manchester and London. Remote direction is available worldwide."
      }
    },
    {
      "@type": "Question",
      "name": "Can I hire your studio for explainer video voiceovers?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, the studio is available for hire and ideal for explainer voiceovers, eLearning, corporate videos, and more. Get in touch to check availability."
      }
    },
    {
      "@type": "Question",
      "name": "Do you offer remote live direction?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, Guy can be directed live via Source Connect, Cleanfeed, Zoom, or phone, offering HD-quality remote sessions for clients globally."
      }
    }
  ]
}
</script>
	
	</head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >

<?php echo html_entity_decode(Config::get('seo19.s3')); ?>
<h2>British Explainer Voice for Web, Social Media & Corporate Videos</h2>

</div>
</div>
</div>

<div class="bar"></div>

<div class="container">
<div class="row">



<div class="col-md-4" >
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo19.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="201" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php echo html_entity_decode(Config::get('seo19.s4')); ?>
</div>


<div class="col-md-4" >
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo19.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="201" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php echo html_entity_decode(Config::get('seo19.s5')); ?>
</div>



<div class="col-md-4" >
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo19.s9'); ?>?title=0&amp;byline=0&amp;portrait=0" height="201" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php echo html_entity_decode(Config::get('seo19.s6')); ?>
</div>


</div>

<div class="row">



<div class="col-md-4" >
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo19.s11'); ?>?title=0&amp;byline=0&amp;portrait=0" height="201" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php echo html_entity_decode(Config::get('seo19.s10')); ?>
</div>


<div class="col-md-4" >
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo19.s13'); ?>?title=0&amp;byline=0&amp;portrait=0" height="201" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php echo html_entity_decode(Config::get('seo19.s12')); ?>
</div>



<div class="col-md-4" >
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo19.s15'); ?>?title=0&amp;byline=0&amp;portrait=0" height="201" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php echo html_entity_decode(Config::get('seo19.s14')); ?>
</div>


</div>

<div class="bar"></div>
<div class="row">
<div class="col-md-12" >

<h3>Trusted by Global Brands like Microsoft, NHS, Vodafone & Booking.com</h3>
<?php echo html_entity_decode(Config::get('seo19.s16')); ?>


</div>
</div>




<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

<?php include("assets/inc/footer.php"); ?>
    
</body>
</html>