<?php require_once 'guyadmin/app/init.php';?>
<?php
error_reporting(0); // Turn off all error reporting
?>



<?php
$mysql_host     = 'localhost';   # use your mysql host host (ussually 127.0.0.1)
$mysql_user     = 'cl10-nreblog';            # use your mysql user
$mysql_pass     = 'earwax69';            # use your mysql password here
$mysql_database = 'cl10-nreblog'; # use your mysql databas here

if(!$link = mysqli_connect($mysql_host, $mysql_user, $mysql_pass)){
    echo 'could not connect database';
    }
    
if(!mysqli_select_db($link, $mysql_database)){
   echo "Database not found";
   die();       
   }

$query = mysqli_query($link, "SELECT * 
                              FROM messages2 
                              WHERE url = '{$_GET['url']}' ");


if(mysqli_num_rows($query) == 0){
   header('Location: https://www.voiceoverguy.co.uk/404');
   die();
  }
else{
    $row = mysqli_fetch_assoc($query);
   }
       
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $row['meta_title']; ?></title>
    <meta name="description" content="<?php echo $row['page_desc']; ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="<?php echo $row['page_desc']; ?>">
<meta name="twitter:description" content="<?php echo $row['page_desc']; ?>">
<meta property="og:site_name" content="<?php echo $row['page_title']; ?>">
<meta property="og:url" content="https://voiceoverguy.co.uk/<?php echo $row['url']; ?>">  
<meta property="og:type" content="website"> 
<meta property="og:type" content="article">
<meta property="og:title" content="<?php echo $row['page_title']; ?>">
<meta property="og:description" content="<?php echo $row['page_title']; ?>">
<meta property="og:image" content="https://voiceoverguy.co.uk/assets/img/blog/<?php echo $row['image']; ?>">
<meta name="Robots" content="index, follow">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link rel="shortcut icon" href="assets/images/favicon/images/favicon.ico" />
<link rel="mask-icon" sizes="any" href="assets/images/favicon/favicon-152.svg" color="#000000">   
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />
<link rel="canonical" href="https://www.voiceoverguy.co.uk/<?php echo $row['url']; ?>" /> 
<link href="assets/css/all.css" rel="stylesheet">
<script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>

<style>
	
	#price1 {display: none;}
	#price2 {display: none;}
	#price3 {display: none;}
	#price4 {display: none;}
	#price5 {display: none;}
	
	
	input[type=text], input[type=email], textarea {
    border:1px solid #ccc;
    padding:8px;
    margin:2px 0;
    font-size:13px;
    font-family:Arial, Helvetica, sans-serif;
    color:#8f8f8f;
    width:250px;
    border-radius:5px;
    box-shadow:inset 0 0 8px #e5e8e7;
}
input[type=submit] {
    border:none;
    padding:8px 25px;
    margin:2px 0;
    font-family:Arial, Helvetica, sans-serif;
    color:#fff;
    background:#0d7963;
    border-radius:5px;
    cursor:pointer;
}
input[type=submit]:hover {
    opacity:0.9;
}

	</style>
	
	
	  
<script type="text/javascript">
$(function() {

$(".submit").click(function() {

	
	var myStr = $("#message").val();
    var newStr = myStr.replace(/&/g, "and");
	
    var message = newStr;
	
	var name = $("#name").val();
	var email = $("#email").val();
	var frompage = "<?php echo $row['page_title']; ?>";

    var dataString = 'message='+ message + '&name=' + name + '&email=' + email + '&frompage=' + frompage;

	if(message=='' || name=='' || email=='')
	{
	$('.success').fadeOut(200).hide();

    $('.error').fadeOut(200).show();
		
   
	}
	
	
	else
	{
	$.ajax({
	type: "POST",
    url: "process-form-blog.php",
    data: dataString,
    success: function(){
	$('.success').fadeIn(200).show();
    $('.error').fadeOut(200).hide();
	$('.submit').fadeOut(200).hide();
	
		
   }
});




	}
		

    return false;
	});



});
</script>
	  
	  
	  
	    
<script type="application/ld+json">
<?php
  // Build schema as a PHP array first, then json_encode it to guarantee valid JSON-LD
  // (prevents trailing commas + safely escapes quotes/newlines from admin fields).
  $schema = [
    "@context" => "https://schema.org",
    "@type" => "BlogPosting",
    "headline" => $row["meta_title"] ?? "",
    "description" => $row["page_desc"] ?? "",
    "author" => [
      "@type" => "Person",
      "name" => "Guy Harris",
      "url" => "https://www.voiceoverguy.co.uk/who"
    ],
    "publisher" => [
      "@type" => "Organization",
      "name" => "VoiceoverGuy",
      "logo" => [
        "@type" => "ImageObject",
        "url" => "https://www.voiceoverguy.co.uk/assets/img/blog/" . ($row["image"] ?? "")
      ]
    ],
    "image" => "https://www.voiceoverguy.co.uk/assets/img/blog/" . ($row["image"] ?? ""),
    "mainEntityOfPage" => "https://www.voiceoverguy.co.uk/" . ($row["url"] ?? ""),
    "isPartOf" => [
      "@type" => "WebSite",
      "name" => "VoiceoverGuy",
      "url" => "https://www.voiceoverguy.co.uk/"
    ],
    "datePublished" => $row["date"] ?? "",
    "dateModified" => $row["date"] ?? "",
    "url" => "https://www.voiceoverguy.co.uk/" . ($row["url"] ?? "")
  ];

  // Keywords are stored in admin as: "kw1","kw2","kw3"
  // Parse safely into an array. If empty, omit keywords/about entirely.
  $rawKeywords = trim($row["twitter"] ?? "");
  if ($rawKeywords !== "") {
    // Remove wrapping quotes then split on "," with optional whitespace
    $trimmed = trim($rawKeywords, "\"");
    $parts = preg_split('/"\s*,\s*"/', $trimmed);
    $keywords = array_values(array_filter(array_map('trim', $parts), function ($v) { return $v !== ""; }));

    if (!empty($keywords)) {
      $schema["keywords"] = $keywords;
      $schema["about"] = array_map(function ($kw) {
        return ["@type" => "Thing", "name" => $kw];
      }, $keywords);
    }
  }

  echo json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>
</script>
	  
	
<script type="application/ld+json">
<?php
$breadcrumb = [
  "@context" => "https://schema.org",
  "@type" => "BreadcrumbList",
  "itemListElement" => [
    [
      "@type" => "ListItem",
      "position" => 1,
      "name" => "Home",
      "item" => "https://www.voiceoverguy.co.uk/"
    ],
    [
      "@type" => "ListItem",
      "position" => 2,
      "name" => "News & Blog",
      "item" => "https://www.voiceoverguy.co.uk/voiceover-news"
    ],
    [
      "@type" => "ListItem",
      "position" => 3,
      "name" => $row["page_title"],
      "item" => "https://www.voiceoverguy.co.uk/" . $row["url"]
    ]
  ]
];

echo json_encode($breadcrumb, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
?>
</script>

</head>


<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>
</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">
<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
</div></div></div>



	




	

<div id="parallax">
<div class="container">
<div class="row">
	
<?php if (Auth::userCan('list_users')): ?>
<h2><a class="btn btn-primary btn" href="https://www.voiceoverguy.co.uk/guyadmin/admin.php?page=options-blog-edit&theid=<?php echo $row['id']; ?>" target="_blank">EDIT No:<?php echo $row['id']; ?></a>
<?php endif ?>

	
<div class="col-md-12" >
<h1><?php echo $row['page_title']; ?> </h1>
<?php echo $row['info']; ?>
<div class="bar"></div>
</div></div>


	

<div class="row">
<div class="col-md-6" >
<?php echo $row['text1']; ?>
	
</div>

<div class="col-md-6" >
<br>
<?php
$string2 = $row['whatvideo'];
if ( $string2 == "1" ){ ?>
<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo $row['video']; ?>" frameborder="0" allowfullscreen></iframe>
<? }elseif ( $string2 == "0" ){ ?>
<iframe src="//player.vimeo.com/video/<?php echo $row['video']; ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>
<? }elseif ( $string2 == "3" ){ ?>
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['page_title']; ?>" class="img-responsive  imageborder"   src="assets/img/blog/<?php echo $row['video']; ?>" />
<?php } else { ?>
<?php echo $row['video']; ?>
<?php } ?>
</div></div>

	

	
	

	


<div class="row">
<div class="col-md-6 effect1" >
<br>
<img alt="<?php echo $row['alt']; ?>" title="<?php echo $row['page_title']; ?>" class="img-responsive imageborder" src="assets/img/blog/<?php echo $row['image']; ?>" />
</div><div class="col-md-6" >
<?php echo $row['text2']; ?>
</div></div>



	
	
	
	
	
<?php if ($row['ntext1'] == ""){ }else{ ?>
<div class="row">
<div class="col-md-6" >
<?php echo $row['ntext1']; ?></div>
<div class="col-md-6 effect1" >
<?php if (
    $row['nimage1'] == '' ||
    $row['nimage1'] == null ||
    empty($row['nimage1']) ||
    !$row['nimage1']
) { }else { ?>
	<br>
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['page_title']; ?>" class="img-responsive  imageborder"   src="assets/img/blog/<?php echo $row['nimage1']; ?>" />
<? } ?>
</div></div>
    
<?php } ?>

	

<?php if ($row['ntext2'] == ""){ }else{ ?>		
<div class="row">
<div class="col-md-6 effect1" >
 <?php if (
    $row['nimage2'] == '' ||
    $row['nimage2'] == null ||
    empty($row['nimage2']) ||
    !$row['nimage2']
) { }else { ?>
	<br>
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['page_title']; ?>" class="img-responsive  imageborder"   src="assets/img/blog/<?php echo $row['nimage2']; ?>" />
<? } ?>

</div>
<div class="col-md-6" >
<?php echo $row['ntext2']; ?>
</div>
</div>
<?php } ?>
	
	
	

<?php if ($row['ntext3'] == ""){ }else{ ?>
<div class="row">
<div class="col-md-6" >
<?php echo $row['ntext3']; ?>
</div>
<div class="col-md-6 effect1" >
<?php if (
    $row['nimage3'] == '' ||
    $row['nimage3'] == null ||
    empty($row['nimage3']) ||
    !$row['nimage3']
) { }else { ?>
	<br>
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['page_title']; ?>" class="img-responsive  imageborder"   src="assets/img/blog/<?php echo $row['nimage3']; ?>" />
<? } ?>
</div>
</div>
<?php } ?>
	
	
	
	
	




	
	
	

	
	
	
	
	
	
	
	
<div class="row">
<div class="col-md-6" >
<?php echo $row['bottomtext']; ?>
</div>
<div class="col-md-6" ><br>
	
		
	<!--
	<p>
	If you would like to know more <a href="https://www.voiceoverguy.co.uk/contact-guy">please get in touch.</a>
	
<form id="form1" accept-charset="ISO-8859-1">
<textarea style="width:100%; max-width:500px;  height: 140px; font-size:19px "  id="message" name="message"  placeholder="Please type your enquiry here" ></textarea>
<input style="width:100%; max-width:500px;" type="text" name="name" id="name" placeholder="Your Name" required><br>
<input style="width:100%; max-width:500px; " type="email" name="email" id="email" placeholder="Your Email" required><br>
<span class="error" style="display:none"> Please enter valid email address</span>
<br>
   
		
<input  type="submit" value="Send message" style="background:#B42C2D; color:#; font-size:14px; border:1px solid #B42C2D;  margin-left: auto;
    margin-right: auto; display:block" class="submit"/>
<div  class="success" style="display:none">
<h2 style="margin-top: -20px;">Message sent successfully</h2>
</div>
</form>
-->
</div>
</div>
	
	
	
	

		
	


	

<div class="bar"></div>
	
	<!--
<div style="text-align:center; font-size: 19px;">
<a href="https://twitter.com/intent/tweet?text=<?php// echo $row['page_title']; ?>%0A https://www.voiceoverguy.co.uk/<?php //echo $row['url']; ?> %0A %23Voiceover %23VoiceoverGuy <?php //echo $row['twitter']; ?>" title="<?php //echo $row['page_title']; ?>"  >
<i class="fa fa-twitter fa-2x" title="" style="margin-right:10px;margin-left:10px"></i></a>
<a href="#" onclick="window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(location.href),'facebook-share-dialog','width=626,height=436');return false;"><i class="fa fa-facebook fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i></a>
 <a  href="javascript:void(0)" onclick="window.open( 'https://www.linkedin.com/shareArticle?mini=true&url=https://www.voiceoverguy.co.uk/<?php //echo $row['url']; ?>', 'sharer', 'toolbar=0, status=0, width=626, height=436');return false;" title="Linkedin"><i class="fa fa-linkedin fa-2x" title="" style="margin-right:10px;margin-left:10px"> </i></a></div>
<div class="bar"></div>
-->


 
<div style="text-align:center">
	
	
	
	
	<?php
  
  $servername = "localhost";
  $username = "cl10-nreblog";
  $password = "earwax69";
  $databasename = "cl10-nreblog";
  $conn = new mysqli($servername,
    $username, $password, $databasename);
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $query = "SELECT * FROM messages2 ORDER BY rand() LIMIT 3";
	
  $result = $conn->query($query);
  
    if ($result->num_rows > 0) 
    {
        while($row = $result->fetch_assoc())
        {
			?>


<div class="col-md-4" >
<h2><?php echo $row['page_title']; ?></h2>
<a href="<?php echo $row['url']; ?>" title="<?php echo $row['page_title']; ?>">
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['page_title']; ?>" class="img-responsive" src="assets/img/blog/<?php echo $row['image']; ?>" />
</a>
	<?php echo $row['hometext']; ?>
	</div>
	
	
	
	
	<? }} else { echo "0 results"; }
$conn->close(); ?>





</div>

	
</div>



	
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<?php include("assets/inc/footer.php"); ?>


   
    <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));</script> 
	
	
</body>
</html>
