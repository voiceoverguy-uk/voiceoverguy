<?php require_once 'guyadmin/app/init.php';?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

 
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
     <link href="assets/css/custom.css" rel="stylesheet">
     <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
     
     <style>
body {overflow: hidden; font-family: 'Courgette', cursive;
        font-size: 24px;}
		
		.board{
			
			background-image: url("board.png");
 
	background-size: 360px 100px; 
	background-repeat: no-repeat;


    background-position: center top;
	height:106px;
	padding-top:21px

			


			
		}

</style>
 
</head>
<body style=" background: url(bg.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;">
  
  



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style="text-align:center;  color:#FFF;background: url(sign.png);
  background-repeat: no-repeat;
    background-attachment: fixed;
    background-position: top;
     background-size: 380px 960px;  "  >
	


  <div style="padding-top:250px;">

 

<?php
date_default_timezone_set('Europe/London');
$MainDate = date("Y-m-d H:i:s");  

$TodayDay = date("l"); 
$TomorrowDay = date("l", strtotime("tomorrow"));
$TheHour = date("H"); 
$timestamp = time() - date('Z');
$time = date('H:i:s', time()); // 10:00:00

$time2 = date('H:i:s', strtotime("+1 hour")); // 10:00:00



$now4=new DateTime( 'now');


$DayIn1 = date("l", strtotime("+1 hour"));
$DayIn2 = date("l", strtotime("+2 hour"));
$DayIn3 = date("l", strtotime("+3 hour"));
$DayIn4 = date("l", strtotime("+4 hour"));
$DayIn5 = date("l", strtotime("+5 hour"));
$DayIn6 = date("l", strtotime("+6 hour"));
$DayIn7 = date("l", strtotime("+7 hour"));
$DayIn8 = date("l", strtotime("+8 hour"));
$DayIn9 = date("l", strtotime("+9 hour"));
$DayIn10 = date("l", strtotime("+10 hour"));
$DayIn11 = date("l", strtotime("+11 hour"));
$DayIn12 = date("l", strtotime("+12 hour"));
$DayIn13 = date("l", strtotime("+13 hour"));
$DayIn14 = date("l", strtotime("+14 hour"));
$DayIn15 = date("l", strtotime("+15 hour"));
$DayIn16 = date("l", strtotime("+16 hour"));
$DayIn17 = date("l", strtotime("+17 hour"));
$DayIn18 = date("l", strtotime("+18 hour"));
$DayIn19 = date("l", strtotime("+19 hour"));
$DayIn20 = date("l", strtotime("+20 hour"));
$DayIn21 = date("l", strtotime("+21 hour"));
$DayIn22 = date("l", strtotime("+22 hour"));
$DayIn23 = date("l", strtotime("+23 hour"));
$DayIn24 = date("l", strtotime("+24 hour"));
$DayIn25 = date("l", strtotime("+25 hour"));
$DayIn26 = date("l", strtotime("+26 hour"));
$DayIn27 = date("l", strtotime("+27 hour"));
$DayIn28 = date("l", strtotime("+28 hour"));
$DayIn29 = date("l", strtotime("+29 hour"));
$DayIn30 = date("l", strtotime("+30 hour"));
$DayIn31 = date("l", strtotime("+31 hour"));
$DayIn32 = date("l", strtotime("+32 hour"));
$DayIn33 = date("l", strtotime("+33 hour"));
$DayIn34 = date("l", strtotime("+34 hour"));
$DayIn35 = date("l", strtotime("+35 hour"));
$DayIn36 = date("l", strtotime("+36 hour"));
$DayIn37 = date("l", strtotime("+37 hour"));
$DayIn38 = date("l", strtotime("+38 hour"));
$DayIn39 = date("l", strtotime("+39 hour"));
$DayIn40 = date("l", strtotime("+40 hour"));
$DayIn41 = date("l", strtotime("+41 hour"));

$TheHourIn1 = date("H", strtotime("+1 hour"));
$TheHourIn2 = date("H", strtotime("+2 hour"));
$TheHourIn3 = date("H", strtotime("+3 hour"));
$TheHourIn4 = date("H", strtotime("+4 hour"));
$TheHourIn5 = date("H", strtotime("+5 hour"));
$TheHourIn6 = date("H", strtotime("+6 hour"));
$TheHourIn7 = date("H", strtotime("+7 hour"));
$TheHourIn8 = date("H", strtotime("+8 hour"));
$TheHourIn9 = date("H", strtotime("+9 hour"));
$TheHourIn10 = date("H", strtotime("+10 hour"));
$TheHourIn11 = date("H", strtotime("+11 hour"));
$TheHourIn12 = date("H", strtotime("+12 hour"));
$TheHourIn13 = date("H", strtotime("+13 hour"));
$TheHourIn14 = date("H", strtotime("+14 hour"));
$TheHourIn15 = date("H", strtotime("+15 hour"));
$TheHourIn16 = date("H", strtotime("+16 hour"));
$TheHourIn17 = date("H", strtotime("+17 hour"));
$TheHourIn18 = date("H", strtotime("+18 hour"));
$TheHourIn19 = date("H", strtotime("+19 hour"));
$TheHourIn20 = date("H", strtotime("+20 hour"));
$TheHourIn21 = date("H", strtotime("+21 hour"));
$TheHourIn22 = date("H", strtotime("+22 hour"));
$TheHourIn23 = date("H", strtotime("+23 hour"));
$TheHourIn24 = date("H", strtotime("+24 hour"));
$TheHourIn25 = date("H", strtotime("+25 hour"));
$TheHourIn26 = date("H", strtotime("+26 hour"));
$TheHourIn27 = date("H", strtotime("+27 hour"));
$TheHourIn28 = date("H", strtotime("+28 hour"));
$TheHourIn29 = date("H", strtotime("+29 hour"));
$TheHourIn30 = date("H", strtotime("+30 hour"));
$TheHourIn31 = date("H", strtotime("+31 hour"));
$TheHourIn32 = date("H", strtotime("+32 hour"));
$TheHourIn33 = date("H", strtotime("+33 hour"));
$TheHourIn34 = date("H", strtotime("+34 hour"));
$TheHourIn35 = date("H", strtotime("+35 hour"));
$TheHourIn36 = date("H", strtotime("+36 hour"));
$TheHourIn37 = date("H", strtotime("+37 hour"));
$TheHourIn38 = date("H", strtotime("+38 hour"));
$TheHourIn39 = date("H", strtotime("+39 hour"));
$TheHourIn40 = date("H", strtotime("+40 hour"));
$TheHourIn41 = date("H", strtotime("+41 hour"));





$string = 'More Xmas Tunes';
$stringPlaying = Config::get('seo29.'.$TodayDay.''.$TheHour.'');

$string1 = Config::get('seo29.'.$DayIn1.''.$TheHourIn1.'');
$string2 = Config::get('seo29.'.$DayIn2.''.$TheHourIn2.'');
$string3 = Config::get('seo29.'.$DayIn3.''.$TheHourIn3.'');
$string4 = Config::get('seo29.'.$DayIn4.''.$TheHourIn4.'');
$string5 = Config::get('seo29.'.$DayIn5.''.$TheHourIn5.'');
$string6 = Config::get('seo29.'.$DayIn6.''.$TheHourIn6.'');
$string7 = Config::get('seo29.'.$DayIn7.''.$TheHourIn7.'');
$string8 = Config::get('seo29.'.$DayIn8.''.$TheHourIn8.'');
$string9 = Config::get('seo29.'.$DayIn9.''.$TheHourIn9.'');
$string10 = Config::get('seo29.'.$DayIn10.''.$TheHourIn10.'');
$string11 = Config::get('seo29.'.$DayIn11.''.$TheHourIn11.'');
$string12 = Config::get('seo29.'.$DayIn12.''.$TheHourIn12.'');
$string13 = Config::get('seo29.'.$DayIn13.''.$TheHourIn13.'');
$string14 = Config::get('seo29.'.$DayIn14.''.$TheHourIn14.'');
$string15 = Config::get('seo29.'.$DayIn15.''.$TheHourIn15.'');
$string16 = Config::get('seo29.'.$DayIn16.''.$TheHourIn16.'');
$string17 = Config::get('seo29.'.$DayIn17.''.$TheHourIn17.'');
$string18 = Config::get('seo29.'.$DayIn18.''.$TheHourIn18.'');
$string19 = Config::get('seo29.'.$DayIn19.''.$TheHourIn19.'');
$string20 = Config::get('seo29.'.$DayIn20.''.$TheHourIn20.'');
$string21 = Config::get('seo29.'.$DayIn21.''.$TheHourIn21.'');
$string22 = Config::get('seo29.'.$DayIn22.''.$TheHourIn22.'');
$string23 = Config::get('seo29.'.$DayIn23.''.$TheHourIn23.'');
$string24 = Config::get('seo29.'.$DayIn24.''.$TheHourIn24.'');
$string25 = Config::get('seo29.'.$DayIn25.''.$TheHourIn25.'');
$string26 = Config::get('seo29.'.$DayIn26.''.$TheHourIn26.'');
$string27 = Config::get('seo29.'.$DayIn27.''.$TheHourIn27.'');
$string28 = Config::get('seo29.'.$DayIn28.''.$TheHourIn28.'');
$string29 = Config::get('seo29.'.$DayIn29.''.$TheHourIn29.'');
$string30 = Config::get('seo29.'.$DayIn30.''.$TheHourIn30.'');
$string31 = Config::get('seo29.'.$DayIn31.''.$TheHourIn31.'');
$string32 = Config::get('seo29.'.$DayIn32.''.$TheHourIn32.'');
$string33 = Config::get('seo29.'.$DayIn33.''.$TheHourIn33.'');
$string34 = Config::get('seo29.'.$DayIn34.''.$TheHourIn34.'');
$string35 = Config::get('seo29.'.$DayIn35.''.$TheHourIn35.'');
$string36 = Config::get('seo29.'.$DayIn36.''.$TheHourIn36.'');
$string37 = Config::get('seo29.'.$DayIn37.''.$TheHourIn37.'');
$string38 = Config::get('seo29.'.$DayIn37.''.$TheHourIn38.'');
$string39 = Config::get('seo29.'.$DayIn38.''.$TheHourIn39.'');
$string40 = Config::get('seo29.'.$DayIn40.''.$TheHourIn40.'');
$string41 = Config::get('seo29.'.$DayIn41.''.$TheHourIn41.'');




if ( $string == $stringPlaying ){ 


echo '<b>';
echo 'Current Show' ;
echo '</b><br>';
echo Config::get('seo29.'.$TodayDay.''.$TheHour.'');
echo '</b><br><br>';


} else{ 


echo '<b>';
echo 'Current Show' ;
echo '<br></b>';
echo Config::get('seo29.'.$TodayDay.''.$TheHour.'');
echo '</b><br><br><br>';
echo Config::get('seo29.'.$DayIn1.''.$TheHourIn1.''); 
echo '<br>';
$midnightx=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn1.':00') ));
$diffx = $now4->diff( $midnightx );
echo $diffx->format('%h hours %i minutes  ');




}




if ( $string == $string1 ){ } else{ 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn1.''.$TheHourIn1.''); 
echo '<br>';
$midnight1=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn1.':00') ));
$diff1 = $now4->diff( $midnight1 );
echo $diff1->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn2.''.$TheHourIn2.''); 
echo '<br>';
$midnight2=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn2.':00') ));
$diff2 = $now4->diff( $midnight2 );
echo $diff2->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}






if ( $string == $string2 ){ } else { 

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn2.''.$TheHourIn2.''); 
echo '<br>';
$midnight2=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn2.':00') ));
$diff2 = $now4->diff( $midnight2 );
echo $diff2->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn3.''.$TheHourIn3.''); 
echo '<br>';
$midnight3=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn3.':00') ));
$diff3 = $now4->diff( $midnight3 );
echo $diff3->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}



if ( $string == $string3 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn3.''.$TheHourIn3.'');
echo '<br>';
$midnight3=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn3.':00') ));
$diff3 = $now4->diff( $midnight3 );
echo $diff3->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn4.''.$TheHourIn4.'');
echo '<br>';
$midnight4=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn4.':00') ));
$diff4 = $now4->diff( $midnight4 );
echo $diff4->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}




if ( $string == $string4 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn4.''.$TheHourIn4.'');
echo '<br>';
$midnight4=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn4.':00') ));
$diff4 = $now4->diff( $midnight4 );
echo $diff4->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn5.''.$TheHourIn5.'');
echo '<br>';
$midnight5=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn5.':00') ));
$diff5 = $now4->diff( $midnight5 );
echo $diff5->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}






if ( $string == $string5 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn5.''.$TheHourIn5.'');
echo '<br>';
$midnight5=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn5.':00') ));
$diff5 = $now4->diff( $midnight5 );
echo $diff6->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn6.''.$TheHourIn6.'');
echo '<br>';
$midnight6=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn6.':00') ));
$diff6 = $now4->diff( $midnight6 );
echo $diff6->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}





if ( $string == $string6 ){ } else { 

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn6.''.$TheHourIn6.'');
echo '<br>';
$midnight6=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn6.':00') ));
$diff6 = $now4->diff( $midnight6 );
echo $diff6->format('%h hours %i minutes');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn7.''.$TheHourIn7.'');
echo '<br>';
$midnight7=new DateTime( date('Y-m-d H:i:s', strtotime(''.$TheHourIn7.':00') ));
$diff7 = $now4->diff( $midnight7 );
echo  $diff7->format('%h hours %i minutes');
echo '<br><br>';
echo '</div>';
}







if ( $string == $string7 ){ } else { 

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn7.''.$TheHourIn7.'');
echo '<br>';
$midnight7=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn7.''.$TheHourIn7.':00') ));
$diff7 = $now4->diff( $midnight7 );
echo  $diff7->format('%h hours %i minutes');
echo '<br><br>';
echo '</div>';


echo '<div class="board">';
echo Config::get('seo29.'.$DayIn8.''.$TheHourIn8.'');
echo '<br>';
$midnight8=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn8.' '.$TheHourIn8.':00') ));
$diff8 = $now4->diff( $midnight8 );
echo $diff8->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

}









if ( $string == $string8 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn8.''.$TheHourIn8.'');
echo '<br>';
$midnight8=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn8.' '.$TheHourIn8.':00') ));
$diff8 = $now4->diff( $midnight8 );
echo $diff8->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn9.''.$TheHourIn9.'');
echo '<br>';
$midnight9=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn9.' '.$TheHourIn9.':00') ));
$diff9 = $now4->diff( $midnight9 );
echo $diff9->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}







if ( $string == $string9 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn9.''.$TheHourIn9.'');
echo '<br>';
$midnight9=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn9.' '.$TheHourIn9.':00') ));
$diff9 = $now4->diff( $midnight9 );
echo $diff9->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn10.''.$TheHourIn10.'');
echo '<br>';
$midnight10=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn10.' '.$TheHourIn10.':00') ));
$diff10 = $now4->diff( $midnight10 );
echo $diff10->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}







if ( $string == $string10 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn10.''.$TheHourIn10.'');
echo '<br>';
$midnight10=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn10.' '.$TheHourIn10.':00') ));
$diff10 = $now4->diff( $midnight10 );
echo $diff10->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn11.''.$TheHourIn11.'');
echo '<br>';
$midnight11=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn11.' '.$TheHourIn11.':00') ));
$diff11 = $now4->diff( $midnight11 );
echo $diff11->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}








if ( $string == $string11 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn11.''.$TheHourIn11.'');
echo '<br>';
$midnight11=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn11.' '.$TheHourIn11.':00') ));
$diff11 = $now4->diff( $midnight11 );
echo $diff11->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn12.''.$TheHourIn12.'');
echo '<br>';
$midnight12=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn12.' '.$TheHourIn12.':00') ));
$diff12 = $now4->diff( $midnight12 );
echo $diff12->format('%h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}






if ( $string == $string12 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn12.''.$TheHourIn12.'');
echo '<br>';
$midnight12=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn12.' '.$TheHourIn12.':00') ));
$diff12 = $now4->diff( $midnight12 );
echo $diff12->format('%h hours %i minutes   ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn13.''.$TheHourIn13.'');
echo '<br>';
$midnight13=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn13.' '.$TheHourIn13.':00') ));
$diff13 = $now4->diff( $midnight13 );
echo $diff13->format('%h hours %i minutes   ');
echo '<br><br>';
echo '</div>';
}







if ( $string == $string13 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn13.''.$TheHourIn13.'');
echo '<br>';
$midnight13=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn13.' '.$TheHourIn13.':00') ));
$diff13 = $now4->diff( $midnight13 );
echo $diff13->format('%d day %h hours %i minutes %s second ');
echo '<br><br>';
echo '</div>';
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn14.''.$TheHourIn14.'');
echo '<br>';
$midnight14=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn14.' '.$TheHourIn14.':00') ));
$diff14 = $now4->diff( $midnight14 );
echo $diff14->format('%d day %h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}






if ( $string == $string14 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn14.''.$TheHourIn14.'');
echo '<br>';
$midnight14=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn14.' '.$TheHourIn14.':00') ));
$diff14 = $now4->diff( $midnight14 );
echo $diff14->format('%d day %h hours %i minutes  ');
echo '<br><br>';
echo '</div>';


echo '<div class="board">';
echo Config::get('seo29.'.$DayIn15.''.$TheHourIn15.'');
echo '<br>';
$midnight15=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn15.' '.$TheHourIn15.':00') ));
$diff15 = $now4->diff( $midnight15 );
echo $diff15->format('%d day %h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}





if ( $string == $string15 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn15.''.$TheHourIn15.'');
echo '<br>';
$midnight15=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn15.' '.$TheHourIn15.':00') ));
$diff15 = $now4->diff( $midnight15 );
echo $diff15->format('%d day %h hours %i minutes  ');
echo '<br><br>';
echo '</div>';

echo '<div class="board">';
echo Config::get('seo29.'.$DayIn16.''.$TheHourIn16.'');
echo '<br>';
$midnight16=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn16.' '.$TheHourIn16.':00') ));
$diff16 = $now4->diff( $midnight16 );
echo $diff16->format('%d day %h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}











if ( $string == $string16 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn16.''.$TheHourIn16.'');
echo '<br>';
$midnight16=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn16.' '.$TheHourIn16.':00') ));
$diff16 = $now4->diff( $midnight16 );
echo $diff16->format('%d day %h hours %i minutes   ');
echo '<br><br>';
echo '</div>';
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn17.''.$TheHourIn17.'');
echo '<br>';
$midnight17=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn17.' '.$TheHourIn17.':00') ));
$diff17 = $now4->diff( $midnight17 );
echo $diff17->format('%d day %h hours %i minutes   ');
echo '<br><br>';
echo '</div>';
}









if ( $string == $string17 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn17.''.$TheHourIn17.'');
echo '<br>';
$midnight17=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn17.' '.$TheHourIn17.':00') ));
$diff17 = $now4->diff( $midnight17 );
echo $diff17->format('%d day %h hours %i minutes   ');
echo '<br><br>';
echo '</div>';
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn18.''.$TheHourIn18.'');
echo '<br>';
$midnight18=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn18.' '.$TheHourIn18.':00') ));
$diff18 = $now4->diff( $midnight18 );
echo $diff18->format('%d day %h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}





if ( $string == $string18 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn18.''.$TheHourIn18.'');
echo '<br>';
$midnight18=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn18.' '.$TheHourIn18.':00') ));
$diff18 = $now4->diff( $midnight18 );
echo $diff18->format('%d day %h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn19.''.$TheHourIn19.'');
echo '<br>';
$midnight19=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn19.' '.$TheHourIn19.':00') ));
$diff19 = $now4->diff( $midnight19 );
echo $diff19->format('%d day %h hours %i minutes   ');
echo '<br><br>';
echo '</div>';
}






if ( $string == $string19 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn19.''.$TheHourIn19.'');
echo '<br>';
$midnight19=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn19.' '.$TheHourIn19.':00') ));
$diff19 = $now4->diff( $midnight19 );
echo $diff19->format('%d day %h hours %i minutes   ');
echo '<br><br>';
echo '</div>';
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn20.''.$TheHourIn20.'');
echo '<br>';
$midnight20=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn20.' '.$TheHourIn20.':00') ));
$diff20 = $now4->diff( $midnight20 );
echo $diff20->format('%d day %h hours %i minutes  ');
echo '<br><br>';
echo '</div>';
}






if ( $string == $string20 ){ } else { 
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn20.''.$TheHourIn20.'');
echo '<br>';
$midnight20=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn20.' '.$TheHourIn20.':00') ));
$diff20 = $now4->diff( $midnight20 );
echo $diff20->format('%d day %h hours %i minutes');
echo '<br><br>';
echo '</div>';
echo '<div class="board">';
echo Config::get('seo29.'.$DayIn21.''.$TheHourIn21.'');
echo '<br>';
$midnight21=new DateTime( date('Y-m-d H:i:s', strtotime(''.$DayIn21.' '.$TheHourIn21.':00') ));
$diff21 = $now4->diff( $midnight21 );
echo $diff21->format('%d day %h hours %i minutes');
echo '<br><br>';
echo '</div>';
}










echo '<br><br><br><br><br><br><br><br><br><br><br>';

//echo 'Coming up in 1 Hour:' ;
//echo '<br><b>';
//echo Config::get('seo29.'.$DayIn1.''.$TheHourIn1.'');
//echo '</b><br><br>';














?>

</p>


</div>

</div>
</div>
</div>
<!-- End Top Menu -->
 
</div>
   
</body>
</html>