<?php

if (isset($_REQUEST['name'],$_REQUEST['email'])) {
      
    $name = $_REQUEST['name'];
    $email = $_REQUEST['email'];
    $message = $_REQUEST['message'];
	$count1 = $_REQUEST['count1'];
	$count2 = $_REQUEST['count2'];
	
	$from1 = "MTV Website Script";
	
	$date = date("Y-m-d H:i:s");
      
    // Set your email address where you want to receive emails. 
    $to = 'movie@voiceoverguy.co.uk';
	
	///movie@voiceoverguy.co.uk
      
  //  $subject = 'Custom Script from $email ';
	$subject = "Custom Script from ".$email."\r\n";
      
    $headers = "From: ".$name." <".$email."> \r\n";
	
	$headers .= "MIME-Version: 1.0\r\n";
//Set the content-type to html
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	
$message2 = '<html><body>';
$message2 .= '<h2>Movie Trailer Voice Script</h2>';
$message2 .= '<p><b>Name: </b>'.$name.'<br>';
$message2 .= '<b>Email: </b>'.$email.'<br>';
$message2 .= '<b>Characters: </b>'.$count1.'<br>';
$message2 .= '<b>Words: </b>'.$count2.'<br>';
	
	//str_replace('<br />', "\n", $textarea);
	
$message2 .= '<h2>'.nl2br($message).'</h2>';
	

$message2 .= '</body></html>';
	
	
	 // $message2 = "From :$name \n<b>Email</b>: $email \n Script:\n$message \r\n";
      
    $send_email = mail($to,$subject,$message2,$headers);
      
	 
	 
	
  // header( 'Location: http://movietrailervoice.co.uk/script1.php?=sent' ) ;

 
   
    echo ($send_email) ? 'success' : 'error';
	
	
	
	
	
}
	
	
	 	
$con = mysql_connect("voiceoverguy.co.uk","cl10-mtvapp","earwax69");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("cl10-mtvapp", $con);
 
$sql="INSERT INTO messages2 (name, email, date, wherefrom)
VALUES
('$name','$email','$date','$from1')";
 
if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

mysql_close($con)


	



?>