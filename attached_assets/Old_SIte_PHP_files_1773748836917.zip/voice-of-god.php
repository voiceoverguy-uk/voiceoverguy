<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo7.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo7.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">
<meta name="twitter:description" content="<?php echo Config::get('seo7.s2'); ?>">
<meta name="Robots" content="index, follow">
    <meta property="og:title" content="Voice of God – Event Announcer Guy Harris" />
    <meta property="og:description" content="<?php echo Config::get('seo7.s2'); ?>" />
    <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/voice-of-god-voice-og.jpg" />
    <meta property="og:url" content="https://www.voiceoverguy.co.uk/voice-of-god" />
    <meta property="og:type" content="profile" />
    <meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/voice-of-god-voice-og.jpg" />
    <link rel="preload" as="image" href="assets/images/guy-harris-voiceover.png">

 
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/voice-of-god" />


      <link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	  
	  
	<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ProfilePage",
  "name": "Voice of God | Guy Harris – British Voiceover Artist",
  "url": "https://www.voiceoverguy.co.uk/voice-of-god",
  "mainEntity": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk/",
    "image": "https://www.voiceoverguy.co.uk/assets/images/guy-harris-voiceover.png",
    "jobTitle": "British Male Voiceover Artist",
    "knowsAbout": [
      "British male voiceover",
      "Santa voiceover",
      "Voice of God announcer",
      "David Attenborough impression",
      "Character voiceover",
      "Live event announcer"
    ],
    "sameAs": [
      "https://www.linkedin.com/in/voiceoverguy/",
      "https://www.voiceoverguy.co.uk/",
      "https://www.youtube.com/@voiceoverguy"
    ]
  }
}
</script>
<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"BreadcrumbList",
  "itemListElement":[
    {
      "@type":"ListItem",
      "position":1,
      "item":{
        "@id":"https://www.voiceoverguy.co.uk/",
        "name":"Home"
      }
    },
    {
      "@type":"ListItem",
      "position":2,
      "item":{
        "@id":"https://www.voiceoverguy.co.uk/voice-of-god",
        "name":"Voice of God"
      }
    }
  ]
}
</script>
<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"SpeakableSpecification",
  "xpath":[
    
    "/html/body//p"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"VideoObject",
  "@id":"https://www.voiceoverguy.co.uk/voice-of-god/#video1",
  "name":"The Masked Singer – Voice of God Show Announcer | Guy Harris",
  "description":"Voicing The Masked Singer for Butlins in 2024, Guy Harris delivered the iconic Voice of God announcements for the live show.",
  "thumbnailUrl":"https://i.ytimg.com/vi/e0vZ9cxdilo/maxresdefault.jpg",
  "uploadDate":"2024-02-27T10:00:00+00:00",
  "url":"https://www.youtube.com/watch?v=e0vZ9cxdilo",
  "embedUrl":"https://www.youtube.com/embed/e0vZ9cxdilo"
}
</script>
<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"VideoObject",
  "@id":"https://www.voiceoverguy.co.uk/voice-of-god/#video2",
  "name":"Ant & Dec’s Saturday Night Takeaway Tour – Voice of God Announcer | Guy Harris",
  "description":"Guy Harris performed the Voice of God across the UK tour in 2014, voicing live event announcements for Ant & Dec’s Saturday Night Takeaway Tour.",
  "thumbnailUrl":"https://i.ytimg.com/vi/W99pMUr6G8Q/maxresdefault.jpg",
  "uploadDate":"2014-08-16T10:00:00+00:00",
  "url":"https://www.youtube.com/watch?v=W99pMUr6G8Q",
  "embedUrl":"https://www.youtube.com/embed/W99pMUr6G8Q"
}
</script>
<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"AudioObject",
  "@id":"https://www.voiceoverguy.co.uk/voice-of-god/#audio",
  "name":"Voice of God Showreel – Guy Harris",
  "description":"A 1 minute 27 second Voice of God event announcer showreel by Guy Harris.",
  "url":"https://www.voiceoverguy.co.uk/assets/audio/voice-of-god-showreel-voiceover-guy-harris.mp3",
  "contentUrl":"https://www.voiceoverguy.co.uk/assets/audio/voice-of-god-showreel-voiceover-guy-harris.mp3",
  "encodingFormat":"audio/mpeg",
  "uploadDate":"2025-03-20T10:00:00+00:00",
  "duration":"PT1M27S"
}
</script>
<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"OfferCatalog",
  "@id":"https://www.voiceoverguy.co.uk/voice-of-god/#offers",
  "name":"Voice of God Event Announcer Packages",
  "itemListElement":[
    {
      "@type":"Offer",
      "itemOffered":{
        "@type":"Service",
        "name":"Voice of God – Pre‑Recorded Event Announcer",
        "provider":"Guy Harris",
        "areaServed":"United Kingdom"
      }
    }
  ]
}
</script>
<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"LocalBusiness",
  "@id":"https://www.voiceoverguy.co.uk/#business",
  "name":"Guy Harris Voiceover",
  "url":"https://www.voiceoverguy.co.uk/",
  "logo":"https://www.voiceoverguy.co.uk/assets/images/guy-harris-profile.jpg",
  "areaServed":"United Kingdom",
  "sameAs":[
    "https://www.linkedin.com/in/voiceoverguy/",
    "https://www.youtube.com/@voiceoverguy"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "DefinedTermSet",
  "@id": "https://www.voiceoverguy.co.uk/voice-of-god#defined-terms",
  "name": "Voiceover terminology used on this page",
  "hasDefinedTerm": [
    {
      "@type": "DefinedTerm",
      "@id": "https://www.voiceoverguy.co.uk/voice-of-god#term-voice-of-god-announcer",
      "name": "Voice of God announcer",
      "alternateName": ["VOG announcer", "Voice of God voiceover"],
      "description": "In live events and awards shows, a ‘Voice of God’ announcer is the off-stage voice used for introductions, cues and announcements in theatres, arenas and corporate productions (not religious or spiritual guidance).",
      "inDefinedTermSet": "https://www.voiceoverguy.co.uk/voice-of-god#defined-terms"
    }
  ]
}
</script>
	  
	  
 
</head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo html_entity_decode(Config::get('seo7.s3')); ?>



</div>
</div>
</div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">

<iframe width="100%" height="300" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/25259194&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
</div>
</div>
</div>
</div>

<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">

<div id="dynamic-review-block" style="background:#fff3f3;border:3px solid #cc0000;padding:25px;margin-bottom:25px;border-radius:10px;text-align:center;box-shadow:0 0 12px rgba(200,0,0,0.25);">
  <h2 id="review-title" style="margin-top:0;font-size:30px;color:#b30000;font-weight:800;">
    🎤 Rated 5.0 <span style="color:#ffcc00;">★★★★★</span> by <span id="review-count">117</span> Happy Clients
  </h2>
  <p style="font-size:18px;color:#333;margin-bottom:18px;">
    Event clients include ITV, TV Choice, Butlins, Masked Singer, Bestway, Poundland, EON, National History Museum, IGT Gaming and more.
  </p>
  <a href="https://www.google.com/search?q=VoiceoverGuy+Wakefield&ludocid=13238741027900894876#lrd=0x48795b5b8bb4d61d:0xb7a63f64e244a5ec,1" target="_blank" rel="noopener"
     style="display:inline-block;background:#cc0000;color:white;padding:12px 28px;border-radius:6px;font-weight:700;font-size:17px;text-decoration:none;">
     ⭐ Read Google Reviews
  </a>
</div>

<script>
  fetch('/api/get-reviews.php')
    .then(r => r.json())
    .then(data => {
      if (data.count) {
        document.getElementById('review-count').textContent = data.count;
      }
    })
    .catch(err => console.error('Review API error:', err));
</script>

</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">
<div class="row">

<div class="col-md-6" >

<?php echo html_entity_decode(Config::get('seo7.s4')); ?>
</div>

<div class="col-md-6" >
<br>


<?php
$string2 = Config::get('seo7.s20');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo7.s7'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo7.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>

</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>


<?php
$string2 = Config::get('seo7.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo7.s8'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo7.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo7.s5')); ?>
</div>


</div>

<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo7.s6')); ?>
</div>

<div class="col-md-6" >
<br>
<a href="voiceover-cartoons" title="Guy Harris - Voice of God" ><img alt="Guy Harris - Voice of God" title="Guy Harris - Voice of God" class="img-responsive"   src="assets/images/cartoons/Voiceover-Cartoon-Voice-Of-God.jpg" /></a>

</div>


</div>



<?php include("assets/inc/applinks.php"); ?>   

<div class="container" style="margin-top:40px;margin-bottom:40px;">
  <div style="background:#f7f7f7;border:2px solid #ddd;padding:25px;border-radius:10px;">
    <h3 style="margin-top:0;font-weight:700;">More Voices You May Like</h3>
    <ul style="margin:0;padding-left:18px;font-size:17px;line-height:1.6;">
      <li><a href="https://voiceofgod.co.uk" title="Voice of God Announcer for Live Events">Voice of God Announcer (Live Events)</a></li>
      <li><a href="/santa-voice">Santa / Father Christmas Voice</a></li>
      <li><a href="/character-voiceover">Character Voiceovers</a></li>
      <li><a href="/voiceover-cartoons">Cartoon Voices</a></li>
      <li><a href="/pathe-voice">Pathé News Voice</a></li>
      <li><a href="/pirate-voiceover">Pirate Voice</a></li>
      <li><a href="/joker-voice">Evil / Joker Style Voice</a></li>
      <li><a href="/gameshow-host-voice">Gameshow Host Voice</a></li>
      <li><a href="/david-attenborough-voice">David Attenborough Style Voice</a></li>
    </ul>
  </div>
</div>

</div><!-- End Container-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

   <?php include("assets/inc/footer.php"); ?>
    
</body>
</html>