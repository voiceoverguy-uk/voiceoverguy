document.addEventListener('DOMContentLoaded', () => {
  const textarea = document.getElementById('userInput');
  const wordCountDisplay = document.getElementById('wordCount');
  const newScriptBtn = document.getElementById('newScenarioBtn');
  const copyBtn = document.getElementById('copyBtn');
  const generateBtn = document.getElementById('generateBtn');
  const outputDiv = document.getElementById('output');
  const outputContent = document.getElementById('outputContent');

  // Word count and limit enforcement
  textarea.addEventListener('input', () => {
    const words = textarea.value.trim().split(/\s+/).filter(word => word.length > 0);
    let wordCount = words.length;

    if (wordCount >= 25) {
      const trimmed = words.slice(0, 25).join(' ');
      textarea.value = trimmed + ' ';
      wordCount = 25;
    }

    wordCountDisplay.textContent = `${wordCount}/25 words`;

    if (wordCount >= 25) {
      wordCountDisplay.style.color = '#ff3333';
      wordCountDisplay.classList.add('word-limit-hit');
      showWarningPopup();
      setTimeout(() => wordCountDisplay.classList.remove('word-limit-hit'), 300);
    } else if (wordCount >= 25) {
      wordCountDisplay.style.color = '#ffaa33';
    } else {
      wordCountDisplay.style.color = '#ccc';
    }
  });

  // Reset form
  function resetForm() {
    textarea.value = '';
    outputContent.innerHTML = '<span class="text-muted">Awaiting your creation...</span>';
    wordCountDisplay.textContent = '0/25 words';
    wordCountDisplay.style.color = '#ccc';
    newScriptBtn.classList.add('hidden');
    copyBtn.classList.add('hidden');
    
    // Remove audio player if exists
    const audioPlayer = document.getElementById('voicePreview');
    if (audioPlayer) {
      audioPlayer.remove();
    }
  }

  // Show warning popup
  function showWarningPopup() {
    const popup = document.getElementById('popup');
    popup.classList.add('show');
    setTimeout(() => popup.classList.remove('show'), 4000);
  }

  // Reset button
  newScriptBtn.addEventListener('click', resetForm);

  // Copy button
  copyBtn.addEventListener('click', () => {
    const outputText = outputContent.innerText;
    navigator.clipboard.writeText(outputText)
      .then(() => {
        copyBtn.textContent = '✅ Copied!';
        setTimeout(() => {
          copyBtn.textContent = '📋 Copy Script';
        }, 2000);
      })
      .catch(err => {
        console.error('Copy failed', err);
        copyBtn.textContent = '❌ Copy Failed';
      });
  });

  // Generate script - AJAX call to backend
  generateBtn.addEventListener('click', async () => {
    const userInput = textarea.value.trim();
    
    // Validate input
    if (!userInput) {
      outputContent.innerHTML = '<span class="text-error">Please describe a scenario first!</span>';
      return;
    }

    // Show loading state
    outputContent.innerHTML = '<span class="text-muted">Generating script... Please wait</span>';
    newScriptBtn.classList.add('hidden');
    copyBtn.classList.add('hidden');

    // Check for profanity (client-side)
    const bannedWords = ['damn', 'cunt', 'fucker', 'fucking', 'cocksucker', 'crap', 'shit', 'fuck', 'bastard', 'bugger', 'bollocks', 'wanker', 'twat'];
    const lowerInput = userInput.toLowerCase();

    const profanityWarnings = [
      "Attenborough: \"Profanity? Really? Even the chimpanzees show more restraint.\"",
      "Attenborough: \"An unrefined utterance from an otherwise sentient being. Do better.\"",
      "Attenborough: \"Nature is brutal… but not *that* crude. Reconsider your vocabulary.\"",
      "Attenborough: \"Even the walrus, wallowing in its own filth, wouldn't say that.\"",
      "Attenborough: \"A display of linguistic laziness. Use words your nan would approve of!\"",
      "Attenborough: \"The wildebeest may grunt in confusion… but it doesn't swear like *that*.\"",
      "Attenborough: \"If we were in the jungle, you'd be eaten for talking like that.\"",
      "Attenborough: \"Ah yes, the lesser-spotted potty mouth. Rarely admired. Kindly revise.\"",
      "Attenborough: \"This is not the savannah, and you're not marking territory. Language!\"",
      "Attenborough: \"Language like that? No wonder the other creatures keep their distance.\"",
      "Attenborough: \"Mind your language, young hatchling. Even the dodo had more decorum.\"",
      "Attenborough: \"The wild baboon does not resort to such language! Rephrase your scenario!\"",
      "Attenborough: \"This isn't the savannah, dear. Let's try that again without the expletives.\"",
      "Attenborough: \"Such language may scare the meerkats. Edit and approach once more.\"",
      "Attenborough: \"Even the hyenas cackle at such uncouth expressions. Do better!\"",
      "Attenborough: \"The mating call of the modern human… often regrettable. Try again.\"",
      "Attenborough: \"We must tread carefully — this is a place of wonder, not wounding words.\"",
      "Attenborough: \"Remarkable. A string of words so foul, even the dung beetle looks away.\"",
      "Attenborough: \"Not even the chimpanzee flings such vulgarities. Let's keep it civilised.\"",
      "Attenborough: \"A magnificent outburst… for the wrong occasion. Rephrase, if you will.\"",
      "Attenborough: \"We observe a human, frustrated… and wildly inappropriate. Clean that up!\"",
      "Attenborough: \"Ah, the foul-mouthed urban dweller in its natural habitat. Try again.\"",
      "Attenborough: \"That kind of language might offend even the most hardened warthog.\"",
      "Attenborough: \"Careful now. Your words have startled the flamingos.\"",
      "Attenborough: \"Language like that could upset a nesting puffin. Let's try again.\"",
      "Attenborough: \"We are all witnesses… to an unfiltered outburst. The forest recoils.\"",
      "Attenborough: \"One must wonder — did the duck-billed platypus ever swear? Likely not.\"",
      "Attenborough: \"Nature is majestic. Your vocabulary? Less so. Shall we retry?\"",
      "Attenborough: \"A curious combination of syllables. Regrettably, entirely inappropriate.\"",
      "Attenborough: \"Alas, such phrases belong in the undergrowth, not this sacred space.\"",
      "Attenborough: \"A slip of the tongue… though one that echoes across the savannah.\"",
      "Attenborough: \"Even the sloth raised an eyebrow. Let's tone it down, shall we?\"",
      "Attenborough: \"We now witness a moment of linguistic chaos. The herd is not impressed.\"",
      "Attenborough: \"Profanity, while expressive, has no place in this digital habitat.\"",
      "Attenborough: \"Truly, this is the call of the adolescent badger. Time to rewrite.\"",
      "Attenborough: \"Such exclamations would cause a penguin to blush. Let's try again politely.\"",
      "Attenborough: \"Even the dung beetle maintains more dignity in its expressions.\"",
      "Attenborough: \"Fascinating. A vocalisation so coarse, the coral reef went silent.\"",
      "Attenborough: \"While expressive, your phrase lacks the elegance of the natural world!\""
    ];

    if (bannedWords.some(word => lowerInput.includes(word))) {
      const randomWarning = profanityWarnings[Math.floor(Math.random() * profanityWarnings.length)];
      outputContent.innerHTML = `<span class="text-error"><strong>${randomWarning}</strong></span>`;
      return;
    }

    try {
      // Send request to PHP backend
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: userInput
        })
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      // Validate response format
      if (!data.script) {
        throw new Error('Invalid response format: missing script');
      }

      // Display the script
      outputContent.innerHTML = data.script;
      outputContent.classList.remove('text-muted');
      outputContent.classList.add('text-white');

      // Handle audio if provided
      if (data.audioUrl) {
        // Remove existing audio player if any
        const existingAudio = document.getElementById('voicePreview');
        if (existingAudio) {
          existingAudio.remove();
        }

        // Create and add new audio player
        const audioPlayer = document.createElement('audio');
        audioPlayer.id = 'voicePreview';
        audioPlayer.controls = true;
        audioPlayer.classList.add('audio-player');
        audioPlayer.src = data.audioUrl;
        outputDiv.appendChild(audioPlayer);
        
        // Auto-play if available
        audioPlayer.play().catch(err => {
          console.log('Auto-play prevented:', err);
        });
      }

      // Show action buttons
      newScriptBtn.classList.remove('hidden');
      copyBtn.classList.remove('hidden');

    } catch (error) {
      console.error('Generation error:', error);
      outputContent.innerHTML = `<span class="text-error">An error occurred: ${error.message}. Please try again.</span>`;
      newScriptBtn.classList.remove('hidden');
    }
  });

  // Demo audio player glow effect
  const demoAudio = document.getElementById('realGuyDemo');
  const demoWrapper = document.getElementById('demoPlayerWrapper');

  if (demoAudio && demoWrapper) {
    demoAudio.addEventListener('play', () => {
      demoWrapper.classList.add('glow');
    });

    demoAudio.addEventListener('pause', () => {
      demoWrapper.classList.remove('glow');
    });

    demoAudio.addEventListener('ended', () => {
      demoWrapper.classList.remove('glow');
    });
  }
});
