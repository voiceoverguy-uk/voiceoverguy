<?php

if (isset($_REQUEST['name'],$_REQUEST['email'])) {
      
    $name = $_REQUEST['name'];
    $email = $_REQUEST['email'];
    $message = $_REQUEST['message'];
	
				
	
	$from1 = "VOG Website Form";
	
	$date = date("Y-m-d H:i:s");
      
    $to = 'guy@voiceoverguy.co.uk';

	$subject = "Website enquiry from ".$email."\r\n";
      
    $headers = "From: ".$name." <".$email."> \r\n";
	
	$headers .= "MIME-Version: 1.0\r\n";
//Set the content-type to html
//	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
$headers .= "Content-Type: text/html; charset=utf-8";
	
	
//accept-charset="utf-8
	
$message2 = '<html><body>';
$message2 .= '<h2>Voiceover Guy Website Enquiry</h2>';
$message2 .= '<p><b>Name: </b>'.$name.'<br>';
$message2 .= '<b>Email: </b>'.$email.'<br>';

	
	
	$message2 .= '<h2>'.($message).'</h2>';
	

$message2 .= '</body></html>';
	
	
      
    $send_email = mail($to,$subject,$message2,$headers);
      

    echo ($send_email) ? 'success' : 'error';
	
	
	
	
	
}
	

	
	
      


?>