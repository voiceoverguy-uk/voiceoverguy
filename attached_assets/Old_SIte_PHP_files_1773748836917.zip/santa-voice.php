<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo12.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo12.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seo12.s2'); ?>">

<meta name="Robots" content="index, follow">
<meta name="author" content="Guy Harris">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

  
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />



<link rel="canonical" href="https://www.voiceoverguy.co.uk/santa-voice" /> 
<meta name="copyright" content="© Guy Harris - VoiceoverGuy.co.uk">

<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>

	  
<?php
$reviewData = json_decode(@file_get_contents($_SERVER['DOCUMENT_ROOT']."/api/get-reviews.php"), true);
$ratingValue = $reviewData['rating'] ?? "5.0";
$ratingCount = $reviewData['count'] ?? "117";
?>
<script type="application/ld+json">
{
"@context": "https://schema.org",
"@type": "Service",
"serviceType": "Santa Voiceover",
"name": "Santa Voice – British Father Christmas Voice Over",
"description": "Authentic British Santa voiceover by Guy Harris – the UK's No.1 Voice of
Santa for BBC, ITV, Heart Radio and Tesco. Available for commercials, phone lines, events,
and festive campaigns. Fast turnaround with broadcast-quality audio.",
"provider": {
"@type": "Person",
"name": "Guy Harris",
"url": "https://www.voiceoverguy.co.uk/",
"image": "https://www.voiceoverguy.co.uk/images/guy-harris-profile.jpg",
"sameAs": [
"https://www.linkedin.com/in/voiceoverguy/",
"https://www.youtube.com/user/voiceoverguyharris"
],
 "jobTitle": "British Male Voiceover Artist",
 "worksFor": {
   "@type": "RadioStation",
   "name": "Santa Radio",
   "url": "https://www.santaradio.co.uk/",
   "address": {
     "@type": "PostalAddress",
     "addressCountry": "UK"
   }
 }
},
"areaServed": {
"@type": "Country",
"name": "United Kingdom"
},
"availableChannel": {
"@type": "ServiceChannel",
"serviceLocation": {
"@type": "Place",
"name": "Remote"
},
"availableLanguage": ["English"]
},
"hasOfferCatalog": {
"@type": "OfferCatalog",
"name": "Santa Voice Services",
"itemListElement": [
{
"@type": "Offer",
"itemOffered": {
"@type": "Service",
"name": "Santa Voice for Radio Commercials"
}
},
{
"@type": "Offer",
"itemOffered": {
"@type": "Service",
"name": "Santa Voice for TV Promos"
}
},
{
"@type": "Offer",
"itemOffered": {
"@type": "Service",
"name": "Santa Voice for Events & Phone Systems"
}
}
]
},
"url": "https://www.voiceoverguy.co.uk/santa-voice"
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can I hire Guy Harris for a Santa voiceover?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Guy Harris is the UK’s leading Santa voiceover artist and can be booked for commercials, events, and festive campaigns via the contact page."
      }
    },
    {
      "@type": "Question",
      "name": "Can I get personalised messages from Santa?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, you can book a personalised message from Santa. Use the Santa script generator to also refine your message before booking."
      }
    },
    {
      "@type": "Question",
      "name": "Can I direct a Santa Voiceover recording session remotely?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, clients can direct sessions remotely via Source Connect, Cleanfeed or Zoom. All connections are supported."
      }
    },
    {
      "@type": "Question",
      "name": "Who is the voice of Santa on Heart?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy Harris is the voice of Father Christmas on the Heart Radio Network. His warm, fun and cheeky Santa performance is heard nationwide each December."
      }
    },
    {
      "@type": "Question",
      "name": "Where can I get a British Santa voice?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy Harris delivers one of the UK’s most authentic British Santa voices — traditional, joyful and full of festive charm, perfect for commercials, events and campaigns."
      }
    },
    {
      "@type": "Question",
      "name": "Can I get Santa on my podcast?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, Guy’s iconic Santa voice is available for podcast intros, festive episodes and guest appearances. As an award-winning UK voiceover, his Santa is instantly recognisable."
      }
    },
    {
      "@type": "Question",
      "name": "Who is the Santa voice in the shops?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy’s Santa voice is heard in stores across the UK, including Tesco, ASDA, Poundland, B&M, The Range, Wilko, SPAR, Go Local and many more."
      }
    },
    {
      "@type": "Question",
      "name": "Who is the Santa voice on Go Jetters?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy Harris voices Santa Claus in the Go Jetters North Pole Christmas Special on CBeebies, where the Go Jetters help Santa fix a festive problem."
      }
    },
    {
      "@type": "Question",
      "name": "Who was Santa on Capital on Christmas Day?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy appeared as Santa on Capital on Christmas Day, checking in after his busy night delivering presents and sharing fun festive banter."
      }
    },
    {
      "@type": "Question",
      "name": "Can I talk to Santa live on air?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Guy has years of experience chatting live on air as Santa. Whether it’s for a radio show or podcast, he can join live or pre‑recorded. Prep a few questions for the best responses from the big man himself!"
      }
    },
    {
      "@type": "Question",
      "name": "Who is the voice of Santa on Santa Radio?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy Harris is the voice of Santa on Santa Radio. Broadcasting 365 days a year, Santa Radio delivers a fun traditional British Christmas soundtrack filled with festive music, celebrity MugShots, listener interactions and original Santa content."
      }
    }
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "RadioStation",
  "@id": "https://www.santaradio.co.uk/#station",
  "name": "Santa Radio",
  "url": "https://www.santaradio.co.uk/",
  "description": "Santa Radio is an online Christmas music radio station broadcasting 365 days a year, featuring festive music, celebrity Christmas MugShots and Santa voice features.",
  "areaServed": {
    "@type": "Country",
    "name": "United Kingdom"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "Santa Voice – British Father Christmas Voice Over",
  "url": "https://www.voiceoverguy.co.uk/santa-voice",
  "description": "Authentic British Santa voiceover by Guy Harris – the UK's No.1 Voice of Santa for BBC, ITV, Heart Radio and Tesco.",
  "inLanguage": "en-GB",
  "author": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk"
  },
  "image": "https://www.voiceoverguy.co.uk/assets/images/santa-voice-og.jpg",
  "isPartOf": {
    "@type": "WebSite",
    "name": "VoiceoverGuy",
    "url": "https://www.voiceoverguy.co.uk"
  }
}
</script>
<meta name="last-modified" content="2025-10-01">

<meta name="keywords" content="Santa voice, Father Christmas voiceover, British Santa voice, Christmas voice actor, festive voiceover artist, Guy Harris Santa">
	  
    <!-- Open Graph -->
    <meta property="og:title" content="Santa Voice – British Father Christmas Voice Over">
    <meta property="og:description" content="Authentic British Santa voiceover by Guy Harris – the UK's No.1 Voice of Santa for BBC, ITV, Heart Radio and Tesco. Available for commercials, phone lines, events, and festive campaigns. Fast turnaround with broadcast-quality audio.">
    <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/santa-voice-og.jpg">
    <meta property="og:url" content="https://www.voiceoverguy.co.uk/santa-voice">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="VoiceoverGuy">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Santa Voice – British Father Christmas Voice Over">
    <meta name="twitter:description" content="Authentic British Santa voiceover by Guy Harris – the UK's No.1 Voice of Santa for BBC, ITV, Heart Radio and Tesco.">
    <meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/santa-voice-og.jpg">

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "AudioObject",
  "name": "Santa Voice Showreel 2025 – Guy Harris",
  "description": "A 2025 Santa voiceover demo by Guy Harris, the UK's leading Voice of Santa. Broadcast-quality audio, 53 seconds.",
  "url": "https://www.voiceoverguy.co.uk/assets/audio/santa-voice-showreel-2025-guy-harris.mp3",
  "contentUrl": "https://www.voiceoverguy.co.uk/assets/audio/santa-voice-showreel-2025-guy-harris.mp3",
  "encodingFormat": "audio/mpeg",
  "duration": "PT53S",
  "uploadDate": "2025-01-01T12:00:00+00:00",
  "publisher": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ImageObject",
  "@id": "https://www.voiceoverguy.co.uk/santa-voice#hero-image",
  "contentUrl": "https://www.voiceoverguy.co.uk/assets/images/santa-voice-og.jpg",
  "url": "https://www.voiceoverguy.co.uk/assets/images/santa-voice-og.jpg",
  "encodingFormat": "image/jpeg",
  "width": 1200,
  "height": 630,
  "representativeOfPage": true
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": "https://www.voiceoverguy.co.uk/#website",
  "url": "https://www.voiceoverguy.co.uk/",
  "name": "VoiceoverGuy",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://www.voiceoverguy.co.uk/?s={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "SpeakableSpecification",
  "cssSelector": [
    "h1"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "OfferCatalog",
  "name": "Santa Voiceover Services",
  "url": "https://www.voiceoverguy.co.uk/santa-voice",
  "itemListElement": [
    {
      "@type": "Offer",
      "name": "Santa Voice for Radio Commercials",
      "description": "Professional Santa Claus voiceovers for radio advertising, Christmas promotions and festive brand campaigns.",
      "url": "https://www.voiceoverguy.co.uk/santa-voice"
    },
    {
      "@type": "Offer",
      "name": "Santa Voice for TV Promos",
      "description": "Broadcast-quality British Santa voice for national and regional television promos.",
      "url": "https://www.voiceoverguy.co.uk/santa-voice"
    },
    {
      "@type": "Offer",
      "name": "Santa Voice for Phone Systems & IVR",
      "description": "Warm, friendly Santa messages for business phone systems, IVR menus and Christmas customer greetings.",
      "url": "https://www.voiceoverguy.co.uk/santa-voice"
    },
    {
      "@type": "Offer",
      "name": "Santa Voice for Events & Shows",
      "description": "Live or pre-recorded Father Christmas announcements for festive events, grottos and Santa experiences.",
      "url": "https://www.voiceoverguy.co.uk/santa-voice"
    },
    {
      "@type": "Offer",
      "name": "Personalised Santa Messages",
      "description": "Custom Santa recordings for children, families and festive surprises.",
      "url": "https://www.voiceoverguy.co.uk/santa-voice"
    }
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://www.voiceoverguy.co.uk"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Santa Voice",
      "item": "https://www.voiceoverguy.co.uk/santa-voice"
    }
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "The UK's Official No.1 Voice of Santa – Guy Harris",
  "description": "Guy Harris is the UK's busiest Santa voice for BBC Radio 2, ITV, Heart, Santa Radio, Capital and more. A fun, warm and iconic Father Christmas voice.",
  "thumbnailUrl": "https://img.youtube.com/vi/P44bGiUI0vE/maxresdefault.jpg",
  "uploadDate": "2025-01-01T12:00:00+00:00",
  "duration": "PT1M00S",
  "contentUrl": "https://www.youtube.com/watch?v=P44bGiUI0vE",
  "embedUrl": "https://www.youtube.com/embed/P44bGiUI0vE",
  "publisher": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "CBeebies Go Jetters – Santa Voice by Guy Harris",
  "description": "Guy Harris voices Santa Claus in the Go Jetters North Pole Christmas Special on CBeebies.",
  "thumbnailUrl": "https://img.youtube.com/vi/yi-4Fm40nmE/maxresdefault.jpg",
  "uploadDate": "2025-01-01T12:00:00+00:00",
  "duration": "PT1M00S",
  "contentUrl": "https://www.youtube.com/watch?v=yi-4Fm40nmE",
  "embedUrl": "https://www.youtube.com/embed/yi-4Fm40nmE",
  "publisher": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk"
  }
}
</script>
	</head>
<body>
  <span id="schema-rating-count" style="display:none;"><?php echo $ratingCount; ?></span>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo html_entity_decode(Config::get('seo12.s3')); ?>



</div>
</div>
</div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">


<div id="dynamic-review-block" style="background:#fff3f3;border:3px solid #cc0000;padding:25px;margin-bottom:25px;border-radius:10px;text-align:center;box-shadow:0 0 12px rgba(200,0,0,0.25);">
  <h2 id="review-title" style="margin-top:0;font-size:30px;color:#b30000;font-weight:800;">
    🎅 Rated 5.0 ★★★★★ by <span id="review-count">117</span> Happy Clients
  </h2>
  <p style="font-size:18px;color:#333;margin-bottom:18px;">
    Trusted by BBC, ITV, Heart, Tesco and thousands of producers across the UK.
  </p>
  <a href="https://www.google.com/search?q=VoiceoverGuy+Wakefield&ludocid=13238741027900894876#lrd=0x48795b5b8bb4d61d:0xb7a63f64e244a5ec,1" target="_blank" rel="noopener"
     style="display:inline-block;background:#cc0000;color:white;padding:12px 28px;border-radius:6px;font-weight:700;font-size:17px;text-decoration:none;">
     ⭐ Read Google Reviews
  </a>
</div>

<script>
  fetch('/api/get-reviews.php')
    .then(r => r.json())
    .then(data => {
      if (data.count) {
        document.getElementById('review-count').textContent = data.count;
      }
    })
    .catch(err => console.error('Review API error:', err));
</script>
<iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/1232894&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true" width="100%" height="315" frameborder="no" scrolling="no"></iframe><br />

</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">
<div class="row">

<div class="col-md-6" >

<?php echo html_entity_decode(Config::get('seo12.s4')); ?>
</div>

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo12.s20');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo12.s7'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo12.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo12.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo12.s8'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo12.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo12.s5')); ?>
</div>


</div>

<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo12.s6')); ?>
<iframe style="width: 100%; height: 100px;" src="https://tunein.com/embed/player/s252505/" width="300" height="150" frameborder="no" scrolling="no"></iframe>
</div>

<div class="col-md-6" >
<br>
<a href="voiceover-cartoons" title="Guy Harris - Santa Voice" ><img alt="Guy Harris - Santa Voice" title="Guy Harris - Santa Voice" class="img-responsive"   src="assets/images/cartoons/Voiceover-Cartoon-Santa-Style.jpg" /></a>

</div>


</div>







<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Container-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

  <?php include("assets/inc/footer.php"); ?>
    
</body>
</html>