<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo Config::get('faqseo2.faqs7'); ?></title>
<meta name="description" content="<?php echo Config::get('faqseo2.faqs8'); ?>">
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">
<meta name="twitter:description" content="<?php echo Config::get('faqseo2.faqs8'); ?>">
<meta name="Robots" content="index, follow">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />
<link rel="canonical" href="https://www.voiceoverguy.co.uk/FAQ" /> 
<link href="assets/css/all.css" rel="stylesheet">
<script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	
	
	<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "@id": "https://www.voiceoverguy.co.uk/FAQ#faq",
  "url": "https://www.voiceoverguy.co.uk/FAQ",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is your turnaround time?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Same day in most cases, with standard projects delivered within 24 hours. I\u2019m in the studio every day, so if you have an urgent job or last-minute change, I can usually accommodate it quickly."
      }
    },
    {
      "@type": "Question",
      "name": "What audio formats do you deliver?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Most clients request WAV or MP3, but I can also provide AIFF or other formats on request. All audio is recorded in my broadcast-quality studio so it drops straight into your edit."
      }
    },
    {
      "@type": "Question",
      "name": "Can I direct a voiceover session live?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. You can direct the session live via Cleanfeed, Source-Connect, Zoom, or a simple phone patch. This way you can give feedback in real time and sign off the read before we wrap."
      }
    },
    {
      "@type": "Question",
      "name": "What rights do I get with the voiceover?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Usage and broadcast rights are agreed in advance so everything is clear. We\u2019ll confirm where and how long the audio will be used \u2013 for example, local radio, national TV, online, internal, or paid media \u2013 and licence it appropriately."
      }
    },
    {
      "@type": "Question",
      "name": "Do you provide revisions?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. If I make a mistake, or the read needs a small tweak, I\u2019m happy to fix it. Larger script changes or new scripts may incur an additional session fee, but I always keep things fair and transparent."
      }
    }
  ]
}
	  </script>
	
	    <style>
   
        .faq-item {
      border-bottom: 1px solid #ddd;
      padding: 1rem 0;
    }

    .faq-question {
      font-weight: 600;
      cursor: pointer;
      position: relative;
      padding-right: 1.5rem;
    }

    .faq-question::after {
      content: '+';
      position: absolute;
      right: 0;
      top: 0;
      font-weight: bold;
      font-size: 1.5rem;
      transition: transform 0.2s ease;
    }

    .faq-item.active .faq-question::after {
      content: '-';
      transform: rotate(180deg);
    }

    .faq-answer {
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.3s ease;
      padding-left: 0.5rem;
      color: #555;
    }

    .faq-item.active .faq-answer {
      max-height: 200px; /* enough for a short answer */
      margin-top: 0.5rem;
    }

  </style>
	
	</head>
<body>
	
	
	
	

  

<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>

    


<div class="container"  >
<div class="row">
<div class="col-md-12">
<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container">
<?php include("assets/inc/menu.php"); ?>
</div></div></div></div>

	
<div id="parallax">
<div class="container">
<div class="row">

	
<div class="col-md-12" >
	

	<?php echo html_entity_decode(Config::get('faqseo2.faqs1')); ?>

</div></div>

<div class="bar"></div>

	
	
<div class="row">
<div class="col-md-6" >
	
		 

  <div class="faq-item">
	  <?php echo html_entity_decode(Config::get('faqseo2.faqs2')); ?>
  </div>

  <div class="faq-item">
   <?php echo html_entity_decode(Config::get('faqseo2.faqs3')); ?>
  </div>

  <div class="faq-item">
    <?php echo html_entity_decode(Config::get('faqseo2.faqs4')); ?>
  </div>

  <div class="faq-item">
   <?php echo html_entity_decode(Config::get('faqseo2.faqs5')); ?>
  </div>

  <div class="faq-item">
   <?php echo html_entity_decode(Config::get('faqseo2.faqs6')); ?>
  </div>

	
	
	
<?php if (empty(html_entity_decode(Config::get('faqseo2.faqs9')))) {}
else{ ?>
<div class="faq-item">
 <?php echo html_entity_decode(Config::get('faqseo2.faqs9')); ?>
 </div>
 <?php } ?>
	
	
<?php if (empty(html_entity_decode(Config::get('faqseo2.faqs10')))) {}
else{ ?>
<div class="faq-item">
 <?php echo html_entity_decode(Config::get('faqseo2.faqs10')); ?>
 </div>
 <?php } ?>
	
	
	
	<?php if (empty(html_entity_decode(Config::get('faqseo2.faqs11')))) {}
else{ ?>
<div class="faq-item">
 <?php echo html_entity_decode(Config::get('faqseo2.faqs11')); ?>
 </div>
 <?php } ?>
	
	
	<?php if (empty(html_entity_decode(Config::get('faqseo2.faqs12')))) {}
else{ ?>
<div class="faq-item">
 <?php echo html_entity_decode(Config::get('faqseo2.faqs12')); ?>
 </div>
 <?php } ?>
	
	
	<?php if (empty(html_entity_decode(Config::get('faqseo2.faqs13')))) {}
else{ ?>
<div class="faq-item">
 <?php echo html_entity_decode(Config::get('faqseo2.faqs13')); ?>
 </div>
 <?php } ?>
	
	
	 <script>
        function updateTime() {
            const date = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            const time = date.toLocaleTimeString();
            const day = date.toLocaleDateString(undefined, options);
            document.getElementById('time').innerHTML =
                `${time}`;
        }

        setInterval(updateTime, 1000);
        updateTime();
    </script>
	
	
	
	
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      document.querySelectorAll('.faq-question').forEach(function(q) {
        q.addEventListener('click', function() {
          var item = q.closest('.faq-item') || q.parentElement;
          if (item) {
            item.classList.toggle('active');
          }
        });
      });
    });
  </script>




</div>



<div class="col-md-6">
<br>
<img src="assets/images/guy-award-winner.jpg" width="527" height="1000" class="img-responsive imageborder"  title="Guy Harris – Award-Winning British Male Voiceover Artist" alt="Guy Harris – Award-Winning British Male Voiceover Artist">
</div>

<!-- Start Second Row-->
</div>

<div class="bar"></div>

<div style="text-align:center; max-width:900px; margin:40px auto 60px auto; font-size:1.1em; line-height:1.6em;">
  <p>
    Still have a question that isn&#39;t covered here, or ready to book a session?
  </p>
  <p>
    <a href="/contact-guy" class="isred" title="Contact Guy about a voiceover">Get in touch</a> and I&#39;ll be happy to help, quote, or advise on the best way to approach your project.
  </p>
</div>









<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

<?php include("assets/inc/footer.php"); ?>
    
</body>
</html>