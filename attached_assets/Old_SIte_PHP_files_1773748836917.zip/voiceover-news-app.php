

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


<link href="assets/css/all.css" rel="stylesheet">
<script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script></head>



<body>


<div class="container">
<div class="row">

 <?php 

$num_rec_per_page=100;

mysql_connect('localhost','cl10-nreblog','earwax69');

mysql_select_db('cl10-nreblog');

if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 

$start_from = ($page-1) * $num_rec_per_page; 

$sql = "SELECT * FROM messages2 WHERE rating = '5' ORDER BY rand() LIMIT $start_from, $num_rec_per_page"; 

$rs_result = mysql_query ($sql); 

?> 



<?php 

while ($row = mysql_fetch_assoc($rs_result)) { 

?> 


<div class="col-md-12"  >


<p style="font-size:32px; text-align:center"><strong><?php echo $row['page_title']; ?></strong></p>

<a href="testblogapp.php?id=<?php echo $row['id']; ?>" >
<div class="effect1">
<img class="img-responsive imageborder center-block" style=" border:1px solid #999"   src="assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</a>



<p style="font-size:32px; text-align:center"><?php echo $row['hometext']; ?> <a href="testblogapp.php?id=<?php echo $row['id']; ?>" >Read more</a> </p>

<div class="bar"></div>


      </div>
      
    

<?php 

}; 



?> 





 <?php 

$num_rec_per_page=100;

mysql_connect('localhost','cl10-nreblog','earwax69');

mysql_select_db('cl10-nreblog');

if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 

$start_from = ($page-1) * $num_rec_per_page; 

$sql = "SELECT * FROM messages2 WHERE rating = '3' ORDER BY rand() LIMIT $start_from, $num_rec_per_page"; 

$rs_result = mysql_query ($sql); 

?> 



<?php 

while ($row = mysql_fetch_assoc($rs_result)) { 

?> 


<div class="col-md-12"  >


<p style="font-size:32px; text-align:center"><strong><?php echo $row['page_title']; ?></strong></p>

<a href="testblogapp.php?id=<?php echo $row['id']; ?>" >
<div class="effect1">
<img class="img-responsive imageborder center-block" style=" border:1px solid #999"   src="assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</a>



<p style="font-size:32px; text-align:center"><?php echo $row['hometext']; ?> <a href="testblogapp.php?id=<?php echo $row['id']; ?>" >Read more</a> </p>

<div class="bar"></div>


      </div>
      
    

<?php 

}; 



?> 



 <?php 

$num_rec_per_page=40;

mysql_connect('localhost','cl10-nreblog','earwax69');

mysql_select_db('cl10-nreblog');

if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 

$start_from = ($page-1) * $num_rec_per_page; 

$sql = "SELECT * FROM messages2 WHERE rating = '0' ORDER BY rand() LIMIT $start_from, $num_rec_per_page"; 

$rs_result = mysql_query ($sql); 

?> 



<?php 

while ($row = mysql_fetch_assoc($rs_result)) { 

?> 


<div class="col-md-12"  >


<p style="font-size:32px; text-align:center"><strong><?php echo $row['page_title']; ?></strong></p>

<a href="testblogapp.php?id=<?php echo $row['id']; ?>" >
<div class="effect1">
<img class="img-responsive imageborder center-block" style=" border:1px solid #999"   src="assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</a>



<p style="font-size:32px; text-align:center"><?php echo $row['hometext']; ?> <a href="testblogapp.php?id=<?php echo $row['id']; ?>" >Read more</a> </p>

<div class="bar"></div>


      </div>
      
    

<?php 

}; 



?> 







</div>



<div style="text-align:center; font-size:36px">

<?php 

$sql = "SELECT * FROM messages2"; 

$rs_result = mysql_query($sql); //run the query

$total_records = mysql_num_rows($rs_result);  //count number of records

$total_pages = ceil($total_records / $num_rec_per_page); 



//echo "<a href='voiceover-news-app.php?page=1'>".'<i class="fa fa-arrow-left fa-1x" aria-hidden="true"></i>'."</a> "; // Goto 1st page  



for ($i=1; $i<=$total_pages; $i++) { 
//
          echo "<a href='voiceover-news-app.php?page=".$i."'>".$i."</a> "; 

}; 

//echo "<a href=allblog.php?page=$total_pages'>".'<i class="fa fa-arrow-right fa-1x" aria-hidden="true"></i>'."</a> "; // Goto last page

?>
<br><br><br><br><br><br>

</div>



</div>



</div>


</div>




<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/scripts.js"></script>

<script type="text/javascript">
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-19338316-2']);
_gaq.push(['_trackPageview']);
(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
</script>

    
</body>
</html>

