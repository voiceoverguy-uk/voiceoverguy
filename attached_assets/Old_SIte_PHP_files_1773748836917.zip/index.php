<?php require_once 'guyadmin/app/init.php';?>
<!DOCTYPE html>
<html lang="en-GB">
	<head>
		<!-- SEO best practice: UTF-8 charset and descriptive title -->
		<meta charset="UTF-8">
		<title>British Male Voiceover | Guy Harris – UK Voice Artist</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">	
		<link rel="canonical" href="https://www.voiceoverguy.co.uk" />
		<meta name="description" content="<?php echo html_entity_decode(Config::get('seo.s8')); ?>">
		
		<meta name="msvalidate.01" content="781CD99316BFBC157AA14BFEE683B5E7" />
		<meta name="twitter:card" content="summary" />
		<meta name="twitter:site" content="@voiceoverman" />
		<meta name="twitter:title" content="<?php echo html_entity_decode(Config::get('seo.s7')); ?>" />
		<meta name="twitter:description" content="<?php echo html_entity_decode(Config::get('seo.s8')); ?>" />
		<meta name="twitter:url" content="https://www.voiceoverguy.co.uk" />
		<meta name="twitter:image" content="https://pbs.twimg.com/profile_images/770927533437120512/twHj7UTs_400x400.jpg" />
		<meta name="Robots" content="index, follow">
		<meta name="apple-itunes-app" content="app-id=526007008, affiliate-data=myAffiliateData, app-argument=myURL">
        <meta property="og:url" content="https://www.voiceoverguy.co.uk/" />
        <meta property="og:type" content="website" />
        <meta property="og:title" content="VoiceoverGuy | Guy Harris – British Male Voice Over" />
        <meta property="og:description" content="Guy Harris is a trusted UK voiceover artist. From Santa to Attenborough, pirate to game show host, hear the voices now." />
        <meta property="og:image" content="https://www.voiceoverguy.co.uk/images/og-image.jpg">
        <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/og-image.jpg" />
        <meta property="og:image:alt" content="Guy Harris voiceover characters – Pirate, Santa, Ghost, David Attenborough, and more." />
        <meta property="fb:app_id" content="1234567890" />
		<meta name="p:domain_verify" content="010f4220855ec1039122693b4aef8bc1"/>
		<!--<link rel='stylesheet' id='options_typography_Ubuntu-400-css'  href='assets/css/fonts.css' type='text/css' media='all' />-->
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
		<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
		<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
		<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
		<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
		<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
		<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
		<meta name="application-name" content="&nbsp;"/>
		<meta name="msapplication-TileColor" content="#FFFFFF" />
		<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
		<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
		<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
		<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
		<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />
		
<!-- Load Google Fonts (Ubuntu & Open Sans) -->
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Ubuntu&display=swap" rel="stylesheet">
<link rel="preload" as="image" href="assets/images/guy-harris-voiceover.webp" type="image/webp">

<!-- Site Stylesheets -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/custom.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<link rel="stylesheet" type="text/css" href="assets/fancybox/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
<link rel="stylesheet" type="text/css" href="assets/slick/slick.css">
<link rel="stylesheet" type="text/css" href="assets/nav/assets/css/MegaNavbar.min.css"/>

<!-- Optional: Legacy/alternate nav skin -->
<!--
<link rel="stylesheet" type="text/css" href="assets/nav/assets/css/skins/navbar-inverse.css" title="inverse">
<link rel="stylesheet" type="text/css" href="assets/nav/assets/css/animation/animation.css" title="inverse">
-->

<!-- jQuery for toggleDiv -->
<script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
<script type="text/javascript">
  function toggleDiv(divId) {
    $("#" + divId).slideToggle();							
  }
</script>
		
		<script type="text/javascript">
			$(function(){
				$(".search").keyup(function() 
				{ 
					var searchid = $(this).val();
					var dataString = 'search='+ searchid;
					if(searchid!='')
					{
						$.ajax({
							type: "POST",
							url: "search/search.php",
							data: dataString,
							cache: false,
							success: function(html)
							{
								$("#result").html(html).show();
							}
						});
					}return false;    
				});
				
				
				$(document).mouseup(function (e)
				{
					
					jQuery("#result").fadeOut(); 
				});
				
				
				
			});
		</script>
		<style type="text/css">
			.audio-row-fix {
			    position: relative;
			    z-index: 5;
			}
			.audio-row-fix audio {
			    position: relative;
			    z-index: 10;
			}
			
			
			.content{
			width:90%;
			max-width:650px;
			margin:0 auto;
			}
			#searchid
			{
			width:100%;
			height:50px;
			border:solid 1px #999;
			padding:20px;
			font-size:14px;
			margin-bottom:21px;
			
			}
			#result
			{
			position:absolute;
			width:90%;
			max-width:650px;
			padding:10px;
			display:none;
			margin-top:-1px;
			border-top:0px;
			overflow:hidden;
			border:1px #999 solid;
			background-color: white;
			max-height:460px;
			overflow:scroll;
			}
			.show
			{
			padding:3px; 
			
			font-size:10px; 
			
			}
			.show:hover
			{
			
			background:#4c66a4;
			color:#FFF;
			cursor:pointer;
			}
			
			
			
		</style>
		
		
		<!-- Google tag (gtag.js) -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-94QXHW47HG"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());
		  gtag('config', 'G-94QXHW47HG');
		</script>
		
		
        <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/og-image.jpg" />
        <meta property="og:image:alt" content="Guy Harris voiceover characters – Pirate, Santa, Ghost, David Attenborough, and more." />
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/og-image.jpg">
		
<!-- Unified Schema.org JSON-LD -->
<?php
  $reviewData = @file_get_contents($_SERVER['DOCUMENT_ROOT'] . "/api/get-reviews.php");
  $reviewJSON = json_decode($reviewData, true);
  $dynamicRating = isset($reviewJSON['rating']) ? $reviewJSON['rating'] : 5;
  $dynamicCount  = isset($reviewJSON['count'])  ? $reviewJSON['count']  : 117;
?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Person",
  "@id": "https://www.voiceoverguy.co.uk/#guyharris",
  "name": "Guy Harris – VoiceoverGuy",
  "alternateName": "VoiceoverGuy",
  "url": "https://www.voiceoverguy.co.uk",
  "image": "https://www.voiceoverguy.co.uk/images/guy-harris-profile.jpg",
  "jobTitle": "British Male Voiceover Artist",
  "description": "Guy Harris is an award-winning British male voiceover artist with over 25 years of experience and more than 200,000 voiceovers. Known for his commercial reads, character voices, explainer narration, David Attenborough impression and as the UK's No.1 Voice of Santa.",
  "gender": "Male",
  "nationality": "British",
  "worksFor": {
    "@type": "Organization",
    "name": "VoiceoverGuy",
    "url": "https://www.voiceoverguy.co.uk"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "Customer Service",
    "email": "guy@voiceoverguy.co.uk",
    "telephone": "+44-7973-350178",
    "areaServed": "GB",
    "availableLanguage": "en-GB"
  },
  "sameAs": [
    "https://www.linkedin.com/in/voiceoverguy/",
    "https://www.youtube.com/user/voiceoverguyharris",
    "https://soundcloud.com/voiceoverguy"
  ],
  "award": [
    "VOX Award – Best Male Voiceover (Winner)",
    "SOVAS – Outstanding Commercial Voiceover (Finalist)",
    "SOVAS – Outstanding Animation Character (Finalist)",
    "SOVAS – Outstanding Promo Voice (Finalist)"
  ],
  "hasOccupation": {
    "@type": "Occupation",
    "name": "British Male Voiceover Artist",
    "occupationLocation": {
      "@type": "Country",
      "name": "United Kingdom"
    },
    "skills": [
      "Commercial Voiceovers",
      "Character Voices",
      "David Attenborough Voice Style",
      "Santa Voice",
      "Explainer Video Narration",
      "Game Voices",
      "E-Learning Narration",
      "Broadcast-quality Audio Production"
    ]
  },
  "affiliation": [
    {
      "@type": "Organization",
      "name": "BBC",
      "url": "https://www.bbc.co.uk"
    },
    {
      "@type": "Organization",
      "name": "ITV",
      "url": "https://www.itv.com"
    },
    {
      "@type": "Organization",
      "name": "Disney",
      "url": "https://www.disney.co.uk"
    }
  ],
  "knowsAbout": [
    "British Male Voiceover",
    "Commercial Voiceover",
    "TV & Radio Ad Voiceovers",
    "Explainer Videos",
    "Narration",
    "Character Voice Acting",
    "Game Trailer Voice",
    "David Attenborough Impression",
    "Santa Voiceover",
    "Voice of God",
    "Voice of God Announcer",
    "Event Voiceovers",
    "Awards Voiceover"
  ],
  "subjectOf": {
    "@type": "LocalBusiness",
    "@id": "https://www.voiceoverguy.co.uk/#business",
    "name": "Guy Harris – VoiceoverGuy",
    "url": "https://www.voiceoverguy.co.uk",
    "image": "https://www.voiceoverguy.co.uk/images/guy-harris-profile.jpg",
    "logo": "https://www.voiceoverguy.co.uk/assets/images/logo-square.png",
    "priceRange": "£100 - £5000",
    "telephone": "+44-7973-350178",
    "email": "guy@voiceoverguy.co.uk",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Wakefield",
      "addressRegion": "West Yorkshire",
      "addressCountry": "GB"
    },
    "openingHours": "Mo-Sa 07:00-21:00",
    "description": "Professional British male voiceover studio providing broadcast-quality audio with fast turnaround, reliable delivery and a full range of character voices including Santa and Attenborough."
    ,
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "<?php echo $dynamicRating; ?>",
      "ratingCount": "<?php echo $dynamicCount; ?>",
      "bestRating": "5",
      "worstRating": "1"
    }
  }
}
</script>
	</head>
	<body>
		
		
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12" id="maintopnav" >
					
					<nav class="topnav">
						<?php include("assets/inc/socials.php"); ?>
					</nav>
					
				</div>
			</div>
		</div>
		
		
<!-- Main Body on homepage -->
		
		<div class="container"  >
			<div class="row">
				
				<div class="col-md-12">
					<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy" rel="noopener noreferrer">
					  <img src="assets/images/guy-harris-voiceover.png" alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo">
					</a><br>
					<div class="container">
						<?php include("assets/inc/menu.php"); ?>
				
		
		
		
		
		<div id="parallax">
			<div class="container">
				<div class="row text-center" >
					
	
					<h1><?php echo html_entity_decode(Config::get('seo.s1')); ?></h1>
					
					<h2><?php echo html_entity_decode(Config::get('seo.s2')); ?></h2>
					
<!-- TODO: Optimise or self-host this asset if not already local. Ensure the MP3 is hosted in /assets/audio/ for best performance. -->


					<audio controls preload="auto" style="max-width:330px; margin-top: -7px">
						<source src="/assets/audio/guy-harris-voiceoverguy-commercial-showreel.mp3" type="audio/mpeg">
						Your browser does not support the HTML5 Audio element.
					</audio>
					 <div style="height: 2px; background: linear-gradient(to right, transparent, #666, transparent); margin: 1rem 0;"></div> 
					<p><?php echo html_entity_decode(Config::get('seo.s3')); ?></p>

					<!-- Dynamic Google Review Counter -->
					<script>
					fetch('/api/get-reviews.php')
					  .then(r => r.json())
					  .then(d => {
					    const el = document.getElementById('home-review-count');
					    if (el && d.count) el.textContent = d.count;
					  });
					</script>
					
					<div class="bar"></div>



<!-- 3 mp3 demos on homepage -->

					<div class="row audio-row-fix">
					<div class="col-md-4" >
						<audio controls preload="auto">
							<source src="/assets/audio/guy-harris-voiceoverguy-commercial-showreel.mp3" type="audio/mpeg">
							Your browser does not support the HTML5 Audio element.
						</audio>
						<br><span class="homesections"><?php echo html_entity_decode(Config::get('seo.ts1')); ?></span><br><br>
					</div>
					
					<div class="col-md-4">
						<audio controls preload="auto">
							<source src="/assets/audio/guy-harris-voiceoverguy-character-showreel.mp3" type="audio/mpeg">
							Your browser does not support the HTML5 Audio element.
						</audio>
						<br><span class="homesections"><?php echo html_entity_decode(Config::get('seo.ts2'));?></span><br><br><br>
					</div>
					
					<div class="col-md-4">
						<audio controls preload="auto">
							<source src="/assets/audio/guy-harris-voiceoverguy-explainer-video-showreel.mp3" type="audio/mpeg">
							Your browser does not support the HTML5 Audio element.
						</audio>
						<br><span class="homesections"><?php echo html_entity_decode(Config::get('seo.ts3'));?></span><br><br><br>
					</div>
					</div><!-- end audio row -->
					
					
<!-- 6 Video demos on homepage -->
					
<div style="text-align:center; max-width:900px; margin:20px auto 40px auto; font-size:1.05em; line-height:1.5em; opacity:0.9;">
  <p>
    Not sure where to start? Here are my most requested styles — from commercial reads to 
    character voices. Each video below gives you a quick taste of how I can bring your project to life.
  </p>
</div>

					
					<div class="col-md-4 text-center" >
						<a class="fancybox-media" href="<?php echo Config::get('seo.nvideo1') ?>"  title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" ><img src="<?php echo Config::get('seo.nvideo2') ?>" alt="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" class="homevideos" loading="lazy"/></a>
						<br /><span class="homesections"><?php echo html_entity_decode(Config::get('seo.ts4')); ?></span><br><br>
					</div>
					
					<div class="col-md-4 text-center">
						<a class="fancybox-media" href="<?php echo Config::get('seo.nvideo3') ?>"  title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>"  ><img src="<?php echo Config::get('seo.nvideo4') ?>" alt="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" class="homevideos" loading="lazy" /></a> 
						<br /><span class="homesections"><?php echo html_entity_decode(Config::get('seo.ts5')); ?></span><br><br>
					</div>
					
					<div class="col-md-4 text-center">
						<a class="fancybox-media" href="<?php echo Config::get('seo.nvideo5') ?>"  title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>"><img src="<?php echo Config::get('seo.nvideo6') ?>" alt="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" class="homevideos" loading="lazy" /></a> 
						<br /><span class="homesections"><?php echo html_entity_decode(Config::get('seo.ts6'));?></span><br><br>
					</div>
					
					<div class="col-md-4 text-center">
						<a class="fancybox-media" href="<?php echo Config::get('seo.nvideo7') ?>"  title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>"><img src="<?php echo Config::get('seo.nvideo8') ?>" alt="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" class="homevideos" loading="lazy" /></a>
						<br /><span class="homesections"><?php echo html_entity_decode(Config::get('seo.ts7'));?></span><br><br>
					</div>
					
					<div class="col-md-4 text-center">
						<a class="fancybox-media" href="<?php echo Config::get('seo.nvideo9') ?>"  title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>"><img src="<?php echo Config::get('seo.nvideo10') ?>" alt="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" class="homevideos" loading="lazy" /></a>
						<br /><span class="homesections"><?php echo html_entity_decode(Config::get('seo.ts8')); ?></span><br><br>
					</div>
					
					<div class="col-md-4 text-center">
						<a class="fancybox-media" href="<?php echo Config::get('seo.nvideo11') ?>"  title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>"><img src="<?php echo Config::get('seo.nvideo12') ?>" alt="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>" title="<?php echo html_entity_decode(Config::get('seo.ts10'));; ?>s" class="homevideos" loading="lazy"  /></a>
						<br /><span class="homesections"><?php echo html_entity_decode(Config::get('seo.ts9')); ?></span>
						
							
						<br><br>
					</div><br><br>
					
<!-- Client images on homepage -->
					
						<div class="col-md-12">
						<div class="bar"></div>
							
						<section class="regular slider">
							<?php echo html_entity_decode(Config::get('seo27.s1')); ?>
						</section>
							<div class="bar"></div>
					</div>
		
<!-- 6 text boxes on homepage -->
			
					
					<div class="col-md-4">
						<h2 class="ident"><span class="fa fa-globe"></span> <?php echo html_entity_decode(Config::get('seo.tts1')); ?></h2>
						<p><?php echo html_entity_decode(Config::get('seo.tts7')); ?></p>
					</div>
					
					<div class="col-md-4">
						<h2 class="ident"><span class="fa fa-rocket"></span> <?php echo html_entity_decode(Config::get('seo.tts2')); ?></h2>
						<p><?php echo html_entity_decode(Config::get('seo.tts8')); ?></p>
					</div>
					
					<div class="col-md-4">
						<h2 class="ident"><span class="fa fa-map-marker"></span> <?php echo html_entity_decode(Config::get('seo.tts3')); ?></h2>
						<p><?php echo html_entity_decode(Config::get('seo.tts9')); ?></p>
					</div>
					
					
					<div class="col-md-4">
						<h2 class="ident"><span class="fa fa-pencil-square-o"></span> <?php echo html_entity_decode(Config::get('seo.tts4'));?></h2>
						<p><?php echo html_entity_decode(Config::get('seo.tts10')); ?></p><br>
					</div>
					
					<div class="col-md-4">
						<h2 class="ident"><span class="fa fa-microphone"></span> <?php echo html_entity_decode(Config::get('seo.tts5')); ?></h2>
						<p><?php echo html_entity_decode(Config::get('seo.tts11')); ?></p><br>
					</div>
					
					<div class="col-md-4">
						<h2 class="ident"><span class="fa fa-desktop"></span> <?php echo html_entity_decode(Config::get('seo.tts6')); ?></h2>
						<p><?php echo html_entity_decode(Config::get('seo.tts12')); ?></p><br>
					</div>
					
					
			
					
					</div></div></div>
			
		
			<div id="parallax">
			<div class="container">
				<div class="row text-center" >
			
				
					<div class="bar"></div>
					
				
<!-- Latest Voiceover News on homepage -->
		
					<h2 class="text-center">
						
						
						<span class="isred">Latest Voiceover News <i class="fa fa-newspaper-o" ></i></span></h2>
					
					<br>
				
					<?php echo html_entity_decode(Config::get('seo.s9')); ?>
					
					
				</div></div>
					
					
				
				
			
			
			
			
			
			
			
																							
				<!-- Start Footer-->
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12" id="newfooter">
							
							<?php echo html_entity_decode(Config::get('seo28.s1')); ?>   
							<?php include("assets/inc/socials.php"); ?>
						<br></div></div></div>
						
						<?php include("assets/inc/footerhome.php"); ?>
						
						
		</body>
	</html>		