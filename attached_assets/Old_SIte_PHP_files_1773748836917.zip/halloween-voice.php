<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo17.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo17.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">
<meta name="twitter:description" content="<?php echo Config::get('seo17.s2'); ?>">
<meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/halloween-voice-og.jpg">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:title" content="Halloween Voice – Spooky & Scary Voiceovers by Guy Harris">
<meta property="og:description" content="From Dracula to Vincent Price, Guy Harris is the go-to voice for Halloween – BBC Radio 1, Thorpe Park, Asda, Poundland, and more. Book your spooky voice today.">
<meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/halloween-voice-og.jpg">
<meta property="og:url" content="https://www.voiceoverguy.co.uk/halloween-voice">

<meta name="Robots" content="index, follow">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
 
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" /> 

<link rel="canonical" href="https://www.voiceoverguy.co.uk/halloween-voice" /> 
<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	  
	  
	  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://www.voiceoverguy.co.uk/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Halloween Voice",
      "item": "https://www.voiceoverguy.co.uk/halloween-voice"
    }
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": "https://www.voiceoverguy.co.uk/#localbusiness",
  "name": "Guy Harris Voiceover",
  "url": "https://www.voiceoverguy.co.uk/",
  "logo": "https://www.voiceoverguy.co.uk/images/guy-harris-profile.jpg",
  "image": "https://www.voiceoverguy.co.uk/images/guy-harris-profile.jpg",
  "description": "British male voiceover artist specialising in character voices, commercials, promos and Halloween voiceovers.",
  "address": {
    "@type": "PostalAddress",
    "addressCountry": "UK"
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "AudioObject",
  "@id": "https://www.voiceoverguy.co.uk/halloween-voice#audio",
  "name": "Halloween Voiceover Showreel – Guy Harris",
  "description": "Spooky and fun Halloween voice styles including Dracula, Vincent Price and Joker tones.",
  "contentUrl": "https://www.voiceoverguy.co.uk/assets/audio/guy-harris-voiceoverguy-halloween-showreel.mp3",
  "url": "https://www.voiceoverguy.co.uk/assets/audio/guy-harris-voiceoverguy-halloween-showreel.mp3",
  "duration": "PT1M2S",
  "encodingFormat": "audio/mpeg",
  "uploadDate": "2024-10-01T12:00:00+00:00",
  "author": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk/"
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "@id": "https://www.voiceoverguy.co.uk/halloween-voice#video1",
  "name": "Halloween Voices – Spooky Voiceovers – Dracula & Vincent Price",
  "description": "A showcase of spooky Halloween voiceovers including Vincent Price and Dracula styles.",
  "thumbnailUrl": "https://i.ytimg.com/vi/bmMpk16zuSs/mqdefault.jpg",
  "uploadDate": "2015-10-22T12:00:00+00:00",
  "embedUrl": "https://www.youtube.com/embed/bmMpk16zuSs",
  "contentUrl": "https://www.youtube.com/watch?v=bmMpk16zuSs"
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "@id": "https://www.voiceoverguy.co.uk/halloween-voice#video2",
  "name": "Joker Impression – The Dark Knight",
  "description": "A Joker voice impression inspired by Heath Ledger, ideal for spooky promos and villain trailers.",
  "thumbnailUrl": "https://i.ytimg.com/vi/OMlBk5QBnyM/mqdefault.jpg",
  "uploadDate": "2014-09-17T12:00:00+00:00",
  "embedUrl": "https://www.youtube.com/embed/OMlBk5QBnyM",
  "contentUrl": "https://www.youtube.com/watch?v=OMlBk5QBnyM"
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can you provide spooky Halloween character voices?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Guy Harris performs Dracula, Ghost Face, Joker impressions, Vincent Price-style narration and more for Halloween ads, promos and events."
      }
    },
    {
      "@type": "Question",
      "name": "Do you offer fast turnaround for Halloween voiceovers?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Most Halloween scripts are voiced the same day, recorded in a broadcast-quality studio with Zoom, Cleanfeed or Source Connect-style remote direction."
      }
    },
    {
      "@type": "Question",
      "name": "Where have your Halloween voices been used?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Guy’s Halloween voiceovers have featured on BBC Radio 1, Asda, Thorpe Park Fright Nights, Poundland and countless YouTube and social media campaigns."
      }
    }
  ]
}
</script>
	  
     
     </head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo html_entity_decode(Config::get('seo17.s3')); ?>



</div>
</div>
</div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">

<iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/1219781&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true" width="100%" height="315" frameborder="no" scrolling="no"></iframe><br />

</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">
<div class="row">

<div class="col-md-6" >

<?php echo html_entity_decode(Config::get('seo17.s4')); ?>
</div>

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo17.s20');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo17.s7'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo17.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo17.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo17.s8'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo17.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo17.s5')); ?>
</div>


</div>

<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo17.s6')); ?>

</div>

<div class="col-md-6" >
<br>
<a href="voiceover-cartoons" title="Scary Cartoon Voiceovers by Guy Harris">
    <img alt="Scary Cartoon Voiceovers" title="Scary Cartoon Voiceovers by Guy Harris" class="img-responsive" src="assets/images/voiceover-cartoon-scary-voices.png" />
  </a>

</div>


</div>







<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Container-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

   <?php include("assets/inc/footer.php"); ?>
    
</body>
</html>