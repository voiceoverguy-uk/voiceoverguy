<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo22.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo22.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seo22.s2'); ?>">

<meta name="Robots" content="index, follow">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<link rel="shortcut icon" href="assets/images/favicon/images/favicon.ico" />
<link rel="mask-icon" sizes="any" href="assets/images/favicon/favicon-152.svg" color="#000000">   
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/source-connect-now" />
<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
     
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    "mainEntity": {
      "@type": "Person",
      "name": "Guy Harris",
      "alternateName": "VoiceoverGuy",
      "jobTitle": "British Male Voiceover Artist",
      "description": "Guy Harris is a British male voiceover artist with over 25 years of experience. This page previously supported Source Connect Now, but now uses Source Nexus for remote recording sessions.",
      "url": "https://www.voiceoverguy.co.uk/source-connect-now",
      "image": "https://www.voiceoverguy.co.uk/assets/images/guy-harris-voiceover.png",
      "sameAs": [
        "https://www.linkedin.com/in/voiceoverguy/",
        "https://www.youtube.com/user/voiceoverguyharris"
      ],
      "worksFor": {
        "@type": "Organization",
        "name": "VoiceoverGuy"
      }
    }
  }
  </script>
  </head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>














<div id="parallax">
<div class="container">



<div class="row">

<div class="col-md-6" >
<br>
<?php echo html_entity_decode(Config::get('seo22.s3')); ?>
</div>

<div class="col-md-6" >


 <?php
	  if (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') !== false
 || strpos($_SERVER['HTTP_USER_AGENT'], 'CriOS') !== false) {
	 
	
	 ?>
     <br>   <br>
     <!--
      <iframe src='https://source-elements.com/now/embed/voiceoverguy/default'  width='500' height='670' allow="microphone" ></iframe>
      
      <iframe src="https://source-elements.com/now/embed/voiceoverguy" width="500" height="870" allow="microphone"></iframe>
      
      -->
<object class="embed" data="https://nexus.source-elements.com/voiceoverguy" type="text/html" width="100%" height='670' allow="microphone https://now.source-elements.com">
 </object>

   

     
     <?php

	
	
}
else{
	

	
	 ?>
     
     <br>   <br>
     <p>To use Source connect NOW please open this page in Chrome, if you dont have Chrome download it for free.</p>
     
     
  
     
     
     <?php
	 
	
}

?>
       
                


</div>


</div>

<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo22.s4')); ?>
</div>

<div class="col-md-6" >
<br>

<a href="voiceover-cartoons" title="Guy Harris - Source Connect NOW" ><img alt="Guy Harris - Source Connect NOW" title="Guy Harris - Source Connect NOW" class="img-responsive"   src="assets/images/cartoons/Voiceover-Cartoon-Source-Connect.jpg" /></a>


</div>


</div>







<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

  <?php include("assets/inc/footer.php"); ?>
    
</body>
</html>