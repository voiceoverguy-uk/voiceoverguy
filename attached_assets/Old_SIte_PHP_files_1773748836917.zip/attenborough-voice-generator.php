<?php
require_once 'guyadmin/app/init.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>David Attenborough Voice Generator | Create a Nature Script</title>
  <meta name="description" content="Create a hilarious or awe-inspiring David Attenborough-style nature narration. Just type a scene and let the AI script begin.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="canonical" href="https://www.voiceoverguy.co.uk/attenborough-voice-generator.php" />
  <meta property="og:title" content="David Attenborough Voice Generator" />
  <meta property="og:description" content="Craft your own narration in the style of Sir David Attenborough. Enter a scene and let the storytelling begin." />
  <meta property="og:image" content="https://www.voiceoverguy.co.uk/images/attenborough-voice-og.jpg" />
  <meta property="og:url" content="https://www.voiceoverguy.co.uk/attenborough-voice-generator.php" />
  <meta name="twitter:card" content="summary_large_image">
  <link rel="stylesheet" href="/attenborough-voice/style.css?v=2">
  <style>
    .outlined-box {
      border: 2px solid #ff2c2c;
      border-radius: 8px;
      padding: 10px;
      margin-top: 10px;
    }
    .output-box {
      min-height: 160px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Attenborough Voiceover Script Generator</h1>
    <p>Type any scenario, and VoiceoverGuy will transform it into a fun, nature-style voiceover, narrated just like Sir David Attenborough.</p>

    <div class="input-box">
      <form id="generatorForm" method="POST" action="" onsubmit="showWaitMessage(); return true;">
        <textarea class="outlined-box" id="prompt" name="prompt" rows="6" maxlength="500" placeholder="Describe your scenario..."><?php echo isset($_POST['prompt']) ? htmlspecialchars($_POST['prompt']) : ''; ?></textarea>
        <div id="wordCount">0 / 500 characters</div>
        <button type="submit" class="generate-button">Generate Narration</button>
        <div id="please-wait" style="display:none;">Awaiting your creation...</div>
      </form>
    </div>

    <?php if (isset($_POST['prompt'])): ?>
      <div class="output-box outlined-box">
        <div class="script-output">
          <h2>Narrated Scene:</h2>
          <p>In the great theatre of life, <?php echo htmlspecialchars($_POST['prompt']); ?></p>
        </div>
      </div>
    <?php endif; ?>

    <section class="style-guide">
      <h2>🎬 David Attenborough's Style</h2>
      <ul class="star-list">
        <li>⭐ Try the Attenborough Voiceover Generator</li>
        <li>⭐ Write any scene, idea, or silly thought to Attenborough-ize</li>
        <li>⭐ Enjoy the magic – and remember: no potty mouth!</li>
        <li>⭐ Prefer the real human touch? Listen to Guy’s own Attenborough demo:</li>
      </ul>
      <audio controls>
        <source src="/assets/audio/david-attenborough-demo-25-guy-harris.mp3" type="audio/mpeg">
        Your browser does not support the audio element.
      </audio>
    </section>
  </div>

  <script src="/attenborough-voice/script.js?v=1"></script>
</body>
</html>