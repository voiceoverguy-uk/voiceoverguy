<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

      <title><?php echo Config::get('seo13.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo13.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="<?php echo Config::get('seo13.s3'); ?>" />

<meta name="twitter:description" content="<?php echo Config::get('seo13.s2'); ?>" />

<meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/football-commentator-voice-og.jpg" />

<meta name="Robots" content="index, follow">

 




<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />



<link rel="canonical" href="https://www.voiceoverguy.co.uk/football-commentator-voice" /> 

<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	
	
	<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Guy Harris - Football Commentator Voice",
  "image": "https://www.voiceoverguy.co.uk/assets/images/football-commentator-voice-og.jpg",
  "description": "Guy Harris is a British voiceover artist known for his football commentator-style voice, used by BBC, Netflix, and major sports brands.",
  "url": "https://www.voiceoverguy.co.uk/football-commentator-voice",
  "telephone": "+44 113 123 4567",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Wakefield",
    "addressRegion": "West Yorkshire",
    "postalCode": "WF1",
    "addressCountry": "GB"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "53.6829",
    "longitude": "-1.4964"
  },
  "priceRange": "£100 - £5000",
  "openingHours": "Mo-Sa 07:00-21:00",
  "sameAs": [
    "https://www.linkedin.com/in/voiceoverguy/",
    "https://www.youtube.com/user/voiceoverguyharris"
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can I hire Guy Harris for a football commentator-style voiceover?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, Guy Harris is available to voice football-style commentaries for TV, radio, promos, and comedy spots. His voice is trusted by major broadcasters and sports clubs."
      }
    },
    {
      "@type": "Question",
      "name": "Is the voiceover studio located in Wakefield, West Yorkshire?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, Guy’s voiceover studio is based in Wakefield, West Yorkshire and offers remote and in-person directed sessions."
      }
    },
    {
      "@type": "Question",
      "name": "What’s included in a football commentator voiceover session?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Voiceover sessions include a live directed call, multiple takes, and delivery in your preferred format. Fast turnaround and professional audio are guaranteed."
      }
    }
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://www.voiceoverguy.co.uk/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Football Commentator Voice",
      "item": "https://www.voiceoverguy.co.uk/football-commentator-voice"
    }
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "AudioObject",
  "name": "Football Commentator Voice – Guy Harris",
  "description": "Professional football commentator-style voiceover demo by Guy Harris.",
  "url": "https://www.voiceoverguy.co.uk/assets/audio/football-commentator-showreel-guy-harris.mp3",
  "contentUrl": "https://www.voiceoverguy.co.uk/assets/audio/football-commentator-showreel-guy-harris.mp3",
  "encodingFormat": "audio/mpeg",
  "duration": "PT72S",
  "uploadDate": "2025-01-01T00:00:00+00:00",
  "creator": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk/football-commentator-voice",
    "image": "https://www.voiceoverguy.co.uk/images/guy-harris-profile.jpg"
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "Football Commentator Voice – Guy Harris",
  "description": "High-energy football commentator-style voiceover demo.",
  "thumbnailUrl": "https://i.ytimg.com/vi/T9opwMc46Ms/maxresdefault.jpg",
  "uploadDate": "2025-01-01T00:00:00+00:00",
  "duration": "PT30S",
  "embedUrl": "https://www.youtube.com/embed/T9opwMc46Ms",
  "contentUrl": "https://www.youtube.com/watch?v=T9opwMc46Ms"
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "Football Commentator Voice – Guy Harris (Video 2)",
  "description": "Additional football commentator-style voiceover demo.",
  "thumbnailUrl": "https://i.ytimg.com/vi/<?php echo Config::get('seo13.s8'); ?>/maxresdefault.jpg",
  "uploadDate": "2025-01-01T00:00:00+00:00",
  "duration": "PT30S",
  "embedUrl": "https://www.youtube.com/embed/<?php echo Config::get('seo13.s8'); ?>",
  "contentUrl": "https://www.youtube.com/watch?v=<?php echo Config::get('seo13.s8'); ?>"
}
</script>
	
	</head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo html_entity_decode(Config::get('seo13.s3')); ?>



</div>
</div>
</div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">

<iframe width="100%" height="320" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/254194483&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false" title="Football Commentator Voiceover Demo Playlist" aria-label="Football Commentator Voiceover Demo Playlist"></iframe>




</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">
<div class="row">

<div class="col-md-6" >

<?php echo html_entity_decode(Config::get('seo13.s4')); ?>
<div style="margin:20px 0;">
    <audio controls style="width:100%; max-width:420px;">
        <source src="https://www.voiceoverguy.co.uk/assets/audio/football-commentator-showreel-guy-harris.mp3" type="audio/mpeg">
        Your browser does not support the audio element.
    </audio>
    <p style="font-size:0.9em; opacity:0.8; margin-top:5px;">
        Football Commentator Showreel – Guy Harris
    </p>
</div>
</div>

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo13.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo13.s7'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo13.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo13.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo13.s8'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo13.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo13.s5')); ?>
</div>


</div>

<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo13.s6')); ?>

</div>

<div class="col-md-6" >
<br>
<a href="voiceover-cartoons" title="Guy Harris Football Commentator Voice" ><img alt="Guy Harris Football Commentator Voice" title="Guy Harris Football Commentator Voice" class="img-responsive"   src="assets/images/cartoons/Voiceover-Cartoon-A-30.jpg" /></a>

</div>


</div>







<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

<?php include("assets/inc/footer.php"); ?>
    
</body>
</html>