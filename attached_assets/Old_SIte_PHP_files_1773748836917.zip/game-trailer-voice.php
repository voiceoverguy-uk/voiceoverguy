<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo26.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo26.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seo26.s2'); ?>">
<link href="https://plus.google.com/+GuyHarrisVoiceoverGuy" rel="publisher" />

<meta name="Robots" content="index, follow">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">


<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/game-trailer-voice" /> 

<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo Config::get('seo26.s1'); ?>">
    <meta property="og:description" content="<?php echo Config::get('seo26.s2'); ?>">
    <meta property="og:url" content="https://www.voiceoverguy.co.uk/game-trailer-voice">
    <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/game-trailer-voice-og.jpg">
    <meta property="og:site_name" content="VoiceoverGuy">
    <meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/game-trailer-voice-og.jpg">

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can you voice a dramatic game trailer?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, Guy Harris specialises in voicing game trailers with high-impact, cinematic delivery. His voice brings drama, tension, and emotion to every campaign."
      }
    },
    {
      "@type": "Question",
      "name": "Do you offer quick turnaround on game trailer voiceovers?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Absolutely. Guy's broadcast-quality studio is available daily for rapid delivery—perfect for gaming trailers with tight deadlines or last-minute requests."
      }
    }
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "AudioObject",
  "name": "Guy Harris Game Trailer Voiceover Demo",
  "description": "Listen to Guy Harris deliver a powerful and cinematic voiceover, perfect for gaming trailers and launch campaigns.",
  "url": "https://www.voiceoverguy.co.uk/assets/audio/guy-harris-voiceoverguy-game-trailer-showreel.mp3",
  "contentUrl": "https://www.voiceoverguy.co.uk/assets/audio/guy-harris-voiceoverguy-game-trailer-showreel.mp3",
  "duration": "PT1M14S",
  "encodingFormat": "audio/mpeg",
  "datePublished": "2024-06-01",
  "author": {
    "@type": "Person",
    "name": "Guy Harris"
  }
}
</script>
  </head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo html_entity_decode(Config::get('seo26.s3')); ?>



</div>
</div>
</div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">

<iframe width="100%" height="170" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/280408431&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>


</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">



<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo26.s4')); ?>
</div>

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo26.s20');
if ( $string2 == "1" ){
?>
<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo26.s7'); ?>" frameborder="0" allowfullscreen></iframe>
<?php } else { ?>
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo26.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php } ?>

</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo26.s21');
if ( $string2 == "1" ){
?>
<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo26.s8'); ?>" frameborder="0" allowfullscreen></iframe>
<?php } else { ?>
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo26.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php } ?>
</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo26.s5')); ?>
</div>


</div>












<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo26.s11')); ?>
</div>

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo26.s22');
if ( $string2 == "1" ){
?>
<iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo26.s9'); ?>" frameborder="0" allowfullscreen></iframe>
<?php } else { ?>
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo26.s9'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php } ?>

</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo26.s23');
if ( $string2 == "1" ){
?>
<iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo26.s10'); ?>" frameborder="0" allowfullscreen></iframe>
<?php } else { ?>
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo26.s10'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php } ?>
</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo26.s12')); ?>
</div>


</div>






<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo26.s6')); ?>

</div>

<div class="col-md-6" >
<br>
<?php
$string2 = Config::get('seo26.s24');
if ( $string2 == "1" ){
?>
<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo26.s13'); ?>" frameborder="0" allowfullscreen></iframe>
<?php } else { ?>
<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo26.s13'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>
<?php } ?>
</div>


</div>







<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

   <?php include("assets/inc/footer.php"); ?>
    
</body>
</html>