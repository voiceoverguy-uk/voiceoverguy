<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo10.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo10.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seo10.s2'); ?>">

<meta name="Robots" content="index, follow">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">


<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />



<link rel="canonical" href="https://www.voiceoverguy.co.uk/movie-trailer-voice" /> 

<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>

    <!-- Open Graph Meta -->
    <meta property="og:title" content="Movie Trailer Voice – Guy Harris">
    <meta property="og:description" content="Deep UK or USA Movie Trailer voice for Promos, Film or Events. TV, Radio or YouTube usage. Clients include BBC Radio 1, BBC Sport, Sport Relief, Saturday Night Takeaway, Strictly Come Dancing, Kleeneze, and dozens of video games including Turtle Strike & Kings Road.">
    <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/movie-trailer-voice-og.jpg" />
    <meta property="og:url" content="https://www.voiceoverguy.co.uk/movie-trailer-voice">
    <meta property="og:type" content="profile">
    <meta property="og:site_name" content="VoiceoverGuy">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Movie Trailer Voice – Guy Harris">
    <meta name="twitter:description" content="Deep UK or USA Movie Trailer voice for Promos, Film or Events. TV, Radio or YouTube usage. Clients include BBC Radio 1, BBC Sport, Sport Relief, Saturday Night Takeaway, Strictly Come Dancing, Kleeneze, and dozens of video games including Turtle Strike & Kings Road.">
    <meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/movie-trailer-voice-og.jpg">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Can I hire Guy Harris for a movie trailer voiceover?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes. Guy Harris provides movie trailer-style voiceovers for TV, radio, film, events, and online use. His voice has been featured in campaigns for BBC, ITV, and major games and promos."
          }
        },
        {
          "@type": "Question",
          "name": "What styles of movie trailer voice can Guy deliver?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Guy can deliver both UK and US-style movie trailer voices, ranging from deep dramatic tones to parody-style trailers with impact."
          }
        },
        {
          "@type": "Question",
          "name": "Where is Guy’s voiceover studio located?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Guy records from his professional studio in Wakefield, West Yorkshire. Sessions can be directed live via Source Connect, Cleanfeed, or Zoom."
          }
        }
      ]
    }
    </script>
    </head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo html_entity_decode(Config::get('seo10.s3')); ?>



</div>
</div>
</div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">

<iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/1232759&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true" height="315" width="100%" frameborder="no" scrolling="no"></iframe>




</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">
<div class="row">

<div class="col-md-6" >


<br>


<?php
$string2 = Config::get('seo10.s20');
if ( $string2 == "1" ){
?>

<iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo10.s7'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo10.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>


</div>

<div class="col-md-6" >

<?php echo html_entity_decode(Config::get('seo10.s4')); ?>


</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>


<?php
$string2 = Config::get('seo10.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo10.s5'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo10.s5'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>


</div>

<div class="col-md-6" >
<br>


<?php
$string2 = Config::get('seo10.s22');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo10.s8'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo10.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>


</div>

<div class="row">

<div class="col-md-6" >


<br>

<?php
$string2 = Config::get('seo10.s23');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo10.s9'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo10.s9'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>

<div class="col-md-6" >


<br>

<?php
$string2 = Config::get('seo10.s24');
if ( $string2 == "1" ){
?>

<iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo10.s11'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo10.s11'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>



</div>


</div>




<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo10.s6')); ?>
</div>

<div class="col-md-6" >
<br>
<a href="voiceover-cartoons" title="VoiceoverGuy Harris - Movie Trailer Voice" ><img alt="VoiceoverGuy Harris - Movie Trailer Voice" title="VoiceoverGuy Harris - Movie Trailer Voice" class="img-responsive"   src="assets/images/cartoons/Voiceover-Cartoon-movie-trailer-voice.jpg" /></a>

</div>


</div>



<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

  <?php include("assets/inc/footer.php"); ?>
    
</body>
</html>