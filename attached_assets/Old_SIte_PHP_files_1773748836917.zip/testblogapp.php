
<?php
$mysql_host     = 'localhost';   # use your mysql host host (ussually 127.0.0.1)
$mysql_user     = 'cl10-nreblog';            # use your mysql user
$mysql_pass     = 'earwax69';            # use your mysql password here
$mysql_database = 'cl10-nreblog'; # use your mysql databas here

if(!$link = mysqli_connect($mysql_host, $mysql_user, $mysql_pass)){
    echo 'could not connect database';
    }
    
if(!mysqli_select_db($link, $mysql_database)){
   echo "Database not found";
   die();       
   }

$query = mysqli_query($link, "SELECT * 
                              FROM messages2 
                              WHERE id = '{$_GET['id']}' ");


if(mysqli_num_rows($query) == 0){
   header('Location: voiceover-news');
   die();
   }
else{
    $row = mysqli_fetch_assoc($query);
    }
       
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

   
<link href="assets/css/all.css" rel="stylesheet">
<script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>


   
    

</head>


<body>
  
  <div style="height: 2em;
   
    position:relative;
    z-index:1;"><a href="voiceover-news-app"><img src="assets/img/blog/back-arrow-black.png"  height="44"></a></div>

    












<div class="container">
<div class="row">
<div class="col-md-12" >


<h1><?php echo $row['page_title']; ?> </h1>
<?php echo $row['info']; ?>
<div class="bar"></div>
</div>
</div>
</div>
</div>




<div class="container">
<div class="row">
<div class="col-md-12" >
<?php echo $row['text1']; ?>
</div>

<div class="col-md-12" >
<br>


  

<?php
$string2 = $row['whatvideo'];

if ( $string2 == "1" ){ ?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo $row['video']; ?>" frameborder="0" allowfullscreen></iframe>


<? }elseif ( $string2 == "0" ){ ?>

<iframe src="//player.vimeo.com/video/<?php echo $row['video']; ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } else { ?>

<?php echo $row['video']; ?>


<?php } ?>




</div>
</div>



<div class="row">
<div class="col-md-12" >
<br>
<div class="effect1">
<?php echo $row['text2']; ?>
</div>
</div>

<div class="col-md-12" >

<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['alt']; ?>" class="img-responsive  imageborder"   src="assets/img/blog/<?php echo $row['image']; ?>" />

</div>
</div>



<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo $row['bottomtext']; ?>





 




           


</div>
</div>
</div>
</div>
<div class="bar"></div>







</div>

</div><?php include("assets/inc/footer.php"); ?>
   
  
</body>
</html>

