document.addEventListener('DOMContentLoaded', () => {
  const textarea = document.getElementById('userInput');
  const wordCountDisplay = document.getElementById('wordCount');
  const newScriptBtn = document.getElementById('newScenarioBtn');
  const copyBtn = document.getElementById('copyBtn');
  const generateBtn = document.getElementById('generateBtn');
  const outputDiv = document.getElementById('output');
  const outputContent = document.getElementById('outputContent');

  // Word count and limit enforcement
  textarea.addEventListener('input', () => {
    const words = textarea.value.trim().split(/\s+/).filter(word => word.length > 0);
    let wordCount = words.length;

    if (wordCount >= 75) {
      const trimmed = words.slice(0, 75).join(' ');
      textarea.value = trimmed + ' ';
      wordCount = 75;
    }

    wordCountDisplay.textContent = `${wordCount}/75 words`;

    if (wordCount >= 75) {
      wordCountDisplay.style.color = '#ff3333';
      wordCountDisplay.classList.add('word-limit-hit');
      showWarningPopup();
      setTimeout(() => wordCountDisplay.classList.remove('word-limit-hit'), 300);
    } else if (wordCount >= 75) {
      wordCountDisplay.style.color = '#ffaa33';
    } else {
      wordCountDisplay.style.color = '#ccc';
    }
  });

  // Reset form
  function resetForm() {
    textarea.value = '';
    outputContent.innerHTML = '<span class="text-muted">Awaiting your festive notes...</span>';
    wordCountDisplay.textContent = '0/75 words';
    wordCountDisplay.style.color = '#ccc';
    newScriptBtn.classList.add('hidden');
    copyBtn.classList.add('hidden');
    
    // Remove audio player if exists
    const audioPlayer = document.getElementById('voicePreview');
    if (audioPlayer) {
      audioPlayer.remove();
    }
  }

  // Show warning popup
  function showWarningPopup() {
    const popup = document.getElementById('popup');
    popup.classList.add('show');
    setTimeout(() => popup.classList.remove('show'), 4000);
  }

  // Reset button
  newScriptBtn.addEventListener('click', resetForm);

  // Copy button
  copyBtn.addEventListener('click', () => {
    const outputText = outputContent.innerText;
    navigator.clipboard.writeText(outputText)
      .then(() => {
        copyBtn.textContent = '✅ Copied!';
        setTimeout(() => {
          copyBtn.textContent = '📋 Copy Script';
        }, 2000);
      })
      .catch(err => {
        console.error('Copy failed', err);
        copyBtn.textContent = '❌ Copy Failed';
      });
  });

  // Generate script - AJAX call to backend
  generateBtn.addEventListener('click', async () => {
    const userInput = textarea.value.trim();
    
    // Validate input
    if (!userInput) {
      outputContent.innerHTML = '<span class="text-error">Please give some details of who the message is for.</span>';
      return;
    }

    // Show loading state
    outputContent.innerHTML = '<span class="text-muted">Generating Santa message... Please Ho Ho Hold!</span>';
    newScriptBtn.classList.add('hidden');
    copyBtn.classList.add('hidden');

    // Check for profanity (client-side)
    const bannedWords = ['damn', 'cunt', 'fucker', 'fucking', 'cocksucker', 'crap', 'shit', 'fuck', 'bastard', 'bugger', 'bollocks', 'wanker', 'twat'];
    const lowerInput = userInput.toLowerCase();

    const profanityWarnings = [
  "Santa: \"Oh dear oh dear... you may be moved to the naughty list with words like that.\"",
  "Santa: \"Language like that? Not even the elves mutter such nonsense in the toy workshop.\"",
  "Santa: \"Tsk tsk! I hope that wasn’t meant for my nice list ears.\"",
  "Santa: \"Such words could melt the North Pole! Mind your mouth, young one.\"",
  "Santa: \"Even the reindeer are blushing. That’s quite an achievement.\"",
  "Santa: \"You kiss your stocking with that mouth? Naughty list updated.\"",
  "Santa: \"Watch your language or you'll be gifted a lump of coal and a thesaurus.\"",
  "Santa: \"Mrs Claus just fainted. She’s not used to such spicy vocabulary.\"",
  "Santa: \"Elves have been sent to sensitivity training for less.\"",
  "Santa: \"Even the gingerbread men have crumbled at that outburst.\"",
  "Santa: \"Rudolph turned off his nose — he doesn’t want to hear this.\"",
  "Santa: \"Ho-ho-HOLD IT RIGHT THERE! Naughty words are not in my sleigh route.\"",
  "Santa: \"Careful now, that sort of language echoes in the snow for *days*.\"",
  "Santa: \"You’ll scare the carollers with that tone, my friend.\"",
  "Santa: \"I check the list twice… and that word just flagged you *twice*.\"",
  "Santa: \"The polar bears are writing a strongly worded letter to HR.\"",
  "Santa: \"Coal production has just been increased — care to guess why?\"",
  "Santa: \"Let’s try that again, this time without upsetting the candy canes.\"",
  "Santa: \"Oh my stars — even the snowmen are melting from embarrassment.\"",
  "Santa: \"That kind of language will get you a one-way ticket to Grinchville.\"",
  "Santa: \"Ho-ho-oh no! That’s not how we speak in Santa’s Grotto.\"",
  "Santa: \"You wouldn’t say that in front of the reindeer… or would you? Naughty!\"",
  "Santa: \"This isn’t the chimney to vent your naughty words down, thank you very much.\"",
  "Santa: \"You just got bumped from presents to pine needles. Watch it!\"",
  "Santa: \"If the elves heard that, they’d drop their tiny hammers in shock.\"",
  "Santa: \"Language like that makes even Krampus look tame.\"",
  "Santa: \"You're about two syllables away from getting a stern letter from the North Pole.\"",
  "Santa: \"The workshop has rules — and Rule One is: no flipping the festive script.\"",
  "Santa: \"Your tongue’s more twisted than a candy cane. Let’s try again — nicely.\"",
  "Santa: \"That’s not festive spirit — that’s festive spit! Clean it up.\"",
  "Santa: \"I’d ask if your parents know you speak like that… but I already do. Naughty list!\"",
  "Santa: \"The sleigh just veered off course in shock. Let’s try again with cheer.\"",
  "Santa: \"Heavens! You’ve made a snow angel cry.\"",
  "Santa: \"Use that mouth for singing carols, not conjuring curses.\"",
  "Santa: \"Honestly, the elves are considering industrial action after hearing that.\"",
  "Santa: \"You’ve triggered the emergency jingle bell protocol — mind your language.\"",
  "Santa: \"It’s a holly jolly Christmas — not a sweary scary one.\"",
  "Santa: \"Even Jack Frost got cold feet after hearing that one.\"",
  "Santa: \"Let’s turn that naughty utterance into a nice sentence, shall we?\""
    ];

    if (bannedWords.some(word => lowerInput.includes(word))) {
      const randomWarning = profanityWarnings[Math.floor(Math.random() * profanityWarnings.length)];
      outputContent.innerHTML = `<span class="text-error"><strong>${randomWarning}</strong></span>`;
      return;
    }

    try {
      // Send request to PHP backend
      const response = await fetch('/api/generate1', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: userInput
        })
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      // Validate response format
      if (!data.script) {
        throw new Error('Invalid response format: missing script');
      }

      // Display the script
      outputContent.innerHTML = data.script;
      outputContent.classList.remove('text-muted');
      outputContent.classList.add('text-white');

      // Handle audio if provided
      if (data.audioUrl) {
        // Remove existing audio player if any
        const existingAudio = document.getElementById('voicePreview');
        if (existingAudio) {
          existingAudio.remove();
        }

        // Create and add new audio player
        const audioPlayer = document.createElement('audio');
        audioPlayer.id = 'voicePreview';
        audioPlayer.controls = true;
        audioPlayer.classList.add('audio-player');
        audioPlayer.src = data.audioUrl;
        outputDiv.appendChild(audioPlayer);
        
        // Auto-play if available
        audioPlayer.play().catch(err => {
          console.log('Auto-play prevented:', err);
        });
      }

      // Show action buttons
      newScriptBtn.classList.remove('hidden');
      copyBtn.classList.remove('hidden');

    } catch (error) {
      console.error('Generation error:', error);
      outputContent.innerHTML = `<span class="text-error">An error occurred: ${error.message}. Please try again.</span>`;
      newScriptBtn.classList.remove('hidden');
    }
  });

  // Demo audio player glow effect
  const demoAudio = document.getElementById('realGuyDemo');
  const demoWrapper = document.getElementById('demoPlayerWrapper');

  if (demoAudio && demoWrapper) {
    demoAudio.addEventListener('play', () => {
      demoWrapper.classList.add('glow');
    });

    demoAudio.addEventListener('pause', () => {
      demoWrapper.classList.remove('glow');
    });

    demoAudio.addEventListener('ended', () => {
      demoWrapper.classList.remove('glow');
    });
  }
});
