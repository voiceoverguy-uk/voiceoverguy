<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en-GB">
  <head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo Config::get('seo2.s7'); ?></title>
<meta name="description" content="<?php echo Config::get('seo2.s8'); ?>">
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">
<meta name="twitter:description" content="<?php echo Config::get('seo2.s8'); ?>">
<meta name="Robots" content="index, follow">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />
<link rel="canonical" href="https://www.voiceoverguy.co.uk/voiceoverguy" /> 
<link href="assets/css/all.css" rel="stylesheet">
<script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	
	
	<script type="application/ld+json">
	
	{
  "@context": "https://schema.org",
  "@type": "ProfilePage",
  "mainEntity": {
    "@type": "Person",
    "name": "Guy Harris",
    "alternateName": "VoiceoverGuy",
    "jobTitle": "British Male Voiceover Artist",
    "description": "Guy Harris is an award-winning British voiceover artist with over 25 years of experience, known for his versatility in character voices such as Santa, Attenborough, Pirate, and Gameshow Host.",
    "url": "https://www.voiceoverguy.co.uk/voiceoverguy",
    "image": "https://www.voiceoverguy.co.uk/images/guy-harris-voiceover.png",
    "sameAs": [
      "https://www.linkedin.com/in/voiceoverguy/",
      "https://www.youtube.com/user/voiceoverguyharris"
    ],
    "worksFor": {
      "@type": "Organization",
      "name": "VoiceoverGuy"
    }
  }
} 
	
	  </script>
	
	
    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="Guy Harris – British Voiceover Guy" />
    <meta property="og:description" content="Award-winning British voiceover artist specialising in commercials, games & character voices. Based in Yorkshire, available worldwide." />
    <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/guy-award-winner.jpg" />
    <meta property="og:url" content="https://www.voiceoverguy.co.uk/voiceoverguy.php" />
    <meta property="og:type" content="profile" />

    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="Guy Harris – British Voiceover Guy" />
    <meta name="twitter:description" content="Award-winning British voiceover artist with 25+ years of experience. Book today!" />
    <meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/guy-award-winner.jpg" />


    <!-- Preload Hero Image -->
    <link rel="preload" as="image" href="assets/images/guy-harris-voiceover.png" type="image/png">
	</head>
<body>
  

<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>

    


<div class="container"  >
<div class="row">
<div class="col-md-12">
<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container">
<?php include("assets/inc/menu.php"); ?>
</div></div></div></div>

	
<div id="parallax">
<div class="container">
<div class="row">

	
<div class="col-md-12" >
<?php echo html_entity_decode(Config::get('seo2.s1')); ?>
</div></div>

<div class="bar"></div>

	
	
<div class="row">
<div class="col-md-6" >

<?php echo html_entity_decode(Config::get('seo2.s2')); ?>
<br>
<img src="assets/images/voiceoverguy-skateboarder.jpg" width="527" height="1000" class="img-responsive imageborder"  title="VoiceoverGuy Skateboarder" alt="VoiceoverGuy the Skateboarder">

<?php echo html_entity_decode(Config::get('seo2.s6')); ?>



</div>



<div class="col-md-6">
<br>
<img src="assets/images/guy-harris-male-voiceover-award-winner.jpg" width="527" height="1000" class="img-responsive imageborder"  title="guy-harris-male-voiceover-award-winner" alt="VoiceoverGuy Male Voiceover Award Winner">
<?php echo html_entity_decode(Config::get('seo2.s3')); ?>
<br>
<img src="assets/images/voiceover-studio-yorkshire.jpg" width="527" height="1000" class="img-responsive imageborder"  title="VoiceoverGuy Yorkshire Studio" alt="VoiceoverGuy West Yorkshire Studio">



</div>

<!-- Start Second Row-->
</div>




<?php echo html_entity_decode(Config::get('seo2.s4')); ?>
<div class="row">
<div class="col-md-6" >



<br>
<img src="assets/images/voiceoverguy-character-voices.jpg" width="527" height="1000" class="img-responsive imageborder"  title="VoiceoverGuy Character Voices" alt="VoiceoverGuy Character Voices">




</div>



<div class="col-md-6">

<?php echo html_entity_decode(Config::get('seo2.s5')); ?>

</div>

<!-- Start Second Row-->
</div>


<div class="row">
<div class="col-md-6" >



<?php echo html_entity_decode(Config::get('seo2.s10')); ?>


</div>



<div class="col-md-6">



<br>
<img src="assets/images/guy-harris-uk-voice-of-santa.jpg" width="527" height="1000" class="img-responsive imageborder"  title="VoiceoverGuy The UK Voice of Santa" alt="UK Voice of Santa">



</div>

<!-- Start Second Row-->
</div>






<div class="bar"></div>








<div class="row">
<div class="col-md-6" >
<br>

	

	
	<iframe width="100%" height="315" src="<?php echo html_entity_decode(Config::get('seo2.s9')); ?>" frameborder="0" allowfullscreen></iframe>
	

	
	
</div>
<div class="col-md-6">
	

<?php echo html_entity_decode(Config::get('seo2.s11')); ?>



</div>

<!-- Start Second Row-->
</div>









<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

<?php include("assets/inc/footer.php"); ?>
    
</body>
</html>