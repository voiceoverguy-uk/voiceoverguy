

<?php http_response_code(404); ?>


<?php require_once 'guyadmin/app/init.php';?>



<?php
error_reporting(0); // Turn off all error reporting
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>404 - Page Not Found | VoiceoverGuy</title>

    <meta name="description" content="404 - Page not found. Explore VoiceoverGuy for character voices, Santa, events and more by Guy Harris.">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seoBlogHome.s2'); ?>">


<meta name="robots" content="noindex, follow">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

 
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/voiceover-news" /> 
<link href="assets/css/all.css" rel="stylesheet">
<script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>

<!--
<script type="text/javascript" src="https://www.voiceoverguy.co.uk/searchjquery-1.8.0.min.js"></script>
-->

<script type="text/javascript">
$(function(){
$(".search").keyup(function() 
{ 
var searchid = $(this).val();
var dataString = 'search='+ searchid;
if(searchid!='')
{
    $.ajax({
    type: "POST",
    url: "search/search.php",
    data: dataString,
    cache: false,
    success: function(html)
    {
    $("#result").html(html).show();
	
	
	
    }
    });
}return false;    
});


$(document).mouseup(function (e)
{
	
	  jQuery("#result").fadeOut(); 
});




});
</script>
   <style type="text/css">
   
   
    .content{
        width:100%;
		max-width:650px;
        margin:0 auto;
    }
    #searchid
    {
        width:100%;
		height:50px;
        border:solid 1px #999;
        padding:20px;
        font-size:14px;
		margin-bottom:21px;
		
    }
    #result
    {
        position:absolute;
         width:100%;
		 max-width:650px;
        padding:10px;
        display:none;
        margin-top:-1px;
        border-top:0px;
        overflow:hidden;
        border:1px #999 solid;
        background-color: white;
		max-height:460px;
		overflow:scroll;
    }
    .show
    {
        padding:3px; 
        
        font-size:10px; 
      
    }
    .show:hover
    {
	
        background:#4c66a4;
        color:#FFF;
        cursor:pointer;
    }
</style>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "404 - Page Not Found | VoiceoverGuy",
  "url": "https://www.voiceoverguy.co.uk/404.php",
  "description": "This page could not be found. Explore VoiceoverGuy for professional voiceover demos and services by Guy Harris.",
  "mainEntity": {
    "@type": "Person",
    "name": "Guy Harris",
    "url": "https://www.voiceoverguy.co.uk/",
    "jobTitle": "British Male Voiceover Artist",
    "image": "https://www.voiceoverguy.co.uk/assets/images/guy-harris-voiceover.png"
  }
}
</script>
    </head>

<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>
</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">
<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
</div></div></div>

<?php
$input = array(Config::get('searchops.s1'), Config::get('searchops.s2'), Config::get('searchops.s3'), Config::get('searchops.s4'), Config::get('searchops.s5'));
$rand_keys = array_rand($input, 2);

?>


<div class="content">
	
<span style="text-align:center; background: rgba(0,0,0,0.2); padding-left: 18px; padding-right: 16px; padding-bottom: 33px; padding-top: 33px;">
<input  type="text" class="search" id="searchid" style="width:94%; height:47px;border-style: solid;
   
     border-width: 1px;
    border-color: black; padding-left:10px " placeholder="So... what are you looking for?" autocomplete="off" />
    
         
	</span>
	
	
<br>
<div id="result" style="z-index:2"></div>
</div>


   














<div id="parallax">
<main role="main">
<div class="container">



<div class="row">
	<span style="text-align: center">
	
		<h1><span class="ident" >404</span> Page not found</h1>

<p>How odd? We can't seem to find that page. Mmm, how about one of these?</p>
<div style="margin: 20px 0; padding: 20px; border: 2px solid #d42027; border-radius: 8px; background: #f9f9f9;">
  <h2 style="color:#d42027;">Don't worry, the voiceover show goes on 🎙️</h2>
  <p>Here are some quick links to help you get back on track:</p>
  <ul style="list-style: none; padding-left: 0; line-height: 1.8;">
    <li>👉 <a href="https://www.voiceoverguy.co.uk/" title="VoiceoverGuy Homepage">Return to the homepage</a></li>
    <li>👉 <a href="https://www.voiceoverguy.co.uk/voiceover-news" title="Voiceover News">Latest voiceover news</a></li>
    <li>👉 <a href="https://www.voiceoverguy.co.uk/character-voiceover" title="Character Voices">Character voices</a></li>
 <li>👉 <a href="https://www.voiceoverguy.co.uk/santa-voice" title="The UK's Voice of Santa">The UK's Voice of Santa</a></li>
    <li>👉 <a href="https://www.voiceoverguy.co.uk/contact-guy" title="Contact Guy">Contact Guy</a></li>
  </ul>
  <p style="margin-top: 12px;">Even my <strong>404 pages</strong> come with character 😉</p>
</div>
	
	</span>
	
<br><br>
<br>



 <?php 

$num_rec_per_page=200;

mysql_connect('localhost','cl10-nreblog','earwax69');

mysql_select_db('cl10-nreblog');

if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 

$start_from = ($page-1) * $num_rec_per_page; 

$sql = "SELECT * FROM messages2 WHERE rating = '5' ORDER BY rand() LIMIT $start_from, $num_rec_per_page"; 

$rs_result = mysql_query ($sql); //run the query

?> 



<?php 

while ($row = mysql_fetch_assoc($rs_result)) { 

?> 


<div class="col-md-4" style=" min-height:350px" >


<p style="font-size:18px"><strong><?php echo $row['page_title']; ?></strong></p><?php if (Auth::userCan('list_users')): ?>
<a href="https://www.voiceoverguy.co.uk/guyadmin/admin.php?page=options-blog-edit&theid=<?php echo $row['id']; ?>" target="_blank"> Edit this Blog</a>

<?php endif ?>

<a href="<?php echo $row['url']; ?>" title="<?php echo $row['alt']; ?>">
<div class="effect1">
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['alt']; ?>" class="img-responsive imageborder"   src="assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</a>



<p><?php echo $row['hometext']; ?></p>




      </div>

<?php 

}; 



?> 





<?php 

$num_rec_per_page=200;

mysql_connect('localhost','cl10-nreblog','earwax69');

mysql_select_db('cl10-nreblog');

if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 

$start_from = ($page-1) * $num_rec_per_page; 

$sql = "SELECT * FROM messages2 WHERE rating = '3' ORDER BY rand() LIMIT $start_from, $num_rec_per_page"; 

$rs_result = mysql_query ($sql); //run the query

?> 



<?php 

while ($row = mysql_fetch_assoc($rs_result)) { 

?> 


<div class="col-md-4" style=" min-height:350px" >


<p style="font-size:18px"><strong><?php echo $row['page_title']; ?></strong></p><?php if (Auth::userCan('list_users')): ?>
<a href="https://www.voiceoverguy.co.uk/guyadmin/admin.php?page=options-blog-edit&theid=<?php echo $row['id']; ?>" target="_blank"> Edit this Blog</a>

<?php endif ?>

<a href="<?php echo $row['url']; ?>" title="<?php echo $row['alt']; ?>">
<div class="effect1">
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['alt']; ?>" class="img-responsive imageborder"   src="assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</a>



<p><?php echo $row['hometext']; ?></p>



    

      </div>

<?php 

}; 



?> 








<?php 

$num_rec_per_page=200;

mysql_connect('localhost','cl10-nreblog','earwax69');

mysql_select_db('cl10-nreblog');

if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 

$start_from = ($page-1) * $num_rec_per_page; 

$sql = "SELECT * FROM messages2 WHERE rating = '0' ORDER BY rand() LIMIT $start_from, $num_rec_per_page"; 

$rs_result = mysql_query ($sql); //run the query

?> 



<?php 

while ($row = mysql_fetch_assoc($rs_result)) { 

?> 


<div class="col-md-4" style=" min-height:350px" >


<p style="font-size:18px"><strong><?php echo $row['page_title']; ?></strong></p><?php if (Auth::userCan('list_users')): ?>
<a href="https://www.voiceoverguy.co.uk/guyadmin/admin.php?page=options-blog-edit&theid=<?php echo $row['id']; ?>" target="_blank"> Edit this Blog</a>

<?php endif ?>

<a href="<?php echo $row['url']; ?>" title="<?php echo $row['alt']; ?>">
<div class="effect1">
<img  alt="<?php echo $row['alt']; ?>" title="<?php echo $row['alt']; ?>" class="img-responsive imageborder"   src="assets/img/blog/<?php echo $row['image']; ?>" />
</div>
</a>



<p><?php echo $row['hometext']; ?></p>



      </div>

<?php 

}; 



?> 


</div>
<div style="text-align:center">

<?php 

$sql = "SELECT * FROM messages2"; 

$rs_result = mysql_query($sql); //run the query

$total_records = mysql_num_rows($rs_result);  //count number of records

$total_pages = ceil($total_records / $num_rec_per_page); 



//echo "<a href='allblog.php?page=1'>".'<i class="fa fa-arrow-left fa-1x" aria-hidden="true"></i>'."</a> "; // Goto 1st page  



for ($i=1; $i<=$total_pages; $i++) { 
//
        //    echo "<a href='allblog.php?page=".$i."'>".$i."</a> "; 

}; 

//echo "<a href=allblog.php?page=$total_pages'>".'<i class="fa fa-arrow-right fa-1x" aria-hidden="true"></i>'."</a> "; // Goto last page

?>




</div>


</main>
<?php include("assets/inc/applinks.php"); ?>   

</div>


<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>

</div><?php include("assets/inc/footer.php"); ?>
    
</body>
</html>
