<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo4.s1'); ?></title>

    <meta name="description" content="<?php echo Config::get('seo4.s2'); ?>">
    
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:site" content="@voiceoverman">

<meta name="twitter:title" content="Commercial Voiceover | Guy Harris" />
<meta name="twitter:description" content="Radio & TV Commercial Voiceovers for Global, Bauer, Disney, Apple & more." />
<meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/commercial-voiceover-og.jpg" />

<meta name="Robots" content="index, follow">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
 
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />


<link rel="canonical" href="https://www.voiceoverguy.co.uk/commercial-voiceover" />
<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script>
	
	<script type="application/ld+json">
	{
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    "mainEntity": {
      "@type": "Person",
      "name": "Guy Harris",
      "url": "https://www.voiceoverguy.co.uk/commercial-voiceover",
      "image": "https://www.voiceoverguy.co.uk/assets/images/commercial-voiceover-og.jpg",
      "sameAs": [
        "https://www.voiceoverguy.co.uk",
        "https://www.linkedin.com/in/voiceoverguy/"
      ],
      "jobTitle": "British Commercial Voiceover Artist",
      "description": "Guy Harris is a leading UK commercial voiceover artist for TV, radio, and digital campaigns. Trusted by brands like Disney, Apple, Hotels.com, Heart, Capital, Smooth, Bauer and more."
    }
  }
  </script>
  
  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Guy Harris Voiceover",
  "image": "https://www.voiceoverguy.co.uk/assets/images/guy-harris-voiceover.png",
  "url": "https://www.voiceoverguy.co.uk/commercial-voiceover",
  "telephone": "+44-113-000-0000",
  "priceRange": "£100–£5000",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Wakefield",
    "addressRegion": "West Yorkshire",
    "addressCountry": "United Kingdom"
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday"
    ],
    "opens": "07:00",
    "closes": "21:00"
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Can I hire Guy Harris for TV and radio commercial voiceovers?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes. Guy Harris is a highly experienced UK commercial male voiceover artist trusted by brands like Disney, Apple, Hotels.com, and major radio networks."
      }
    },
    {
      "@type": "Question",
      "name": "Where is Voiceoverguy's Guy Harris’s studio located?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The studio is based in Wakefield, West Yorkshire, and is available for remote sessions and commercial bookings."
      }
    },
    {
      "@type": "Question",
      "name": "What is the typical cost of a commercial voiceover?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Prices typically range from £100 to £5000 depending on the usage and duration of the campaign."
      }
    }
  ]
}
</script>
  
  <meta property="og:title" content="Commercial Voiceover | Guy Harris – UK Radio & TV Voice Artist" />
  <meta property="og:description" content="Trusted by Disney, Apple, Hotels.com and major UK radio networks. Book Guy Harris for your next commercial voiceover." />
  <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/commercial-voiceover-og.jpg" />
  <meta property="og:url" content="https://www.voiceoverguy.co.uk/commercial-voiceover" />
  <meta property="og:type" content="profile" />

  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="Commercial Voiceover | Guy Harris" />
  <meta name="twitter:description" content="Radio & TV Commercial Voiceovers for Global, Bauer, Disney, Apple & more." />
  <meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/commercial-voiceover-og.jpg" />
	
	</head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>







<div id="parallax">
<div class="container">
<div class="row">
<div class="col-md-12" >


<?php echo html_entity_decode(Config::get('seo4.s3')); ?>



</div>
</div>
</div>
</div>



<div class="container-fluid">
<div class="row">
<div class="col-md-12" style=" background-color: #9E0100; padding-top:20px; padding-bottom:20px;">
<div class="container">
<iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/1232779&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true" height="315" width="100%" frameborder="no" scrolling="no"></iframe>
</div>
</div>
</div>
</div>





<div id="parallax">
<div class="container">
<div class="row">

<div class="col-md-6" >

<h2>Trusted Voice on UK Radio Commercials</h2>
<?php echo html_entity_decode(Config::get('seo4.s4')); ?>
</div>

<div class="col-md-6" >
<br>

<h2>TV Ad Voiceovers for Leading Brands</h2>

<?php
$string2 = Config::get('seo4.s20');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo4.s7'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo4.s7'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>



</div>


</div>


<div class="row">

<div class="col-md-6" >
<br>

<?php
$string2 = Config::get('seo4.s21');
if ( $string2 == "1" ){
?>

<iframe width="100%"  height="315" src="https://www.youtube.com/embed/<?php echo Config::get('seo4.s8'); ?>" frameborder="0" allowfullscreen></iframe>

<?php } else { ?>

<iframe src="//player.vimeo.com/video/<?php echo Config::get('seo4.s8'); ?>?title=0&amp;byline=0&amp;portrait=0" height="281" width="100%" allowfullscreen="" frameborder="0"></iframe>


<?php } ?>
</div>

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo4.s5')); ?>
</div>


</div>

<div class="row">

<div class="col-md-6" >
<?php echo html_entity_decode(Config::get('seo4.s6')); ?>
</div>

<div class="col-md-6" >
<br>
<a href="voiceover-cartoons" title="Guy Harris – British Male Commercial Voiceover" ><img alt="Guy Harris - Commercial Voiceover" title="Guy Harris - Commercial Voiceover" class="img-responsive"   src="assets/images/cartoons/Voiceover-Cartoon-Darth-Vader.jpg" /></a>

</div>


</div>







<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Containerr-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>

 <?php include("assets/inc/footer.php"); ?>
 
</body>
</html>