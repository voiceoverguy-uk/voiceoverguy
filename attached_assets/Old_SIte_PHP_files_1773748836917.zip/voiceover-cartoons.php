<?php require_once 'guyadmin/app/init.php';?>


<!DOCTYPE html>
<html lang="en-GB">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo Config::get('seo24.s1'); ?></title>
    <!-- Meta tags for SEO -->
 

    <link rel="canonical" href="https://www.voiceoverguy.co.uk/voiceover-cartoons">
    <meta property="og:title" content="Voiceover Cartoons by Guy Harris – British Voice Actor">
    <meta property="og:description" content="A light-hearted series of cartoons showing the quirky side of life in the voiceover booth. Created by Guy Harris, a top UK voice artist.">
    <meta property="og:image" content="https://www.voiceoverguy.co.uk/assets/images/voiceover-cartoons-og.jpg">
    <meta property="og:url" content="https://www.voiceoverguy.co.uk/voiceover-cartoons">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Voiceover Cartoons – A Fun Look Behind the Mic">
    <meta name="twitter:description" content="Explore original voiceover-themed cartoons by UK voice artist Guy Harris. A fun take on VO life.">
    <meta name="twitter:image" content="https://www.voiceoverguy.co.uk/assets/images/voiceover-cartoons-og.jpg">
    <link rel="preload" as="image" href="https://www.voiceoverguy.co.uk/assets/images/voiceover-cartoons-og.jpg">
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ProfilePage",
      "name": "Cartoon Voiceovers | Guy Harris – British Voiceover Artist",
      "url": "https://www.voiceoverguy.co.uk/cartoon-voiceovers",
      "mainEntity": {
        "@type": "Person",
        "name": "Guy Harris",
        "url": "https://www.voiceoverguy.co.uk/",
        "image": "https://www.voiceoverguy.co.uk/assets/images/guy-harris-voiceover.png",
        "jobTitle": "British Male Voiceover Artist",
        "sameAs": [
          "https://www.linkedin.com/in/voiceoverguy/",
          "https://www.voiceoverguy.co.uk/",
          "https://www.youtube.com/voiceoverguy"
        ]
      }
    }
    </script>

    <meta name="description" content="<?php echo Config::get('seo24.s2'); ?>">
    
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@voiceoverman">
<meta name="twitter:title" content="Guy Harris">

<meta name="twitter:description" content="<?php echo Config::get('seo24.s2'); ?>">

<meta name="Robots" content="index, follow">

 

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

 
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/images/favicon/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/favicon/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="assets/images/favicon/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/images/favicon/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/images/favicon/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/images/favicon/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="assets/images/favicon/favicon-180.png" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16.png" sizes="16x16">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-17.png" sizes="17x17">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-18.png" sizes="18x18">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-255.png" sizes="255x255">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-256.png" sizes="256x256">
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="assets/images/favicon/favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;"/>
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="assets/images/favicon/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="assets/images/favicon/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="assets/images/favicon/mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="assets/images/favicon/mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="assets/images/favicon/mstile-310x310.png" />



<link rel="canonical" href="https://www.voiceoverguy.co.uk/voiceover-cartoons" /> 
<link href="assets/css/all.css" rel="stylesheet">
     <script type="text/javascript" src="assets/fancybox/lib/jquery-1.10.1.min.js"></script></head>
<body>
  
  
<!-- Start Top Menu -->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="maintopnav" >
			       
<nav class="topnav">
<?php include("assets/inc/socials.php"); ?>
</nav>

</div>
</div>
</div>
<!-- End Top Menu -->
    




<div class="container">
<div class="row">
<div class="col-md-12">

<a href="https://www.voiceoverguy.co.uk" title="Guy Harris - Voiceover Guy">
<img alt="Guy Harris - Voiceover Guy" title="Guy Harris - Voiceover Guy" class="img-responsive" id="newlogo"  src="assets/images/guy-harris-voiceover.png" />
</a> 
<br>
<div class="container"> <?php include("assets/inc/menu.php"); ?></div>
    

</div></div></div>


<div id="parallax">




<div class="container">
<div class="row">
<div class="col-md-12" style="text-align:center" >


<?php echo html_entity_decode(Config::get('seo24.s3')); ?>


<div class="col-md-3">
<span style="cursor:zoom-in" class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-12-Days.jpg"  title="Voiceover Cartoon - 12 Days" >
<br>
<img alt="Voiceover Cartoon - 12 Days" title="Voiceover Cartoon - 12 Days"  src="assets/images/cartoons_small/Voiceover-Cartoon-12-Days.jpg" style="height:200px;" class="center-block img-responsive"/></span>
</div>
	
	
	
<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-A-30.jpg"  title="Voiceover Cartoon - A 30" >
<br><img alt="Voiceover Cartoon - A 30" title="Voiceover Cartoon - A 30"   src="assets/images/cartoons_small/Voiceover-Cartoon-A-30.jpg" style="height:200px;"class="center-block img-responsive"/></span>
</div>
	
<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Accents.jpg"  title="Voiceover Cartoon - Accents" >
<br><img alt="Voiceover Cartoon - Accents" title="Voiceover Cartoon - Accents"   src="assets/images/cartoons_small/Voiceover-Cartoon-Accents.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>
	
<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Agency-Nerves.jpg"  title="Voiceover Cartoon - Agency Nerves" >
<br><img alt="Voiceover Cartoon - Agency Nerves" title="Voiceover Cartoon - Agency Nerves"    src="assets/images/cartoons_small/Voiceover-Cartoon-Agency-Nerves.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>
	
<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Busy-Day.jpg"  title="Voiceover Cartoon - Busy Day" >
<br><img alt="Voiceover Cartoon - Busy Day" title="Voiceover Cartoon - Busy Day"   src="assets/images/cartoons_small/Voiceover-Cartoon-Busy-Day.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Bad-Santa.jpg"  title="Voiceover Cartoon - Bad Santa" >
<br><img alt="Voiceover Cartoon - Bad Santa" title="Voiceover Cartoon - Bad Santa"    src="assets/images/cartoons_small/Voiceover-Cartoon-Bad-Santa.jpg" style="height:200px;" class="center-block img-responsive"/></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Awesome-At-Oral.jpg"  title="Voiceover Cartoon - Awesome At Oral" >
<br><img alt="Voiceover Cartoon - Awesome At Oral" title="Voiceover Cartoon - Awesome At Oral"   src="assets/images/cartoons_small/Voiceover-Cartoon-Awesome-At-Oral.jpg" style="height:200px;" class="center-block img-responsive"/></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Awards.jpg"  title="Voiceover Cartoon - Awards" >
<br><img alt="Voiceover Cartoon - Awards" title="Voiceover Cartoon - Awards"   src="assets/images/cartoons_small/Voiceover-Cartoon-Awards.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Alexander-Technique.jpg"  title="Voiceover Cartoon - Alexander Technique" >
<br><img alt="Voiceover Cartoon - Alexander Technique" title="Voiceover Cartoon - Alexander Technique"   src="assets/images/cartoons_small/Voiceover-Cartoon-Alexander-Technique.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Agent.jpg"  title="Voiceover Cartoon - Agent" >
<br><img alt="Voiceover Cartoon - Agent" title="Voiceover Cartoon - Agent"    src="assets/images/cartoons_small/Voiceover-Cartoon-Agent.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-DeBreathing.jpg"  title="Voiceover Cartoon - DeBreathing" >
<br><img alt="Voiceover Cartoon - DeBreathing" title="Voiceover Cartoon - DeBreathing"    src="assets/images/cartoons_small/Voiceover-Cartoon-DeBreathing.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Darth-Vader.jpg"  title="Voiceover Cartoon - Darth Vader" >
<br><img alt="Voiceover Cartoon - Darth Vader" title="Voiceover Cartoon - Darth Vader"    src="assets/images/cartoons_small/Voiceover-Cartoon-Darth-Vader.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-commuting.jpg"  title="Voiceover Cartoon - commuting" >
<br><img alt="Voiceover Cartoon - commuting" title="Voiceover Cartoon - commuting"    src="assets/images/cartoons_small/Voiceover-Cartoon-commuting.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Clothing.jpg"  title="Voiceover Cartoon - Clothing" >
<br><img alt="Voiceover Cartoon - Clothing" title="Voiceover Cartoon - Clothing"    src="assets/images/cartoons_small/Voiceover-Cartoon-Clothing.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-client-written.jpg"  title="Voiceover Cartoon - client written" >
<br><img alt="Voiceover Cartoon - client written" title="Voiceover Cartoon - client written"    src="assets/images/cartoons_small/Voiceover-Cartoon-client-written.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Child-Voices.jpg"  title="Voiceover Cartoon - Child Voices" >
<br><img alt="Voiceover Cartoon - Child Voices" title="Voiceover Cartoon - Child Voices"    src="assets/images/cartoons_small/Voiceover-Cartoon-Child-Voices.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

         
<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-HowJSay.jpg"  title="Voiceover Cartoon - HowJSay" >
<br><img alt="Voiceover Cartoon - HowJSay" title="Voiceover Cartoon - HowJSay"    src="assets/images/cartoons_small/Voiceover-Cartoon-HowJSay.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-How-Much.jpg"  title="Voiceover Cartoon - How Much" >
<br><img alt="Voiceover Cartoon - How Much" title="Voiceover Cartoon - How Much"    src="assets/images/cartoons_small/Voiceover-Cartoon-How-Much.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-hohoho.jpg"  title="Voiceover Cartoon - hohoho" >
<br><img alt="Voiceover Cartoon - hohoho" title="Voiceover Cartoon - hohoho"    src="assets/images/cartoons_small/Voiceover-Cartoon-hohoho.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Equity.jpg"  title="Voiceover Cartoon - Equity" >
<br><img alt="Voiceover Cartoon - Equity" title="Voiceover Cartoon - Equity"    src="assets/images/cartoons_small/Voiceover-Cartoon-Equity.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Dont-You-Know-Who-I-am.jpg"  title="Voiceover Cartoon - Dont You Know Who I am" >
<br><img alt="Voiceover Cartoon - Dont You Know Who I am" title="Voiceover Cartoon - Dont You Know Who I am"    src="assets/images/cartoons_small/Voiceover-Cartoon-Dont-You-Know-Who-I-am.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Dinner-Bore.jpg"  title="Voiceover Cartoon - Dinner Bore" >
<br><img alt="Voiceover Cartoon - Dinner Bore" title="Voiceover Cartoon - Dinner Bore"    src="assets/images/cartoons_small/Voiceover-Cartoon-Dinner-Bore.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Demo-Tapes.jpg"  title="Voiceover Cartoon - Demo Tapes" >
<br><img alt="Voiceover Cartoon - Demo Tapes" title="Voiceover Cartoon - Demo Tapes"    src="assets/images/cartoons_small/Voiceover-Cartoon-Demo-Tapes.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-DeEssing.jpg"  title="Voiceover Cartoon - DeEssing" >
<br><img alt="Voiceover Cartoon - DeEssing" title="Voiceover Cartoon - DeEssing"    src="assets/images/cartoons_small/Voiceover-Cartoon-DeEssing.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>
	
<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Narration.jpg"  title="Voiceover Cartoon - Narration" >
<br><img alt="Voiceover Cartoon - Narration" title="Voiceover Cartoon - Narration"    src="assets/images/cartoons_small/Voiceover-Cartoon-Narration.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Multitasking.jpg"  title="Voiceover Cartoon - Multitasking" >
<br><img alt="Voiceover Cartoon - Multitasking" title="Voiceover Cartoon - Multitasking"    src="assets/images/cartoons_small/Voiceover-Cartoon-Multitasking.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-movie-trailer-voice.jpg"  title="Voiceover Cartoon - movie trailer voice" >
<br><img alt="Voiceover Cartoon - movie trailer voice" title="Voiceover Cartoon - movie trailer voice"    src="assets/images/cartoons_small/Voiceover-Cartoon-movie-trailer-voice.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Mic-Selection.jpg"  title="Voiceover Cartoon - Mic Selection" >
<br><img alt="Voiceover Cartoon - Mic Selection" title="Voiceover Cartoon - Mic Selection"    src="assets/images/cartoons_small/Voiceover-Cartoon-Mic-Selection.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Losing-the-big-gig.jpg"  title="Voiceover Cartoon - Losing the big gig" >
<br><img alt="Voiceover Cartoon - Losing the big gig" title="Voiceover Cartoon - Losing the big gig"    src="assets/images/cartoons_small/Voiceover-Cartoon-Losing-the-big-gig.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-London-Jobs.jpg"  title="Voiceover Cartoon - London Jobs" >
<br><img alt="Voiceover Cartoon - London Jobs" title="Voiceover Cartoon - London Jobs"    src="assets/images/cartoons_small/Voiceover-Cartoon-London-Jobs.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Last-Minute-Job.jpg"  title="Voiceover Cartoon - Last Minute Job" >
<br><img alt="Voiceover Cartoon - Last Minute Job" title="Voiceover Cartoon - Last Minute Job"    src="assets/images/cartoons_small/Voiceover-Cartoon-Last-Minute-Job.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Just-got-up.jpg"  title="Voiceover Cartoon - Just got up" >
<br><img alt="Voiceover Cartoon - Just got up" title="Voiceover Cartoon - Just got up"    src="assets/images/cartoons_small/Voiceover-Cartoon-Just-got-up.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-In-Store.jpg"  title="Voiceover Cartoon - In Store" >
<br><img alt="Voiceover Cartoon - In Store" title="Voiceover Cartoon - In Store"    src="assets/images/cartoons_small/Voiceover-Cartoon-In-Store.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-illness.jpg"  title="Voiceover Cartoon - illness" >
<br><img alt="Voiceover Cartoon - illness" title="Voiceover Cartoon - illness"    src="assets/images/cartoons_small/Voiceover-Cartoon-illness.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>



<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Overseas-debts.jpg"  title="Voiceover Cartoon - Overseas debts" >
<br><img alt="Voiceover Cartoon - Overseas debts" title="Voiceover Cartoon - Overseas debts"    src="assets/images/cartoons_small/Voiceover-Cartoon-Overseas-debts.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-OnHold.jpg"  title="Voiceover Cartoon - On-Hold" >
<br><img alt="Voiceover Cartoon - On-Hold" title="Voiceover Cartoon - On-Hold"    src="assets/images/cartoons_small/Voiceover-Cartoon-OnHold.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-On-The-Hunt.jpg"  title="Voiceover Cartoon - On The Hunt" >
<br><img alt="Voiceover Cartoon - On The Hunt" title="Voiceover Cartoon - On The Hunt"    src="assets/images/cartoons_small/Voiceover-Cartoon-On-The-Hunt.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-on-a-budget.jpg"  title="Voiceover Cartoon - on a budget" >
<br><img alt="Voiceover Cartoon - on a budget" title="Voiceover Cartoon - on a budget"    src="assets/images/cartoons_small/Voiceover-Cartoon-on-a-budget.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Off-Mic.jpg"  title="Voiceover Cartoon - Off Mic" >
<br><img alt="Voiceover Cartoon - Off Mic" title="Voiceover Cartoon - Off Mic"    src="assets/images/cartoons_small/Voiceover-Cartoon-Off-Mic.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Nov-5th.jpg"  title="Voiceover Cartoon - Nov 5th" >
<br><img alt="Voiceover Cartoon - Nov 5th" title="Voiceover Cartoon - Nov 5th"    src="assets/images/cartoons_small/Voiceover-Cartoon-Nov-5th.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-NDA.jpg"  title="Voiceover Cartoon - NDA" >
<br><img alt="Voiceover Cartoon - NDA" title="Voiceover Cartoon - NDA"    src="assets/images/cartoons_small/Voiceover-Cartoon-NDA.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>



<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Rudolf.jpg"  title="Voiceover Cartoon - Rudolf" >
<br><img alt="Voiceover Cartoon - Rudolf" title="Voiceover Cartoon - Rudolf"    src="assets/images/cartoons_small/Voiceover-Cartoon-Rudolf.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Quiet-Days.jpg"  title="Voiceover Cartoon - Quiet Days" >
<br><img alt="Voiceover Cartoon - Quiet Days" title="Voiceover Cartoon - Quiet Days"    src="assets/images/cartoons_small/Voiceover-Cartoon-Quiet-Days.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Popping-The-Mic.jpg"  title="Voiceover Cartoon - Popping The Mic" >
<br><img alt="Voiceover Cartoon - Popping The Mic" title="Voiceover Cartoon - Popping The Mic"    src="assets/images/cartoons_small/Voiceover-Cartoon-Popping-The-Mic.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Poorly-Sick.jpg"  title="Voiceover Cartoon - Poorly Sick" >
<br><img alt="Voiceover Cartoon - Poorly Sick" title="Voiceover Cartoon - Poorly Sick"    src="assets/images/cartoons_small/Voiceover-Cartoon-Poorly-Sick.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Pitch-Shifting.jpg"  title="Voiceover Cartoon - Pitch Shifting" >
<br><img alt="Voiceover Cartoon - Pitch Shifting" title="Voiceover Cartoon - Pitch Shifting"    src="assets/images/cartoons_small/Voiceover-Cartoon-Pitch-Shifting.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Pirate-Voice.jpg"  title="Voiceover Cartoon - Pirate Voice" >
<br><img alt="Voiceover Cartoon - Pirate Voice" title="Voiceover Cartoon - Pirate Voice"    src="assets/images/cartoons_small/Voiceover-Cartoon-Pirate-Voice.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Phone-Patching.jpg"  title="Voiceover Cartoon - Phone Patching" >
<br><img alt="Voiceover Cartoon - Phone Patching" title="Voiceover Cartoon - Phone Patching"    src="assets/images/cartoons_small/Voiceover-Cartoon-Phone-Patching.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Pay-Peanuts.jpg"  title="Voiceover Cartoon - Pay Peanuts" >
<br><img alt="Voiceover Cartoon - Pay Peanuts" title="Voiceover Cartoon - Pay Peanuts"    src="assets/images/cartoons_small/Voiceover-Cartoon-Pay-Peanuts.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Own-Studio.jpg"  title="Voiceover Cartoon - Own Studio" >
<br><img alt="Voiceover Cartoon - Own Studio" title="Voiceover Cartoon - Own Studio"    src="assets/images/cartoons_small/Voiceover-Cartoon-Own-Studio.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Sound-Proofing.jpg"  title="Voiceover Cartoon - Sound Proofing" >
<br><img alt="Voiceover Cartoon - Sound Proofing" title="Voiceover Cartoon - Sound Proofing"    src="assets/images/cartoons_small/Voiceover-Cartoon-Sound-Proofing.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Showreels.jpg"  title="Voiceover Cartoon - Showreels" >
<br><img alt="Voiceover Cartoon - Showreels" title="Voiceover Cartoon - Showreels"    src="assets/images/cartoons_small/Voiceover-Cartoon-Showreels.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Sensual-Read.jpg"  title="Voiceover Cartoon - Sensual Read" >
<br><img alt="Voiceover Cartoon - Sensual Read" title="Voiceover Cartoon - Sensual Read"    src="assets/images/cartoons_small/Voiceover-Cartoon-Sensual-Read.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Scary-VoicesIV.jpg"  title="Voiceover Cartoon - Scary VoicesIV" >
<br><img alt="Voiceover Cartoon - Scary VoicesIV" title="Voiceover Cartoon - Scary VoicesIV"    src="assets/images/cartoons_small/Voiceover-Cartoon-Scary-VoicesIV.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Scary-VoicesII.jpg"  title="Voiceover Cartoon - Scary VoicesII" >
<br><img alt="Voiceover Cartoon - Scary VoicesII" title="Voiceover Cartoon - Scary VoicesII"    src="assets/images/cartoons_small/Voiceover-Cartoon-Scary-VoicesII.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Scary-Voices.jpg"  title="Voiceover Cartoon - Scary Voices" >
<br><img alt="Voiceover Cartoon - Scary Voices" title="Voiceover Cartoon - Scary Voices"    src="assets/images/cartoons_small/Voiceover-Cartoon-Scary-Voices.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Santa-Style.jpg"  title="Voiceover Cartoon - Santa Style" >
<br><img alt="Voiceover Cartoon - Santa Style" title="Voiceover Cartoon - Santa Style"    src="assets/images/cartoons_small/Voiceover-Cartoon-Santa-Style.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Santa-Magic.jpg"  title="Voiceover Cartoon - Santa Magic" >
<br><img alt="Voiceover Cartoon - Santa Magic" title="Voiceover Cartoon - Santa Magic"    src="assets/images/cartoons_small/Voiceover-Cartoon-Santa-Magic.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Santa-Calls.jpg"  title="Voiceover Cartoon - Santa Calls" >
<br><img alt="Voiceover Cartoon - Santa Calls" title="Voiceover Cartoon - Santa Calls"    src="assets/images/cartoons_small/Voiceover-Cartoon-Santa-Calls.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Today.jpg"  title="Voiceover Cartoon - Today" >
<br><img alt="Voiceover Cartoon - Today" title="Voiceover Cartoon - Today"    src="assets/images/cartoons_small/Voiceover-Cartoon-Today.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Time-Stretching.jpg"  title="Voiceover Cartoon - Time Stretching" >
<br><img alt="Voiceover Cartoon - Time Stretching" title="Voiceover Cartoon - Time Stretching"    src="assets/images/cartoons_small/Voiceover-Cartoon-Time-Stretching.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-TheAgency.jpg"  title="Voiceover Cartoon - TheAgency" >
<br><img alt="Voiceover Cartoon - TheAgency" title="Voiceover Cartoon - TheAgency"    src="assets/images/cartoons_small/Voiceover-Cartoon-TheAgency.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-The-Extra-Mile.jpg"  title="Voiceover Cartoon - The Extra Mile" >
<br><img alt="Voiceover Cartoon - The Extra Mile" title="Voiceover Cartoon - The Extra Mile"    src="assets/images/cartoons_small/Voiceover-Cartoon-The-Extra-Mile.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Technology.jpg"  title="Voiceover Cartoon - Technology" >
<br><img alt="Voiceover Cartoon - Technology" title="Voiceover Cartoon - Technology"    src="assets/images/cartoons_small/Voiceover-Cartoon-Technology.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Technical-issues.jpg"  title="Voiceover Cartoon - Technical issues" >
<br><img alt="Voiceover Cartoon - Technical issues" title="Voiceover Cartoon - Technical issues"    src="assets/images/cartoons_small/Voiceover-Cartoon-Technical-issues.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Stephen-Hawkins.jpg"  title="Voiceover Cartoon - Stephen Hawkins" >
<br><img alt="Voiceover Cartoon - Stephen Hawkins" title="Voiceover Cartoon - Stephen Hawkins"    src="assets/images/cartoons_small/Voiceover-Cartoon-Stephen-Hawkins.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Source-Connect.jpg"  title="Voiceover Cartoon - Source Connect" >
<br><img alt="Voiceover Cartoon - Source Connect" title="Voiceover Cartoon - Source Connect"    src="assets/images/cartoons_small/Voiceover-Cartoon-Source-Connect.jpg" style="height:200px;" class="center-block img-responsive" /></span>
	</div>
	
	
<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Vox.jpg"  title="Voiceover Cartoon - Vox" >
<br><img alt="Voiceover Cartoon - Vox" title="Voiceover Cartoon - Vox"    src="assets/images/cartoons_small/Voiceover-Cartoon-Vox.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Voiceover-Mums.jpg"  title="Voiceover Cartoon - Voiceover Mums" >
<br><img alt="Voiceover Cartoon - Voiceover Mums" title="Voiceover Cartoon - Voiceover Mums"    src="assets/images/cartoons_small/Voiceover-Cartoon-Voiceover-Mums.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-VoiceBid.jpg"  title="Voiceover Cartoon - VoiceBid" >
<br><img alt="Voiceover Cartoon - VoiceBid" title="Voiceover Cartoon - VoiceBid"    src="assets/images/cartoons_small/Voiceover-Cartoon-VoiceBid.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Voice-Of-God.jpg"  title="Voiceover Cartoon - Voice Of God" >
<br><img alt="Voiceover Cartoon - Voice Of God" title="Voiceover Cartoon - Voice Of God"    src="assets/images/cartoons_small/Voiceover-Cartoon-Voice-Of-God.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-voice-gimp.jpg"  title="Voiceover Cartoon - voice gimp" >
<br><img alt="Voiceover Cartoon - voice gimp" title="Voiceover Cartoon - voice gimp"    src="assets/images/cartoons_small/Voiceover-Cartoon-voice-gimp.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Voice-Coach.jpg"  title="Voiceover Cartoon - Voice Coach" >
<br><img alt="Voiceover Cartoon - Voice Coach" title="Voiceover Cartoon - Voice Coach"    src="assets/images/cartoons_small/Voiceover-Cartoon-Voice-Coach.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-UAE.jpg"  title="Voiceover Cartoon - UAE" >
<br><img alt="Voiceover Cartoon - UAE" title="Voiceover Cartoon - UAE"    src="assets/images/cartoons_small/Voiceover-Cartoon-UAE.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-topping-tailing.jpg"  title="Voiceover Cartoon - topping tailing" >
<br><img alt="Voiceover Cartoon - topping tailing" title="Voiceover Cartoon - topping tailing"    src="assets/images/cartoons_small/Voiceover-Cartoon-topping-tailing.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>


<div class="col-md-3" >
<span style="cursor:zoom-in"  class="fancybox-media" href="assets/images/cartoons/Voiceover-Cartoon-Too-Cheesey.jpg"  title="Voiceover Cartoon - Too Cheesey" >
<br><img alt="Voiceover Cartoon - Too Cheesey" title="Voiceover Cartoon - Too Cheesey"    src="assets/images/cartoons_small/Voiceover-Cartoon-Too-Cheesey.jpg" style="height:200px;" class="center-block img-responsive" /></span>
</div>

	


             





</div>
<div class="col-md-12" style="text-align:center" >

<?php echo html_entity_decode(Config::get('seo24.s4')); ?>
</div>

</div>














<?php include("assets/inc/applinks.php"); ?>   

</div><!-- End Container-->


<!-- Start Footer-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12" id="newfooter">

<?php echo html_entity_decode(Config::get('seo28.s1')); ?>
   
<?php include("assets/inc/socials.php"); ?>
<br> </div></div></div></div>
<!-- End Footer-->

</div>
	
	<script src="assets/js/scripts.js"></script>

  <?php include("assets/inc/footer.php"); ?>
    
</body>
</html>